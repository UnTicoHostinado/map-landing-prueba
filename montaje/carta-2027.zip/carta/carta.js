/* MAP · carta de navegación 2027 · 20261031 */

(function(){
"use strict";
/* ===== ruta: carta 3D → carta plana → versión clásica =====
   Va a la clásica si la persona la eligió (y no ha vuelto a abrir la carta), si tiene ahorro de datos o conexión 2G,
   o si el equipo tiene menos de 1 GB de memoria. ?carta=1 fuerza la carta y borra la elección. */
const CLASICA="/wp-content/uploads/2026/carta/clasica/";
const RUTA=(()=>{let q="",pref=null;try{q=location.search}catch(e){}
  const forzar=/[?&]carta=1/.test(q);
  try{if(forzar)localStorage.setItem("map27.portada","carta");pref=localStorage.getItem("map27.portada")}catch(e){}
  if(forzar) return "carta";
  if(pref==="carta") return "carta";        // la persona abrió la carta a propósito: se respeta
  if(pref==="clasica") return "clasica";
  const c=navigator.connection; if(c&&(c.saveData||/(^|-)2g$/.test(c.effectiveType||""))) return "clasica";
  if(navigator.deviceMemory&&navigator.deviceMemory<1) return "clasica";
  return "carta";})();
if(RUTA==="clasica"){location.replace(CLASICA);return}
/* ===== Datos: la carta y los ocho territorios =====
   Coordenadas en píxeles de la hoja NC 17-9 a 2576 px de ancho.
   Neatline calibrada: x 231 = 84°30'W, x 2526 = 83°00'W, y 61 = 10°00'N, y 1607 = 9°00'N. */
/* Bloque de cuatro hojas JOG recortadas a sus líneas de marco: 86°W–83°W, 11°N–9°N */
const CARTA={w:4096,h:2760,lon0:-86,lon1:-83,lat0:11,lat1:9};
const T=[
 {id:"la-barra",nombre:"La Barra",lugar:"San José",lo:-84.0843,la:9.925,tipo:"senal",frase:"La cantina es un templo.",link:"/cantina-ideal-3/",sub:"La Cantina Ideal"},
 {id:"traccion-humana",nombre:"Tracción Humana",lugar:"Cartago",lo:-83.9091,la:9.8506,tipo:"senal",frase:"No podían creer que yo lo hubiera hecho.",link:"/4-historias-de-patineta/",sub:"4 Historias de Patineta"},
 {id:"letra",archivo:"bastardos-poveda",nombre:"Los Bastardos de Poveda",lugar:"Transmitiendo desde distintas ermitas",lo:-83.8876,la:9.6158,tipo:"senal",frase:"…poco a poco nos íbamos dando cuenta hacia dónde apuntaba la serie.",link:"/podcast/#bastardos",sub:"Podcast",retrato:true,bastardos:true,rot:"Retrato",b:1,bit:[{t:"Valdo",frase:"…poco a poco nos íbamos dando cuenta hacia dónde apuntaba la serie.",link:"/podcast/#retrato-01",ep:"28 jun 2020",alt:"Retrato en plumilla de Valdo, con gorro de lana, anteojos de pasta y barba, firmado Los Bastardos de Poveda"},{t:"Bernabé Berrocal",frase:"…difícil entender este camino desde la biología hasta las letras.",link:"/podcast/#retrato-02",ep:"28 ago 2020",alt:"Retrato en plumilla de Bernabé Berrocal, con pelo largo, bigote y barba, firmado Los Bastardos de Poveda"},{t:"David Monge",frase:"El ejercicio mental de quien crece con la lectura.",link:"/podcast/#retrato-03",ep:"24 jun 2020",alt:"Retrato en plumilla de David Monge, con sombrero, anteojos y barba de candado, firmado Los Bastardos de Poveda"},{t:"Daniela Herrera",frase:"La vida teje historias que desafían el alma.",link:"/podcast/#retrato-04",ep:"16 feb 2024",alt:"Retrato en plumilla de Daniela Herrera, sonriente, con pelo largo ondulado y anteojos sobre la cabeza, firmado Los Bastardos de Poveda"},{t:"Bernardo Corrales",frase:"El hijo del aserrín, madera y poesía.",link:"/podcast/#retrato-05",ep:"9 jun 2020",alt:"Retrato en plumilla de Bernardo Corrales, con pelo corto y una sonrisa amplia, firmado Los Bastardos de Poveda"},{t:"Sergio Murillo",frase:"…impíos de letra y leyendas con miel de mango.",link:"/podcast/#retrato-06",ep:"27 abr 2022",alt:"Retrato en plumilla de Sergio Murillo, con anteojos oscuros, abrigo y bufanda, firmado Los Bastardos de Poveda"},{t:"Piro Soto",frase:"16 Reds o Aserrín, Fuego & Viento… ¿Qué le preocupa? ¿A qué le tiene miedo? ¿Le vale el qué dirán?",link:"/podcast/#retrato-07",ep:"28 mar 2021",alt:"Retrato en plumilla de Piro Soto, con pelo canoso, mirando hacia un lado, firmado Los Bastardos de Poveda"},{t:"Fabián González",frase:"A la gente le prohibían patinar y aun así, la gente patinaba.",link:"/podcast/#retrato-08",ep:"15 oct 2020",alt:"Retrato en plumilla de Fabián González, con sombrero de ala, anteojos, barba y camisa floreada, firmado Los Bastardos de Poveda"},{t:"Luis Poveda",frase:"Entre cervezas y estados muy alterados de consciencia.",link:"/podcast/#retrato-09",ep:"26 nov 2022",alt:"Retrato en plumilla de Luis Poveda, con gorro de lana, bigote blanco y una sonrisa amplia, firmado Los Bastardos de Poveda"}]},
 {id:"en-vivo",nombre:"En Vivo",lugar:"Turrialba",lo:-83.668,la:9.8894,tipo:"senal",frase:"Enciendo la televisión y nada me habla a mí.",link:"/serie-map/",sub:"Serie MAP"},
 {id:"sala-oscura",nombre:"Sala Oscura",lugar:"Quepos",lo:-84.1935,la:9.4217,tipo:"senal",frase:"El negocio de los medios en Costa Rica es otro.",link:"/sobre-el-director/",sub:"Cine"},
 {id:"zona-restringida",nombre:"Zona Restringida",lugar:"Cerro Chirripó",lo:-83.4902,la:9.5,tipo:"senal",frase:"Escritor, rockero, patriota y ciudadano del mundo.",link:"/carlos-alvarado-y-el-morbo-literario-del-poder/",sub:"Editorial",fotomontaje:true},
 {id:"estacion-arkadi",nombre:"Estación del Dr. Arkady",lugar:"Cerros de Puriscal",lo:-84.33,la:9.83,tipo:"senal",frase:"…nada más que con menos carros y mejores cantinas.",link:"/estudios-de-campo/",sub:"Los Estudios de Campo",estacion:true,total:10,b:1,bit:[{t:"Camino a la montaña",frase:"…nada más que con menos carros y mejores cantinas.",link:"/estudios-de-campo/",alt:"Una camioneta Ford antigua estacionada sobre el zacate, en blanco y negro"},{t:"Flashback",frase:"…escuchando cómo las láminas del techo crujían con la ventolera.",link:"/estudios-de-campo-bitacora-2/",alt:"Un pelotero de los Giants abrazado con dos aficionadas en la gramilla de un estadio, en sepia"},{t:"La playa",frase:"…un pacto que uno firma con el cansancio del día.",link:"/estudios-de-campo-3/",alt:"Un grupo de personas conversa en la acera, frente a la pared de una casa, en blanco y negro"},{t:"La crisis planetaria del bicho THX 1138",frase:"…no estaba pendiente abrirle las entrañas a nadie.",link:"/tri/",alt:"Una mujer en uniforme militar sonríe sentada frente a una máquina de escribir"},{t:"Escuela de brujos",frase:"…hurgando entre trastos que no recordaba haber guardado.",link:"/los-estudios-de-campo-del-dr-arkady-volkov-lazenkoescuela-de-brujos/",alt:"Retrato de familia frente a una casa de adobe, en blanco y negro"},{t:"Receptor transdimensional de banda vacante residual VX-996",frase:"—Héctor, esa frase no es de Sun Tzu —le dije.",link:"/bitacora-6/",alt:"Un operador con audífonos frente a una consola de radio; detrás, dos hombres sostienen un disco"}]},
 {id:"obra-gris",nombre:"Obra Gris",lugar:"Cordillera de Talamanca",lo:-83.3373,la:9.2878,tipo:"nubes",sub:"Arquitectura"},
 {id:"taller",nombre:"Taller",lugar:"Valle de El General",lo:-83.7098,la:9.271,tipo:"nubes",sub:"Arte"}
];
const COLLAGE=[ // foto y clip alternados: 9 y 9
 ["banda-vivo","en-vivo"],["clip-aire","traccion-humana","v"],["tapis","la-barra"],["clip-gente","la-barra","v"],
 ["ruido","sala-oscura","bn"],["clip-microfono","en-vivo","v"],["deck","taller"],["clip-silla","zona-restringida","v"],
 ["esteban-cartago","traccion-humana"],["clip-fosforo","la-barra","v"],["mascaradas","letra"],["clip-cantante","en-vivo","v"],
 ["calavera","taller"],["clip-calle","traccion-humana","v"],["revista","traccion-humana"],["clip-cartones","obra-gris","v"],
 ["punk-bnw","en-vivo"],["clip-banda","en-vivo","v"]
];
/* ===== Aeropuertos: el menú del sitio, sobre aeródromos reales de las hojas JOG ===== */
const AEROS=[
 {id:"a-textos",nombre:"Textos",oaci:"MROC",aero:"Juan Santamaría",lugar:"Alajuela",lo:-84.2088,la:9.9939,link:"/textos/"},
 {id:"a-serie",nombre:"Serie MAP",oaci:"MRGP",aero:"Guápiles",lugar:"Pococí",lo:-83.797,la:10.2172,link:"/serie-map/"},
 {id:"a-podcast",nombre:"Podcast",oaci:"MRLB",aero:"Daniel Oduber",lugar:"Liberia",lo:-85.5444,la:10.5933,link:"/podcast/"},
 {id:"a-director",nombre:"Sobre el director",oaci:"MRTM",aero:"Tambor",lugar:"Península de Nicoya",lo:-85.0159,la:9.7389,link:"/sobre-el-director/"},
 {id:"a-contacto",nombre:"Contacto",oaci:"MRCH",aero:"Chacarita",lugar:"Puntarenas",lo:-84.7728,la:9.9814,link:"/contacto/"}
];
const AERO_SVG='<svg viewBox="-15 -27 30 42" width="30" height="42" aria-hidden="true"><path class="mastil" d="M0 -9V-26"/><path class="bandera" d="M0 -26L12 -22.2L0 -18.4Z"/><circle class="anillo" r="9"/><rect class="pista" x="-1.7" y="-7.2" width="3.4" height="14.4" transform="rotate(35)"/></svg>';
/* Voz del Dr. Arkady */
const AV={
 deteccion:t=>`${t.nueva?"Señal nueva":"Señal"} detectada en ${t.nombre}. Toque para sintonizar`,
 libre:"Gire el aro para cambiar el rumbo y buscar señales. Arrastre para volar",
 nube:"Zona sin cartografiar. Las nubes taparon la foto aérea",
 rumbo:"Rumbo aleatorio. El instrumento elige por usted"
};

/* ===== utilidades ===== */
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const app=$("#app"), mapa=$("#mapa"), lienzo=$("#lienzo");
const reduce=matchMedia("(prefers-reduced-motion: reduce)").matches;
const store={get(k,d){try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const lonDe=x=>CARTA.lon0+x/CARTA.w*(CARTA.lon1-CARTA.lon0);
const latDe=y=>CARTA.lat0+y/CARTA.h*(CARTA.lat1-CARTA.lat0);
T.forEach(t=>{t.x=(t.lo-CARTA.lon0)/(CARTA.lon1-CARTA.lon0)*CARTA.w; t.y=(CARTA.lat0-t.la)/(CARTA.lat0-CARTA.lat1)*CARTA.h;});
const gms=(v,h)=>{const a=Math.abs(v),g=Math.floor(a),m=Math.round((a-g)*60);const mm=m===60?0:m,gg=m===60?g+1:g;return String(gg).padStart(2,"0")+"°"+String(mm).padStart(2,"0")+"'"+h};
const frecDe=x=>Math.round(240+clamp(x/CARTA.w,0,1)*(535-240));
T.forEach(t=>{t.frec=frecDe(t.x);t.lat=gms(latDe(t.y),"N");t.lon=gms(lonDe(t.x),"W")});
/* ===== señales nuevas: fecha de publicación del texto o de llegada a la carta; 30 días con chip «Nueva» ===== */
const NUEVA_DIAS=30, FECHAS={
 "la-barra":"2025-10-26", "traccion-humana":"2025-10-22",
 "estacion-arkadi":["2026-05-13","2026-06-22","2026-07-12","2026-07-31","2026-08-10","2026-09-15"],
 "letra":["2026-10-30","2026-10-31","2026-10-31","2026-10-31","2026-10-31","2026-10-31","2026-10-31","2026-10-31","2026-10-31"]
};
const esNueva=f=>!!f&&(Date.now()-Date.parse(f+"T12:00:00-06:00"))/864e5<=NUEVA_DIAS;
T.forEach(t=>{const F=FECHAS[t.id];
  if(t.bit){t.bit.forEach((b,i)=>{b.fecha=F&&F[i];b.nueva=esNueva(b.fecha)});t.nueva=t.bit.some(b=>b.nueva);const u=t.bit.map(b=>b.nueva).lastIndexOf(true);if(u>=0)t.b=u+1;}
  else{t.fecha=F;t.nueva=esNueva(F);}});

AEROS.forEach(a=>{a.x=(a.lo-CARTA.lon0)/(CARTA.lon1-CARTA.lon0)*CARTA.w; a.y=(CARTA.lat0-a.la)/(CARTA.lat0-CARTA.lat1)*CARTA.h;});

/* ===== audio: Web Audio, todo arranca con el interruptor ===== */
const A={ctx:null,master:null,estatica:null,estGain:null,bufs:{},on:true,fuente:null,ini:0,dur:0};
const SON={clack:"/wp-content/uploads/2026/carta/assets/sonidos/clack.mp3",corta:"/wp-content/uploads/2026/carta/assets/sonidos/estatica-corta.mp3",larga:"/wp-content/uploads/2026/carta/assets/sonidos/estatica-larga.mp3",sintonia:"/wp-content/uploads/2026/carta/assets/sonidos/sintonia.mp3",perillas:"/wp-content/uploads/2026/carta/assets/sonidos/perillas.mp3",nubes:"/wp-content/uploads/2026/carta/assets/sonidos/nubes.mp3"};
const crudos={};
Object.entries(SON).forEach(([k,u])=>{crudos[k]=fetch(u).then(r=>r.arrayBuffer()).catch(()=>null)});
async function buf(k,u){
  if(A.bufs[k]) return A.bufs[k];
  const ab=await (crudos[k]||fetch(u).then(r=>r.arrayBuffer()));
  if(!ab||!A.ctx) return null;
  try{A.bufs[k]=await A.ctx.decodeAudioData(ab.slice(0));}catch(e){return null}
  return A.bufs[k];
}
function iniciarAudio(){
  if(A.ctx) return;
  const C=window.AudioContext||window.webkitAudioContext; if(!C) return;
  A.ctx=new C(); A.master=A.ctx.createGain(); A.master.gain.value=1; A.master.connect(A.ctx.destination);
  // estática continua generada: ruido filtrado con chasquidos; no se repite ni pesa
  const n=A.ctx.sampleRate*2, b=A.ctx.createBuffer(1,n,A.ctx.sampleRate), d=b.getChannelData(0);
  for(let i=0;i<n;i++){d[i]=(Math.random()*2-1)*.5; if(Math.random()<.0004){const L=40+Math.random()*200;for(let j=0;j<L&&i+j<n;j++)d[i+j]+=(Math.random()*2-1)*.9*(1-j/L)}}
  const src=A.ctx.createBufferSource(); src.buffer=b; src.loop=true;
  const bp=A.ctx.createBiquadFilter(); bp.type="bandpass"; bp.frequency.value=2200; bp.Q.value=.6;
  A.estGain=A.ctx.createGain(); A.estGain.gain.value=0;
  src.connect(bp).connect(A.estGain).connect(A.master); src.start();
  A.estatica=src;
}
function sonar(k,vol=1,u){
  if(!A.ctx||!A.on) return;
  buf(k,u||SON[k]).then(b=>{if(!b||!A.on)return;const s=A.ctx.createBufferSource(),g=A.ctx.createGain();g.gain.value=vol;s.buffer=b;s.connect(g).connect(A.master);s.start();});
}
function nivelEstatica(v,t=.3){if(!A.ctx)return;const g=A.estGain.gain;g.cancelScheduledValues(A.ctx.currentTime);g.setTargetAtTime(A.on?v:0,A.ctx.currentTime,t/3)}
function pararSenal(){if(A.fuente){try{A.fuente.stop()}catch(e){}A.fuente=null}}
async function tocarSenal(t,desde=0){
  pararSenal(); A.pausa=false; A.cargando=true; estadoPlay();
  if(!A.ctx){A.cargando=false;estadoPlay();return;}
  const b=await buf("s-"+pista(t),`/wp-content/uploads/2026/carta/assets/senales/${pista(t)}.mp3`);
  A.cargando=false;
  if(!b||S.activa!==t||A.pausa){estadoPlay();return;}
  desde=desde>0&&desde<b.duration-.2?desde:0;
  const s=A.ctx.createBufferSource(), g=A.ctx.createGain(); g.gain.value=A.on?1:0;
  s.buffer=b; s.connect(g).connect(A.master); s.start(0,desde); A.fuente=s; A.fuenteGain=g; A.ini=A.ctx.currentTime-desde; A.dur=b.duration;
  s.onended=()=>{if(A.fuente===s){A.fuente=null;A.pos=0;nivelEstatica(0,1);estadoPlay()}};
  estadoPlay();
}
/* play / pausa de la ficha */
function estadoPlay(){const b=document.querySelector("#ficha .ficha-play");if(!b)return;const suena=!A.pausa&&(!!A.fuente||!!A.cargando);
  b.dataset.estado=suena?"suena":"quieta";b.setAttribute("aria-label",suena?"Pausar":"Escuchar");}
function alternarPlay(t){
  if(!A.ctx&&typeof iniciarAudio==="function") iniciarAudio();
  if(A.fuente||A.cargando){ A.pos=A.fuente?A.ctx.currentTime-A.ini:0; pararSenal(); A.pausa=true; A.cargando=false; nivelEstatica(0,.3); estadoPlay(); }
  else { nivelEstatica(0,.3); tocarSenal(t,A.pos||0); }
}

/* ===== estado ===== */
const S={rumbo:0,alineada:null,guia:null,cx:0,cy:0,r:150,vw:0,vh:0,fase:"portada",activa:null,oidas:new Set(store.get("map27.oidas",[])),visto:store.get("map27.visto",false),aguja:0,marc:0};

/* ===== la escena: carta sobre el relieve real (Copernicus DEM 90 m) ===== */
if(!window.THREE){location.replace("/wp-content/uploads/2026/carta/plana.html"+location.search);return}
let renderer;
/* marca contra cierres (iPhone): si la carga anterior del 3D se cayó sin cerrar la página, esta vez va la plana */
{let caida=false;try{caida=sessionStorage.getItem("map27.3d")==="cargando"}catch(e){}
 if(caida){try{sessionStorage.removeItem("map27.3d")}catch(e){}location.replace("/wp-content/uploads/2026/carta/plana.html"+location.search);return}
 try{sessionStorage.setItem("map27.3d","cargando")}catch(e){}
 addEventListener("pagehide",()=>{try{sessionStorage.removeItem("map27.3d")}catch(e){}});}
try{renderer=new THREE.WebGLRenderer({antialias:true});}catch(e){location.replace("/wp-content/uploads/2026/carta/plana.html"+location.search);return}
renderer.domElement.addEventListener("webglcontextlost",e=>{e.preventDefault();location.replace("/wp-content/uploads/2026/carta/plana.html"+location.search)});
const movil=Math.min(innerWidth,innerHeight)<700;
renderer.setPixelRatio(Math.min(devicePixelRatio,movil?1.5:2));
renderer.outputEncoding=THREE.sRGBEncoding;
mapa.prepend(renderer.domElement);
const escena=new THREE.Scene(); escena.background=new THREE.Color(0x1b1d1c); escena.fog=new THREE.Fog(0x1b1d1c,90,320);
const camara=new THREE.PerspectiveCamera(45,1,.1,900);
escena.add(new THREE.AmbientLight(0xffffff,.62));
const sol=new THREE.DirectionalLight(0xfff3e0,.62); sol.position.set(-40,45,-30); escena.add(sol);
const KX=59.4, KZ=60, WD=3*KX, HD=2*KZ, EXAG=2.6;   // unidades por grado: igual que la escala de las hojas
const aMundo=(x,y)=>({x:(x/CARTA.w-.5)*WD,z:(y/CARTA.h-.5)*HD});
const aCarta=(X,Z)=>({x:(X/WD+.5)*CARTA.w,y:(Z/HD+.5)*CARTA.h});
T.forEach(t=>{t.w=aMundo(t.x,t.y)}); AEROS.forEach(a=>{a.w=aMundo(a.x,a.y)});
let alt=null,aw=0,ah=0;
function alturaEn(X,Z){ if(!alt) return 0; const u=clamp((X/WD+.5)*(aw-1),0,aw-1), v=clamp((Z/HD+.5)*(ah-1),0,ah-1);
  const x0=Math.floor(u),y0=Math.floor(v),x1=Math.min(aw-1,x0+1),y1=Math.min(ah-1,y0+1),fx=u-x0,fy=v-y0,g=(x,y)=>alt[y*aw+x];
  return ((g(x0,y0)*(1-fx)+g(x1,y0)*fx)*(1-fy)+(g(x0,y1)*(1-fx)+g(x1,y1)*fx)*fy)/1640*EXAG; }
const cargarImg=src=>new Promise((ok,mal)=>{const i=new Image();i.onload=()=>ok(i);i.onerror=mal;i.src=src});
let avisarCarta=()=>{}; const cartaLista=new Promise(r=>{avisarCarta=r});
function cargarCarta(){
  const tam=innerWidth>=760?2048:1280, maxTex=renderer.capabilities.maxTextureSize;
  const reg=(innerWidth>=760&&maxTex>=4096)?"region-4096":"region-2048";
  const HOJAS=[["liberia",0,0],["alajuela",1,0],["puntarenas",0,1],["sanjose",1,1]];
  Promise.all([cargarImg("/wp-content/uploads/2026/carta/assets/carta/relieve-4h.png"),cargarImg(`/wp-content/uploads/2026/carta/assets/carta/${reg}.jpg`),...HOJAS.map(([n])=>cargarImg(`/wp-content/uploads/2026/carta/assets/carta/hoja-${n}-${tam}.jpg`))]).then(([rel,region,...imgs])=>{
    const c=document.createElement("canvas");aw=c.width=rel.width;ah=c.height=rel.height;const g=c.getContext("2d");g.drawImage(rel,0,0);
    const d=g.getImageData(0,0,aw,ah).data; const a=new Float32Array(aw*ah); for(let i=0;i<aw*ah;i++) a[i]=(d[i*4]*256+d[i*4+1])/65535*3800; alt=a;
    const tex=img=>{const t=new THREE.Texture(img);t.encoding=THREE.sRGBEncoding;t.anisotropy=renderer.capabilities.getMaxAnisotropy();t.needsUpdate=true;return t};
    // Centroamérica de fondo (Natural Earth): plana, un poco por debajo de las hojas
    const rw=11*KX, rh=7*KZ, base=new THREE.Mesh(new THREE.PlaneGeometry(rw,rh),new THREE.MeshLambertMaterial({map:tex(region)}));
    base.rotation.x=-Math.PI/2; base.position.set((-82.5+84.5)*KX,-.35,-(10-10)*KZ); escena.add(base);
    // el pliego de papel bajo las cuatro hojas
    const canto=new THREE.Mesh(new THREE.BoxGeometry(WD+1.2,.3,HD+1.2),new THREE.MeshLambertMaterial({color:0xe6e0cf})); canto.position.y=-.17; escena.add(canto);
    // las cuatro hojas sobre el relieve real
    const segX=movil?110:160, segY=Math.round(segX*(HD/2)/(WD/2));
    HOJAS.forEach(([n,col,fil],k)=>{
      const geo=new THREE.PlaneGeometry(WD/2,HD/2,segX,segY); geo.rotateX(-Math.PI/2); geo.translate((col-.5)*WD/2,0,(fil-.5)*HD/2);
      const p=geo.attributes.position; for(let i=0;i<p.count;i++) p.setY(i,alturaEn(p.getX(i),p.getZ(i))); geo.computeVertexNormals();
      escena.add(new THREE.Mesh(geo,new THREE.MeshLambertMaterial({map:tex(imgs[k])})));
    });
    nubes(); avisarCarta(); try{sessionStorage.removeItem("map27.3d")}catch(e){}
  }).catch(()=>location.replace("/wp-content/uploads/2026/carta/plana.html"+location.search));
}
// nubes reales sobre las zonas sin cartografiar
function nubes(){
  const c=document.createElement("canvas");c.width=c.height=128;const g=c.getContext("2d");const gr=g.createRadialGradient(64,64,4,64,64,62);
  gr.addColorStop(0,"rgba(255,255,255,.95)");gr.addColorStop(.5,"rgba(255,255,255,.45)");gr.addColorStop(1,"rgba(255,255,255,0)");g.fillStyle=gr;g.fillRect(0,0,128,128);
  const tx=new THREE.CanvasTexture(c);
  T.filter(t=>t.tipo==="nubes").forEach(t=>{t.puffs=[];for(let i=0;i<9;i++){const s=new THREE.Sprite(new THREE.SpriteMaterial({map:tx,transparent:true,opacity:.5+Math.random()*.25,depthWrite:false}));
    const sc=3+Math.random()*4;s.scale.set(sc*1.6,sc,1);s.position.set(t.w.x+(Math.random()-.5)*7,alturaEn(t.w.x,t.w.z)+4.5+Math.random()*2.2,t.w.z+(Math.random()-.5)*5);s.userData.f=Math.random()*6;escena.add(s);t.puffs.push(s)}});
}

/* ===== cámara de vuelo: objetivo sobre la carta, distancia, inclinación y rumbo ===== */
const V={tx:0,tz:0,d:200,p:78};
function aplicarCam(){
  const p=V.p*Math.PI/180,h=-S.rumbo*Math.PI/180, ty=alturaEn(V.tx,V.tz);
  camara.position.set(V.tx+Math.sin(h)*Math.cos(p)*V.d, ty+Math.sin(p)*V.d, V.tz+Math.cos(h)*Math.cos(p)*V.d);
  camara.lookAt(V.tx,ty,V.tz);
  const c=aCarta(V.tx,V.tz); S.x=c.x; S.y=c.y;
  $("#lat").textContent=gms(latDe(c.y),"N"); $("#lon").textContent=gms(lonDe(c.x),"W"); $("#frec").textContent=frecDe(c.x)+" kHz";
  $("#alt").textContent=(Math.round(V.d*1640*3.28/EXAG*Math.sin(p)/100)*100).toLocaleString("es-CR")+" ft";
}
const ease=t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;
let vuelo=null;
function volarA(dest,ms){
  if(vuelo) vuelo.fin(false);
  return new Promise(res=>{
    const o={tx:V.tx,tz:V.tz,d:V.d,p:V.p,r:S.rumbo}, arco=Math.max(o.d,dest.d)*1.45, t0=performance.now(), dur=reduce?1:ms;
    const dr=((dest.rumbo-o.r+540)%360)-180;
    vuelo={paso:now=>{const k=Math.min(1,(now-t0)/dur),q=ease(k);
      V.tx=o.tx+(dest.tx-o.tx)*q; V.tz=o.tz+(dest.tz-o.tz)*q; S.rumbo=o.r+dr*q; V.p=o.p+(dest.p-o.p)*q;
      V.d=(o.d+(dest.d-o.d)*q)+Math.sin(Math.PI*q)*(arco-Math.max(o.d,dest.d))*.6;
      if(k>=1) vuelo.fin(true)},
      fin:ok=>{vuelo=null;res(ok)}};
  });
}
const rumboHacia=(x0,y0,x1,y1)=>Math.atan2(x1-x0,-(y1-y0))*180/Math.PI;

/* ===== marcas proyectadas sobre el relieve ===== */
function montarMarcas(){
  T.forEach(t=>{
    const b=document.createElement("button");
    b.type="button"; b.className="marca"+(t.tipo==="nubes"?" nube":"")+(t.estacion?" estacion":"")+(t.bastardos?" bastardos":"")+(t.nueva?" nueva":""); b.dataset.id=t.id; b.dataset.dormida="true";
    b.style.setProperty("--d",(-Math.random()*2.8).toFixed(2)+"s");
    b.setAttribute("aria-label",`${t.nombre}, ${t.lugar}. ${t.tipo==="nubes"?"Zona de nubes":"Sintonizar señal"}`);
    b.innerHTML=`<span class="onda"></span><span class="onda b"></span><span class="punto"></span><span class="rotulo">${t.nombre}${t.nueva?'<em class="chip-nueva">Nueva</em>':""}<small>${t.tipo==="nubes"?"nubes · sin cartografiar":t.frec+" kHz"}</small></span>`;
    b.addEventListener("click",()=>sintonizar(t));
    lienzo.appendChild(b); t.el=b;
    if(S.oidas.has(t.id)) b.classList.add("oida");
  });
}
function montarAeros(){
  AEROS.forEach(a=>{
    const b=document.createElement("a");
    b.className="aero"; b.href=a.link; b.dataset.id=a.id; b.dataset.dormida="true";
    b.setAttribute("aria-label",`Aeropuerto ${a.aero}, ${a.lugar}: ir a ${a.nombre}`);
    b.innerHTML=AERO_SVG+`<span class="placa">${a.nombre}<small>${a.oaci} · ${a.aero}</small></span>`;
    b.addEventListener("click",e=>{e.preventDefault();aterrizar(a)});
    lienzo.appendChild(b); a.el=b;
  });
}
function despertarAeros(){AEROS.forEach((a,i)=>setTimeout(()=>{a.el.dataset.dormida="false";a.el.classList.add("viva")},reduce?0:300+i*120))}
function dormirAeros(){AEROS.forEach(a=>{a.el.classList.remove("viva");a.el.dataset.dormida="true"})}
async function aterrizar(a){
  if(S.fase==="portada"||S.fase==="collage"||S.fase==="reveal") return;
  if($("#ficha").classList.contains("abierta")) cerrarFicha();
  pararSenal(); nivelEstatica(0,.2); sonar("perillas",.5);
  aviso(`Aproximación a ${a.oaci} · ${a.aero}. Aterrizando en ${a.nombre}`,true,6000);
  if(vuelo) vuelo.fin(false);
  await Promise.race([volarA({tx:a.w.x,tz:a.w.z,d:9,p:32,rumbo:S.rumbo},reduce?1:1700),new Promise(r=>setTimeout(r,reduce?0:2100))]);
  location.href=a.link;
}
const v3=new THREE.Vector3();
function proyectar(){
  AEROS.forEach(a=>{
    v3.set(a.w.x,alturaEn(a.w.x,a.w.z)+.35,a.w.z); const dist=camara.position.distanceTo(v3); v3.project(camara);
    const x=(v3.x*.5+.5)*S.vw, y=(-v3.y*.5+.5)*S.vh;
    if(v3.z>1||v3.x<-1.15||v3.x>1.15||v3.y<-1.15||v3.y>1.15){a.el.style.visibility="hidden";return}
    a.el.style.visibility=""; const sc=clamp(34/dist,.8,1.2);
    a.el.style.transform=`translate(${x.toFixed(1)}px,${y.toFixed(1)}px) translate(-50%,-26px) scale(${sc.toFixed(2)})`;
    a.el.style.zIndex=String(1000-Math.round(dist));
  });
  T.forEach(t=>{
    v3.set(t.w.x,alturaEn(t.w.x,t.w.z)+.35,t.w.z); const dist=camara.position.distanceTo(v3); v3.project(camara);
    t.sx=(v3.x*.5+.5)*S.vw; t.sy=(-v3.y*.5+.5)*S.vh;
    const fuera=v3.z>1||v3.x<-1.15||v3.x>1.15||v3.y<-1.15||v3.y>1.15;
    if(fuera){t.el.style.visibility="hidden";return}
    t.el.style.visibility=""; const sc=clamp(30/dist,.55,1.2);
    t.el.style.transform=`translate(${t.sx.toFixed(1)}px,${t.sy.toFixed(1)}px) translate(-50%,-11px) scale(${sc.toFixed(2)})`;
    t.el.style.zIndex=String(1000-Math.round(dist));
  });
}
function aPantalla(t){return {x:t.sx??S.vw/2,y:t.sy??S.vh/2}}
/* ===== geometría de la cabina: el radiogoniómetro abajo, el parabrisas libre ===== */
function medir(){
  S.vw=app.clientWidth; S.vh=app.clientHeight;
  renderer.setSize(S.vw,S.vh,false); camara.aspect=S.vw/S.vh; camara.updateProjectionMatrix();
  const ancho=S.vw>=760, inf=($("#tablero").offsetHeight||150);
  S.r=ancho?Math.min(S.vw*.15,175):Math.min(S.vw*.4,160);
  S.cx=S.vw/2; S.cy=S.vh-inf+S.r*.18;
  const ins=$("#instrumento"), lado=S.r*2*(130/104);
  ins.style.width=ins.style.height=lado+"px"; ins.style.left=(S.cx-lado/2)+"px"; ins.style.top=(S.cy-lado/2)+"px";
  $("#aviso").style.top=Math.max(96,S.cy-S.r*1.32-44)+"px";
}

/* ===== bucle: vuelo, aguja ADF, lámparas y marcas ===== */
let segs=[];
function bucle(now){
  if(vuelo) vuelo.paso(now);
  if(S.fase==="portada") S.rumbo+=.03;   // la carta gira despacio bajo la portada
  aplicarCam();
  T.forEach(t=>{if(t.puffs)t.puffs.forEach(s=>{s.position.x+=Math.sin(now/4000+s.userData.f)*.004})});
  renderer.render(escena,camara); proyectar();
  const temblor=S.arrastrandoAro?0:(Math.sin(now/370)+Math.sin(now/113))*.5;
  let k=0, guia=null;
  if(S.fase==="espera"&&S.objetivo){ guia=S.objetivo; k=.5; }
  else if(S.fase==="libre"&&!vuelo){ const r=antena(); k=r.k; guia=r.guia; }
  // la aguja ADF apunta a la señal relativa al rumbo; la carátula gira con el rumbo
  let ang=0;
  if(guia){const dx=guia.x-S.x,dy=guia.y-S.y; if(Math.hypot(dx,dy)>30) ang=rumboHacia(S.x,S.y,guia.x,guia.y)-S.rumbo;}
  const dif=((ang-S.aguja+540)%360)-180; S.aguja+=dif*.12;
  const ag=document.getElementById("aguja"), ro=document.getElementById("rotor");
  if(ag) ag.setAttribute("transform",`rotate(${(S.aguja+temblor).toFixed(2)})`);
  if(ro) ro.setAttribute("transform",`rotate(${(-S.rumbo).toFixed(2)})`);
  S.marc=((Math.round(S.rumbo)%360)+360)%360; $("#marc").textContent=String(S.marc).padStart(3,"0")+"°";
  const n=Math.round(k*9);
  segs.forEach((s,i)=>s.setAttribute("fill",i<n?(i>6?"#c6361f":"#e9a23b"):"#3a2a14"));
  // la estática solo vive mientras alguien busca: girar el aro o mover la carta; en reposo se apaga
  if(A.ctx&&!A.fuente&&S.fase==="libre"){const busca=performance.now()-(S.ultimoMov||0)<2500;nivelEstatica(busca?.015+.05*(1-k):0,busca?.8:2.5)}
  if(A.fuente&&A.dur){const p=clamp((A.ctx.currentTime-A.ini)/A.dur,0,1);const ll=$("#ficha .lleno");if(ll)ll.style.width=(p*100)+"%";const tt=$("#ficha .tiempo");if(tt)tt.textContent=fmt(A.ctx.currentTime-A.ini)+" / "+fmt(A.dur);}
  requestAnimationFrame(bucle);
}
/* ===== antena: lo que queda de frente a la nariz es lo que se sintoniza ===== */
const angDif=(a,b)=>Math.abs(((a-b+540)%360)-180);
function antena(){
  const muda=A.fuente||$("#ficha").classList.contains("abierta");
  let best=null,bk=0,bdf=99,cerca=null,dc=Infinity;
  T.forEach(t=>{
    const dx=t.x-S.x,dy=t.y-S.y,d=Math.hypot(dx,dy); if(d<60||d>2800) return;
    if(t.tipo==="senal"&&d<dc){dc=d;cerca=t}
    const df=angDif(rumboHacia(S.x,S.y,t.x,t.y),S.rumbo); if(df>25) return;
    const kk=(1-df/25)*clamp(1.35-d/2000,.3,1); if(kk>bk){bk=kk;best=t;bdf=df}
  });
  const guia=best||cerca;
  if(muda){ if(S.alineada){S.alineada.el.classList.remove("detectada");S.alineada=null} leve(null); return {k:0,guia}; }
  const fija=(best&&bdf<(best===S.alineada?10:7))?best:null;
  if(fija!==S.alineada){
    if(S.alineada) S.alineada.el.classList.remove("detectada");
    S.alineada=fija;
    if(fija){fija.el.classList.add("detectada");bip(fija.tipo==="nubes");const g=String(S.marc).padStart(3,"0");
      aviso(fija.tipo==="nubes"?`Eco a ${g}°: ${fija.nombre}. Zona de nubes`:`Señal a ${g}°: ${fija.nombre}. Toque la marca`,true,5000);}
  }
  leve(best,bk*bk);
  return {k:bk,guia};
}
/* ===== el aro: girarlo es girar la nave ===== */
function aro(){
  const hit=document.getElementById("aro-hit"); let st=null, ult=0;
  const angDe=e=>{const r=$("#instrumento").getBoundingClientRect();return Math.atan2(e.clientX-(r.left+r.width/2),-(e.clientY-(r.top+r.height/2)))*180/Math.PI};
  hit.addEventListener("pointerdown",e=>{
    if(S.fase!=="libre"&&S.fase!=="espera") return; e.preventDefault(); e.stopPropagation();
    try{hit.setPointerCapture(e.pointerId)}catch(_){}
    if(vuelo) vuelo.fin(false);
    if($("#ficha").classList.contains("abierta")) cerrarFicha();
    if(S.fase==="espera"){S.fase="libre";S.objetivo.el.classList.remove("detectada");despertarTodo()}
    $("#rumbo").classList.remove("llamado");
    st={id:e.pointerId,a:angDe(e)}; ult=Math.round(S.rumbo/10); S.arrastrandoAro=true; hit.style.cursor="grabbing";
  });
  // la carátula y el mundo siguen al dedo: girar a la derecha gira la carta a la derecha
  hit.addEventListener("pointermove",e=>{if(!st||e.pointerId!==st.id)return;const a=angDe(e);const d=((a-st.a+540)%360)-180;st.a=a;S.rumbo-=d;S.ultimoMov=performance.now();const m=Math.round(S.rumbo/10);if(m!==ult){ult=m;tic()}});
  const fin=e=>{if(!st||e.pointerId!==st.id)return;st=null;S.arrastrandoAro=false;hit.style.cursor="grab"};
  hit.addEventListener("pointerup",fin); hit.addEventListener("pointercancel",fin);
  window.addEventListener("keydown",e=>{if(S.fase!=="libre"||document.querySelector(".pliego:not([hidden])"))return;if(e.key==="["||e.key==="]"){if($("#ficha").classList.contains("abierta"))cerrarFicha();S.rumbo+=e.key==="]"?5:-5;S.ultimoMov=performance.now();tic()}});
}
const fmt=s=>{s=Math.max(0,s);return "0:"+String(Math.floor(s)).padStart(2,"0")};

/* ===== volar con la mano: arrastrar avanza, rueda o pellizco sube y baja ===== */
function arrastre(){
  const cv=renderer.domElement, toques=new Map();
  const activo=()=>S.fase==="libre"||S.fase==="espera";
  cv.addEventListener("pointerdown",e=>{if(!activo())return;cv.setPointerCapture(e.pointerId);toques.set(e.pointerId,{x:e.clientX,y:e.clientY});cv.classList.add("arrastrando");if(vuelo)vuelo.fin(false)});
  cv.addEventListener("pointermove",e=>{
    const p=toques.get(e.pointerId); if(!p) return;
    if(toques.size===2){const [a,b]=[...toques.values()];const d0=Math.hypot(a.x-b.x,a.y-b.y);p.x=e.clientX;p.y=e.clientY;const [c,d]=[...toques.values()];const d1=Math.hypot(c.x-d.x,c.y-d.y);if(d0>0&&d1>0){V.d=clamp(V.d*d0/d1,6,120);V.p=clamp(24+(V.d-4)*.45,24,78)}return}
    const dx=e.clientX-p.x,dy=e.clientY-p.y;p.x=e.clientX;p.y=e.clientY;S.ultimoMov=performance.now();
    const k=V.d*.0016, h=-S.rumbo*Math.PI/180;
    V.tx=clamp(V.tx+(-Math.cos(h)*dx-Math.sin(h)*dy)*k,-WD/2,WD/2); V.tz=clamp(V.tz+(Math.sin(h)*dx-Math.cos(h)*dy)*k,-HD/2,HD/2);
  });
  const soltar=e=>{toques.delete(e.pointerId);if(!toques.size)cv.classList.remove("arrastrando")};
  cv.addEventListener("pointerup",soltar); cv.addEventListener("pointercancel",soltar);
  cv.addEventListener("wheel",e=>{if(!activo())return;e.preventDefault();S.ultimoMov=performance.now();if(vuelo)vuelo.fin(false);V.d=clamp(V.d*Math.exp(e.deltaY*.0012),6,120);V.p=clamp(24+(V.d-4)*.45,24,78)},{passive:false});
  window.addEventListener("keydown",e=>{
    if(!activo()||document.querySelector(".pliego:not([hidden])")) return;
    const m={ArrowUp:[0,1],ArrowDown:[0,-1],ArrowLeft:[-1,0],ArrowRight:[1,0]}[e.key]; if(!m) return; e.preventDefault();
    const h=-S.rumbo*Math.PI/180, k=V.d*.04; V.tx+=(Math.cos(h)*m[0]-Math.sin(h)*m[1])*k; V.tz+=(-Math.sin(h)*m[0]-Math.cos(h)*m[1])*k;
  });
}

/* ===== aviso de Arkady (máquina de escribir) ===== */
let avisoT=0,avisoH=0;
function aviso(txt,alerta,dur=4500){
  const el=$("#aviso"); clearInterval(avisoT); clearTimeout(avisoH); el.classList.toggle("alerta",!!alerta); el.classList.remove("oculto");
  if(dur) avisoH=setTimeout(()=>el.classList.add("oculto"),dur);
  if(reduce){el.textContent=txt;return}
  let i=0; el.innerHTML='<span class="cursor">▌</span>';
  avisoT=setInterval(()=>{i++;el.innerHTML=txt.slice(0,i)+'<span class="cursor">▌</span>';if(i>=txt.length){clearInterval(avisoT)}},22);
}

/* ===== sintonizar: subir, girar y posarse sobre la señal ===== */
async function sintonizar(t){
  if(S.fase==="portada"||S.fase==="collage"||S.fase==="reveal") return;
  if(S.fase==="espera"&&t!==S.objetivo) return;
  const venia=S.fase;
  S.activa=t; S.objetivo=null; leve(null); if(S.alineada){S.alineada.el.classList.remove("detectada");S.alineada=null} cerrarFicha(true);
  T.forEach(o=>o.el.classList.remove("detectada"));
  pararSenal();
  if(t.tipo==="nubes"){ sonar("nubes",.9); nivelEstatica(.05,.3); aviso(AV.nube); }
  else { sonar("sintonia",.7); nivelEstatica(.09,.2); }
  if(venia==="espera"){ S.fase="libre"; despertarTodo(); }
  const lejos=Math.hypot(t.x-S.x,t.y-S.y), r=lejos>120?rumboHacia(S.x,S.y,t.x,t.y):S.rumbo;
  const llego=await volarA({tx:t.w.x,tz:t.w.z,d:t.tipo==="nubes"?26:16,p:t.tipo==="nubes"?40:30,rumbo:r},clamp(1300+lejos*.9,1300,3000));
  if(!llego||S.activa!==t) return;
  abrirFicha(t);
  if(t.tipo==="senal"){ nivelEstatica(0,.4); tocarSenal(t); marcarBitacora(t); S.oidas.add(t.id); store.set("map27.oidas",[...S.oidas]); t.el.classList.add("oida"); }
}
function despertarTodo(){
  T.forEach((o,i)=>setTimeout(()=>{o.el.dataset.dormida="false";o.el.classList.add("viva")},reduce?0:i*90));
  despertarAeros();
  if(!S.dichoLibre){S.dichoLibre=true;setTimeout(()=>{$("#rumbo").classList.add("llamado");aviso(AV.libre)},reduce?0:1600);}
}

/* ===== construcción del dial ===== */
function dibujarDial(){
  const svg=$("#dial"), NS="http://www.w3.org/2000/svg";
  const el=(n,a,p=svg)=>{const e=document.createElementNS(NS,n);for(const k in a)e.setAttribute(k,a[k]);p.appendChild(e);return e};
  const defs=el("defs",{});
    const m=el("mask",{id:"aro"},defs); el("rect",{x:"-140",y:"-140",width:"280",height:"280",fill:"#fff"},m); el("circle",{cx:"0",cy:"0",r:"84",fill:"#000"},m);
  // retícula exterior: como el sello MAP
  [["-128","0","-104","0"],["104","0","128","0"],["0","-128","0","-104"],["0","104","0","128"]].forEach(([a,b,c,d])=>el("line",{x1:a,y1:b,x2:c,y2:d,stroke:"#1b1d1b","stroke-width":"1.2"}));
  el("circle",{cx:"0",cy:"0",r:"112",fill:"none",stroke:"#1b1d1b","stroke-width":".8","stroke-dasharray":"2.5 2.5"});
  // bisel martillado y carátula crema
  el("circle",{cx:"0",cy:"0",r:"104",fill:"#9a9f9c",mask:"url(#aro)",stroke:"#5b605d","stroke-width":"1.5"});
  el("circle",{cx:"0",cy:"0",r:"99",fill:"#ece5cf",mask:"url(#aro)"});
  el("circle",{cx:"0",cy:"0",r:"84.5",fill:"none",stroke:"#1b1d1b","stroke-width":"1.6"});
  el("circle",{cx:"0",cy:"0",r:"99",fill:"none",stroke:"#1b1d1b","stroke-width":".8"});
  const rotor=el("g",{id:"rotor"});
  const esc=el("g",{"font-family":"IBM Plex Mono, monospace","font-size":"5.6","font-weight":"600",fill:"#1b1d1b","text-anchor":"middle"},rotor);
  for(let g=0;g<360;g+=2){
    const a=(g-90)*Math.PI/180, L=g%10===0?9:(g%5===0?6:4), r0=84.5, r1=r0+L;
    el("line",{x1:(Math.cos(a)*r0).toFixed(2),y1:(Math.sin(a)*r0).toFixed(2),x2:(Math.cos(a)*r1).toFixed(2),y2:(Math.sin(a)*r1).toFixed(2),stroke:"#1b1d1b","stroke-width":g%10===0?".9":".5"},esc);
    if(g%30===0){const rr=92.5;const t=el("text",{x:(Math.cos(a)*rr).toFixed(2),y:(Math.sin(a)*rr+2).toFixed(2),transform:`rotate(${g} ${(Math.cos(a)*rr).toFixed(2)} ${(Math.sin(a)*rr).toFixed(2)})`},esc);t.textContent=String(g).padStart(3,"0");}
  }
  // marca roja de referencia (como en el Sichtfunkpeiler)
  el("circle",{cx:"0",cy:"-80",r:"2.2",fill:"#c6361f"},rotor);
  // índice fijo: donde se lee la marcación
  el("path",{d:"M0,-104.5 L-3.6,-111 L3.6,-111 Z",fill:"#1b1d1b"});
  // cristal: retícula fina sobre la carta
  el("circle",{cx:"0",cy:"0",r:"84",fill:"rgba(236,229,207,.06)"});
  el("line",{x1:"-84",y1:"0",x2:"84",y2:"0",stroke:"rgba(27,29,27,.45)","stroke-width":".5"});
  el("line",{x1:"0",y1:"-84",x2:"0",y2:"84",stroke:"rgba(27,29,27,.45)","stroke-width":".5"});
  el("circle",{cx:"0",cy:"0",r:"42",fill:"none",stroke:"rgba(27,29,27,.4)","stroke-width":".5","stroke-dasharray":"1.5 2"});
  // aguja: línea de marcación que cruza el cristal
  const ag=el("g",{id:"aguja"});
  el("line",{x1:"0",y1:"80",x2:"0",y2:"-80",stroke:"#c6361f","stroke-width":"1.4","stroke-linecap":"round"},ag);
  el("path",{d:"M0,-82 L-3.2,-72 L3.2,-72 Z",fill:"#c6361f"},ag);
  el("circle",{cx:"0",cy:"0",r:"3.4",fill:"#1b1d1b"},ag);
  el("circle",{cx:"0",cy:"0",r:"1.3",fill:"#ece5cf"},ag);
  // intensidad: arco de lámparas bajo el dial
  const vu=el("g",{id:"vu"});
  for(let i=0;i<9;i++){const a=(22+i*5)*Math.PI/180; el("rect",{x:(Math.cos(a)*117-2).toFixed(2),y:(Math.sin(a)*117-2).toFixed(2),width:"4",height:"4",rx:"1",fill:"#3a2a14",class:"seg"},vu);}
  // zona de agarre del aro: girarlo es girar la antena
  const hit=el("circle",{id:"aro-hit",cx:"0",cy:"0",r:"95",fill:"none",stroke:"rgba(0,0,0,0)","stroke-width":"28"});
  hit.style.pointerEvents="stroke"; hit.style.cursor="grab"; hit.style.touchAction="none";
}

function bip(grave){
  if(!A.ctx||!A.on) return;
  const o=A.ctx.createOscillator(),g=A.ctx.createGain(),t=A.ctx.currentTime;
  o.type="sine";o.frequency.value=grave?420:880;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.18,t+.01);g.gain.setValueAtTime(.18,t+.07);g.gain.linearRampToValueAtTime(0,t+.09);
  o.connect(g).connect(A.master);o.start(t);o.stop(t+.12);
  if(!grave){const o2=A.ctx.createOscillator(),g2=A.ctx.createGain();o2.frequency.value=880;g2.gain.setValueAtTime(0,t+.14);g2.gain.linearRampToValueAtTime(.18,t+.15);g2.gain.setValueAtTime(.18,t+.21);g2.gain.linearRampToValueAtTime(0,t+.23);o2.connect(g2).connect(A.master);o2.start(t+.14);o2.stop(t+.26);}
}
async function leve(t,k=0){
  if(!A.ctx) return;
  const L=A.leve||(A.leve={t:null,src:null,g:null});
  if(t!==L.t){
    if(L.src){const g=L.g,s=L.src;g.gain.setTargetAtTime(0,A.ctx.currentTime,.08);setTimeout(()=>{try{s.stop()}catch(e){}},500)}
    L.t=t;L.src=null;L.g=null;
    if(!t) return;
    const key=t.tipo==="nubes"?"nubes":"s-"+pista(t), url=t.tipo==="nubes"?SON.nubes:`/wp-content/uploads/2026/carta/assets/senales/${pista(t)}.mp3`;
    const b=await buf(key,url); if(!b||L.t!==t) return;
    const s=A.ctx.createBufferSource(),lp=A.ctx.createBiquadFilter(),g=A.ctx.createGain();
    lp.type="lowpass";lp.frequency.value=1300;g.gain.value=0;s.buffer=b;s.loop=true;
    s.connect(lp).connect(g).connect(A.master);s.start(0,Math.random()*b.duration*.6);L.src=s;L.g=g;
  }
  if(L.g) L.g.gain.setTargetAtTime(A.on?k*.34:0,A.ctx.currentTime,.12);
}
let ticBuf=null;
function tic(){
  if(!A.ctx||!A.on) return;
  if(!ticBuf){const n=Math.floor(A.ctx.sampleRate*.014);ticBuf=A.ctx.createBuffer(1,n,A.ctx.sampleRate);const d=ticBuf.getChannelData(0);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/n,4);}
  const s=A.ctx.createBufferSource(),f=A.ctx.createBiquadFilter(),g=A.ctx.createGain();
  f.type="bandpass";f.frequency.value=3000;f.Q.value=2;g.gain.value=.55;s.buffer=ticBuf;s.connect(f).connect(g).connect(A.master);s.start();
}
/* ===== estación del Dr. Arkady: cambiar de bitácora sin salir de la ficha ===== */
const pista=t=>(t.archivo||t.id)+"-"+String(t.bit?(t.b||1):1).padStart(2,"0");
function marcarBitacora(t){ if(!t.bit) return; S.oidas.add(pista(t)); store.set("map27.oidas",[...S.oidas]);
  const bt=document.querySelector(`#ficha [data-bit="${t.b||1}"]`); if(bt) bt.classList.add("oida"); }
function cambiarBitacora(t,n){
  if(!t.bit||n===(t.b||1)&&A.fuente) return;
  t.b=n; const B=t.bit[n-1], f=$("#ficha"), num=String(n).padStart(2,"0");
  const img=f.querySelector(".ficha-foto img"); if(img){img.src=`/wp-content/uploads/2026/carta/assets/senales/${pista(t)}.jpg`;img.alt=B.alt;}
  const fr=f.querySelector(".frase"); if(fr) fr.textContent=B.frase;
  const ti=f.querySelector(".bit-titulo"); if(ti) ti.innerHTML=num+" · "+B.t+(B.ep?" · "+B.ep:"")+(B.nueva?'<em class="chip-nueva">Nueva</em>':"");
  const ab=f.querySelector(".ficha-acciones a"); if(ab) ab.href=B.link;
  f.querySelectorAll("[data-bit]").forEach(b=>b.setAttribute("aria-pressed",String(+b.dataset.bit===n)));
  const ll=f.querySelector(".lleno"); if(ll) ll.style.width="0%"; const tt=f.querySelector(".tiempo"); if(tt) tt.textContent="0:00";
  pararSenal(); sonar("sintonia",.5); nivelEstatica(.09,.15);
  setTimeout(()=>{ if(S.activa!==t||t.b!==n) return; nivelEstatica(0,.4); tocarSenal(t); marcarBitacora(t); },380);
}
/* ===== ficha movible: se arrastra desde la cabecera ===== */
const F={dx:0,dy:0};
function ponerF(f){f.style.setProperty("--dx",F.dx+"px");f.style.setProperty("--dy",F.dy+"px");}
function arrastreFicha(f){
  const cab=f.querySelector(".ficha-cab"); if(!cab) return;
  cab.addEventListener("pointerdown",e=>{
    if(e.button>0||e.target.closest("button,a")) return;
    e.preventDefault(); e.stopPropagation();
    const ancho=matchMedia("(min-width:760px)").matches, r=f.getBoundingClientRect(), R=(f.offsetParent||document.body).getBoundingClientRect();
    const hc=cab.getBoundingClientRect().bottom-r.top+10, x0=e.clientX, y0=e.clientY, dx0=F.dx, dy0=F.dy, top0=r.top-dy0;
    let movio=false; f.classList.add("arrastrando"); try{cab.setPointerCapture(e.pointerId)}catch(_){}
    const mover=ev=>{
      const dx=ev.clientX-x0, dy=ev.clientY-y0; if(Math.abs(dx)+Math.abs(dy)>5) movio=true; if(!movio) return;
      if(ancho){
        const L=clamp(r.left+dx,R.left-r.width+120,R.right-120), Tp=clamp(r.top+dy,R.top+6,R.bottom-hc);
        F.dx=dx0+(L-r.left); F.dy=dy0+(Tp-r.top);
      } else { F.dx=0; F.dy=clamp(dy0+dy,0,r.height-hc); }
      ponerF(f);
    };
    const soltar=()=>{
      cab.removeEventListener("pointermove",mover); cab.removeEventListener("pointerup",soltar); cab.removeEventListener("pointercancel",soltar);
      f.classList.remove("arrastrando");
      if(!ancho){ const max=r.height-hc; F.dy=movio?(F.dy>max/2?max:0):(F.dy>0?0:F.dy); ponerF(f); f.classList.toggle("plegada",F.dy>0); }
    };
    cab.addEventListener("pointermove",mover); cab.addEventListener("pointerup",soltar); cab.addEventListener("pointercancel",soltar);
  });
}
addEventListener("resize",()=>{F.dx=0;F.dy=0;const f=$("#ficha");if(f){ponerF(f);f.classList.remove("plegada")}});
/* ===== ficha ===== */
function abrirFicha(t){
  const f=$("#ficha");
  const cab=`<div class="ficha-cab" title="Arrastre para mover la ficha"><span class="asa" aria-hidden="true"></span><b>${t.nombre}${t.nueva&&!t.bit?'<em class="chip-nueva">Nueva</em>':""}</b><span class="coord">${t.lat} ${t.lon}${t.tipo==="senal"?" · "+t.frec+" kHz":""}</span><button class="ficha-x" type="button" data-cerrar aria-label="Cerrar la ficha"><svg viewBox="0 0 12 12" aria-hidden="true"><path d="M1 1L11 11M11 1L1 11"/></svg></button></div>`;
  if(t.tipo==="nubes"){
    f.innerHTML=cab+`<div class="ficha-cuerpo"><div class="nube-arte">NUBES</div><div class="ficha-texto"><h2>Zona sin cartografiar</h2><p class="sub">${t.sub} · ${t.lugar}</p>
      <p class="frase">Las nubes taparon la foto aérea. El territorio existe; todavía nadie lo registró.</p>
      <div class="ficha-acciones"><span class="btn vacio" style="border-style:dashed">Señal en preparación</span></div></div></div>`;
  } else {
    const B=t.bit?t.bit[(t.b||1)-1]:null, num=n=>String(n).padStart(2,"0");
    const selector=B?`<div class="bitacoras"><div class="fila" role="group" aria-label="Elegir ${(t.rot||"Bitácora").toLowerCase()}"><span class="rot">${t.rot||"Bitácora"}</span>${t.bit.map((b,i)=>`<button type="button" data-bit="${i+1}" aria-pressed="${i+1===(t.b||1)}" title="${b.t}" class="${S.oidas.has(t.id+"-"+num(i+1))?"oida":""}${b.nueva?" nueva":""}">${num(i+1)}</button>`).join("")}${Array.from({length:Math.max(0,(t.total||0)-t.bit.length)},(_,j)=>`<button type="button" class="futura" disabled title="Bitácora en preparación">${num(t.bit.length+j+1)}</button>`).join("")}</div><p class="bit-titulo">${num(t.b||1)} · ${B.t}${B.ep?" · "+B.ep:""}${B.nueva?'<em class="chip-nueva">Nueva</em>':""}</p></div>`:"";
    f.innerHTML=cab+`<div class="ficha-cuerpo"><div class="ficha-foto"><img src="/wp-content/uploads/2026/carta/assets/senales/${pista(t)}.jpg" alt="${B?B.alt:t.nombre+": imagen de la señal"}">${t.fotomontaje?'<span class="sello-foto">FOTOMONTAJE</span>':''}</div>
      <div class="ficha-texto"><h2>${t.nombre}</h2><p class="sub">${t.sub} · ${t.lugar}</p><p class="frase">${B?B.frase:t.frase}</p>${selector}
      <div class="medidor"><button class="ficha-play" type="button" data-estado="quieta" aria-label="Escuchar"><svg class="i-play" viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 1.2L11 6L2.5 10.8Z"/></svg><svg class="i-pausa" viewBox="0 0 12 12" aria-hidden="true"><path d="M2 1h3v10H2zM7 1h3v10H7z"/></svg></button><div class="medidor-wrap"><span class="fondo"></span><span class="lleno"></span></div><span class="tiempo">0:00</span></div>
      <div class="ficha-acciones"><a class="btn lleno" href="${B?B.link:t.link}" target="_blank" rel="noopener">Abrir</a></div></div></div>`;
    f.querySelector(".ficha-play").addEventListener("click",()=>alternarPlay(t));
    if(B) f.querySelectorAll("[data-bit]").forEach(b=>b.addEventListener("click",()=>cambiarBitacora(t,+b.dataset.bit)));
  }
  f.querySelector("[data-cerrar]").addEventListener("click",()=>{cerrarFicha();});
  f.classList.toggle("estacion",!!t.estacion); f.classList.toggle("retrato",!!t.retrato); f.classList.toggle("bastardos",!!t.bastardos); A.pos=0; estadoPlay(); arrastreFicha(f);
  if(!matchMedia("(min-width:760px)").matches){F.dy=0;f.classList.remove("plegada")} ponerF(f);
  requestAnimationFrame(()=>f.classList.add("abierta"));
}
function cerrarFicha(silencioso){
  const f=$("#ficha"); f.classList.remove("abierta");
  if(!silencioso){pararSenal(); S.activa=null; nivelEstatica(0,.5); $("#aviso").classList.add("oculto");}
}

/* ===== portada y collage ===== */
function escribirCoord(){
  const txt="09°56'N · 84°05'W · SAN JOSÉ, COSTA RICA", el=$("#coord-portada");
  if(reduce){el.textContent=txt;return}
  let i=0; const iv=setInterval(()=>{el.textContent=txt.slice(0,++i);if(i>=txt.length)clearInterval(iv)},45);
}
const clackEl=new Audio("/wp-content/uploads/2026/carta/assets/sonidos/clack.mp3"); clackEl.preload="auto";
function clack(){if(!A.on)return;try{clackEl.currentTime=0;const p=clackEl.play();if(p&&p.catch)p.catch(()=>{})}catch(e){}}
/* transmisión en clave Morse: "MAP CR" mientras se telegrafían las coordenadas */
const MORSE={M:"--",A:".-",P:".--.",C:"-.-.",R:".-."};
function transmitir(){
  const el=$("#coord-portada"), txt="09°56'N · 84°05'W · SAN JOSÉ, COSTA RICA", u=.055;
  const tonos=[]; let t=.15;
  "MAP CR".split(" ").forEach(w=>{[...w].forEach(ch=>{[...MORSE[ch]].forEach(sg=>{const d=sg==="."?u:3*u;tonos.push([t,d]);t+=d+u});t+=2*u});t+=4*u});
  const total=t;
  if(A.ctx&&A.on){
    const t0=A.ctx.currentTime, o=A.ctx.createOscillator(), g=A.ctx.createGain(), f=A.ctx.createBiquadFilter();
    o.type="square"; o.frequency.value=640; f.type="lowpass"; f.frequency.value=1800; g.gain.value=0;
    o.connect(f).connect(g).connect(A.master);
    tonos.forEach(([a,d])=>{g.gain.setValueAtTime(0,t0+a);g.gain.linearRampToValueAtTime(.075,t0+a+.006);g.gain.setValueAtTime(.075,t0+a+d-.006);g.gain.linearRampToValueAtTime(0,t0+a+d)});
    o.start(t0); o.stop(t0+total+.1);
  }
  // cada pulso suelta un pedazo del texto: la línea entra telegrafiada
  el.textContent="";
  const n=txt.length, por=n/tonos.length;
  tonos.forEach(([a],i)=>setTimeout(()=>{el.textContent=txt.slice(0,Math.round((i+1)*por))},a*1000));
  return new Promise(res=>setTimeout(()=>{el.textContent=txt;res()},total*1000+250));
}
async function encender(){
  if(S.fase!=="portada") return;
  clack();
  S.fase="collage";
  const sw=$("#encender"); sw.setAttribute("aria-checked","true");
  iniciarAudio(); if(A.ctx&&A.ctx.state==="suspended"){try{await A.ctx.resume()}catch(e){}}
  await transmitir();   // la Morse y el texto telegrafiado no son movimiento: suenan siempre
  $("#portada").classList.add("fuera"); collage();
}
function collage(){
  const lay=$("#collage"), saltar=$("#saltar");
  const largo=!S.visto;
  const piezas=largo?COLLAGE:COLLAGE.slice(0,6);
  // ritmo de montaje: arranca pausado y acelera (primera visita ~5,5 s; las siguientes ~1 s)
  const tiempos=[]; let acum=0;
  piezas.forEach((_,i)=>{tiempos.push(acum); const k=piezas.length>1?i/(piezas.length-1):0; acum+=largo?Math.round(440-270*k):130;});
  if(A.ctx){sonar("larga",.8); nivelEstatica(.12,.2); (largo?[250,1300,2400,3400,4300]:[200]).forEach(ms=>setTimeout(()=>sonar("perillas",.7),ms));}
  saltar.hidden=false;
  const els=[]; let fuera=false;
  const terminar=()=>{if(fuera)return;fuera=true;saltar.hidden=true;revelar(els)};
  saltar.onclick=terminar;
  piezas.forEach(([n,ter,tipo],i)=>setTimeout(()=>{
    if(fuera) return;
    const d=document.createElement("div"); d.className="pieza-c"+(tipo==="bn"?" bn":"");
    const w=Math.round(clamp(S.vw*((tipo==="v"?.38:.30)+Math.random()*.16),130,tipo==="v"?400:330));
    d.style.width=w+"px";
    if(tipo==="v"){d.innerHTML=`<video src="/wp-content/uploads/2026/carta/assets/collage/${n}.mp4" muted playsinline autoplay loop preload="auto"></video>`}
    else d.innerHTML=`<img src="/wp-content/uploads/2026/carta/assets/collage/${n}.jpg" alt="">`;
    d.insertAdjacentHTML("beforeend",`<span class="tag">${(T.find(t=>t.id===ter)||{}).nombre||""}</span>`);
    const x=Math.random()*(S.vw-w*.7)-w*.15, y=Math.random()*(S.vh*.78)-30, r=(Math.random()*16-8);
    d.dataset.ter=ter; d.style.transform=`translate(${x}px,${y}px) rotate(${r}deg) scale(1.25)`; d.style.opacity="0";
    lay.appendChild(d); els.push(d);
    requestAnimationFrame(()=>{d.style.transition="transform .22s cubic-bezier(.2,1.4,.4,1),opacity .12s";d.style.opacity="1";d.style.transform=`translate(${x}px,${y}px) rotate(${r}deg) scale(1)`;d._x=x;d._y=y;d._w=w;d._r=r});
  },tiempos[i]));
  setTimeout(terminar,acum+(largo?800:300));
}
function revelar(els){
  S.fase="reveal"; const tr=$("#trazos");
  if(!reduce){
    tr.innerHTML=""; const NS="http://www.w3.org/2000/svg", cx=S.vw/2, cy=S.vh*.45;
    const L=(x1,y1,x2,y2,dl)=>{const l=document.createElementNS(NS,"line");l.setAttribute("x1",x1);l.setAttribute("y1",y1);l.setAttribute("x2",x2);l.setAttribute("y2",y2);const len=Math.hypot(x2-x1,y2-y1);l.style.strokeDasharray=len;l.style.strokeDashoffset=len;l.style.transition=`stroke-dashoffset .7s ease ${dl}s, opacity .5s ease 1.4s`;tr.appendChild(l);requestAnimationFrame(()=>requestAnimationFrame(()=>{l.style.strokeDashoffset=0;l.style.opacity=0}))};
    for(let i=0;i<12;i++){const a=i*Math.PI/6;L(cx,cy,cx+Math.cos(a)*Math.max(S.vw,S.vh),cy+Math.sin(a)*Math.max(S.vw,S.vh),i*.03)}
  }
  // cada pieza vuela a su territorio sobre el relieve y se vuelve un punto
  els.forEach((d,i)=>{
    const t=T.find(o=>o.id===d.dataset.ter); const p=t?aPantalla(t):{x:S.vw/2,y:S.vh/2};
    d.style.transition=`transform .75s cubic-bezier(.6,0,.3,1) ${i*.025}s, opacity .35s ease ${.5+i*.025}s`;
    d.style.transform=`translate(${p.x-d._w/2}px,${p.y-d._w/2}px) rotate(0deg) scale(.06)`; d.style.opacity="0";
  });
  setTimeout(()=>{$("#collage").innerHTML="";tr.innerHTML=""},reduce?0:1500);
  setTimeout(()=>{
    T.forEach(t=>t.el.classList.add("viva"));
    if(A.ctx) nivelEstatica(0,3);
    esperar();
  },reduce?0:650);
  S.visto=true; store.set("map27.visto",true); marcarEncendida(true);
}
async function esperar(){
  // la señal apunta a lo nuevo: la primera que el visitante no ha oído
  const sen=T.filter(t=>t.tipo==="senal");
  const obj=sen.find(t=>!S.oidas.has(t.id))||sen[Math.floor(Math.random()*sen.length)];
  S.objetivo=obj;
  T.forEach(t=>{t.el.classList.toggle("viva",t===obj);t.el.dataset.dormida=t===obj?"false":"true"}); despertarAeros();
  // descenso desde lo alto: la nave queda al sur de la señal, con la señal a unos 30° de la nariz
  const r=((S.rumbo%360)+360)%360, apr=-25;
  const ang=(apr+150)*Math.PI/180, dist=7;
  const tx=obj.w.x+Math.sin(ang)*dist, tz=obj.w.z-Math.cos(ang)*dist;
  const c=aCarta(tx,tz), haciaSenal=rumboHacia(c.x,c.y,obj.x,obj.y);
  S.rumbo=r;
  setTimeout(()=>{$("#instrumento").classList.add("listo"); $$(".hud").forEach(h=>h.classList.add("listo"))},reduce?0:1600);
  await volarA({tx,tz,d:34,p:34,rumbo:haciaSenal-28},reduce?1:4200);
  if(S.objetivo!==obj) return;
  S.fase="espera"; obj.el.classList.add("detectada");
  aviso(AV.deteccion(obj),true,0);
}

/* ===== mandos ===== */
function mandos(){
  $("#encender").addEventListener("click",encender);
  $("#rumbo").addEventListener("click",()=>{
    if(S.fase==="espera"){sintonizar(S.objetivo);return}
    if(S.fase!=="libre") return;
    const p=$("#rumbo .perilla"); S.giro=(S.giro||0)+120+Math.random()*240; p.style.transform=`rotate(${S.giro}deg)`;
    $("#rumbo").classList.remove("llamado"); sonar("perillas",.8);
    const pool=T.filter(t=>t!==S.activa&&(t.tipo==="senal"||Math.random()<.35));
    const t=pool[Math.floor(Math.random()*pool.length)]; aviso(AV.rumbo,false,2500); setTimeout(()=>sintonizar(t),350);
  });
  $("#b-audio").addEventListener("click",e=>{
    A.on=!A.on; const b=e.currentTarget; b.setAttribute("aria-pressed",A.on); b.classList.toggle("encendida",A.on);
    // apagar el audio apaga el aparato de sonido completo, no solo el volumen
    if(A.ctx){A.master.gain.setTargetAtTime(A.on?1:0,A.ctx.currentTime,.05); if(A.on){A.ctx.resume()}else{setTimeout(()=>{if(!A.on)A.ctx.suspend()},120)}}
  });
  $("#b-carta").addEventListener("click",()=>abrirPliego("p-carta"));
  $("#b-apagar").addEventListener("click",apagar);
  $$("[data-pliego]").forEach(b=>b.addEventListener("click",()=>abrirPliego(b.dataset.pliego)));
  $$(".pliego").forEach(p=>{
    p.addEventListener("click",e=>{if(e.target===p)cerrarPliego(p)});
    p.querySelector(".cerrar").addEventListener("click",()=>cerrarPliego(p));
  });
  window.addEventListener("keydown",e=>{if(e.key==="Escape"){const p=document.querySelector(".pliego:not([hidden])");if(p)cerrarPliego(p);else if($("#ficha").classList.contains("abierta"))cerrarFicha()}});
  $("#f-panol").addEventListener("submit",e=>{
    e.preventDefault(); const i=$("#correo-panol"), r=$("#r-panol");
    if(!i.value||!i.checkValidity()){r.textContent="Revise el correo: falta la arroba o el dominio.";i.focus();return}
    r.textContent="Anotado en la bitácora. (Borrador: este formulario todavía no envía nada.)"; i.value="";
  });
  // índice de la carta plegada
  $("#indice").innerHTML=T.map(t=>`<li><span class="frec">${t.tipo==="senal"?t.frec+"<br>kHz":"—"}</span><div><h3>${t.nombre}${t.nueva?'<em class="chip-nueva">Nueva</em>':""}</h3><div class="lugar">${t.sub} · ${t.lugar} · ${t.lat} ${t.lon}</div>${t.tipo==="senal"?`<p class="fr">${t.frase}</p>`:`<p class="fr">Zona de nubes. Señal en preparación.</p>`}</div>
    <div class="acc"><button class="btn vacio" type="button" data-sint="${t.id}">Sintonizar</button>${t.link?`<a class="btn lleno" href="${t.link}" target="_blank" rel="noopener">Abrir</a>`:""}</div></li>`).join("");
  $$("[data-sint]").forEach(b=>b.addEventListener("click",()=>{cerrarPliego($("#p-carta"));const t=T.find(o=>o.id===b.dataset.sint);if(S.fase==="espera"){S.fase="libre";despertarTodo()}setTimeout(()=>sintonizar(t),150)}));
}
function apagar(){
  pararSenal(); nivelEstatica(0,.1); clack(); if(A.ctx) setTimeout(()=>{if(S.fase==="portada")A.ctx.suspend()},400); leve(null);
  $$(".pliego").forEach(p=>p.hidden=true); $("#ficha").classList.remove("abierta");
  if(vuelo) vuelo.fin(false); clearInterval(avisoT); $("#aviso").textContent="";
  S.activa=null; S.objetivo=null; S.alineada=null; S.fase="portada"; marcarEncendida(false);
  $("#instrumento").classList.remove("listo"); $$(".hud").forEach(h=>h.classList.remove("listo"));
  T.forEach(t=>{t.el.classList.remove("viva","detectada");t.el.dataset.dormida="true"}); dormirAeros();
  $("#rumbo").classList.remove("llamado");
  $("#encender").setAttribute("aria-checked","false"); $("#portada").classList.remove("fuera");
  volarA({tx:0,tz:0,d:200,p:78,rumbo:S.rumbo},reduce?1:2200);
  setTimeout(()=>$("#encender").focus(),300);
}
let ultimoFoco=null;
function abrirPliego(id){if(S.fase==="portada"||S.fase==="collage")return;ultimoFoco=document.activeElement;const p=$("#"+id);p.hidden=false;sonar("perillas",.5);p.querySelector(".cerrar").focus()}
function cerrarPliego(p){p.hidden=true;if(ultimoFoco)try{ultimoFoco.focus()}catch(e){}}

/* ===== regreso: quien vuelve con el sello MAP no repite el encendido =====
   ?desde=textos|serie|podcast|director|contacto (o ya encendió en esta visita) */
const REGRESO=(()=>{let d=null,ses=false;try{d=new URLSearchParams(location.search).get("desde")}catch(e){}
  try{ses=sessionStorage.getItem("map27.encendida")==="1"}catch(e){} return (d||ses)?{desde:d}:null})();
const marcarEncendida=v=>{try{v?sessionStorage.setItem("map27.encendida","1"):sessionStorage.removeItem("map27.encendida")}catch(e){}};
function audioAlPrimerToque(){
  const arrancar=()=>{removeEventListener("pointerdown",arrancar,true);removeEventListener("keydown",arrancar,true);
    iniciarAudio(); if(A.ctx&&A.ctx.state==="suspended") A.ctx.resume().catch(()=>{});};
  addEventListener("pointerdown",arrancar,true); addEventListener("keydown",arrancar,true);
}
function regreso(){
  S.fase="libre"; S.dichoLibre=true; marcarEncendida(true);
  $("#encender").setAttribute("aria-checked","true"); $("#portada").classList.add("fuera");
  $("#instrumento").classList.add("listo"); $$(".hud").forEach(h=>h.classList.add("listo"));
  T.forEach(t=>{t.el.dataset.dormida="false";t.el.classList.add("viva")}); despertarAeros();
  audioAlPrimerToque();
  const a=AEROS.find(x=>x.id==="a-"+REGRESO.desde);
  if(a){
    // despegue: la cámara arranca sobre la pista y sube hacia adelante
    S.rumbo=Math.random()*360; V.tx=a.w.x; V.tz=a.w.z; V.d=5; V.p=20;
    const h=-S.rumbo*Math.PI/180;
    aviso(`Despegue desde ${a.oaci} · ${a.aero}. Cabina en línea`,true,5500);
    volarA({tx:a.w.x-Math.sin(h)*9,tz:a.w.z-Math.cos(h)*9,d:42,p:44,rumbo:S.rumbo+20},reduce?1:3200);
  }else{
    aviso("Cabina en línea. Gire el aro para buscar señales",false,4500);
    volarA({tx:0,tz:0,d:70,p:52,rumbo:S.rumbo},reduce?1:2200);
  }
}
/* ===== arranque ===== */
dibujarDial(); aro(); segs=$$("#vu .seg"); montarMarcas(); montarAeros(); medir(); arrastre(); mandos(); escribirCoord(); cargarCarta();
if(REGRESO) regreso();
window.addEventListener("resize",medir);
if(window.visualViewport) visualViewport.addEventListener("resize",medir);
requestAnimationFrame(bucle);
// si la carta no termina de cargar en 20 s, va la versión plana
Promise.race([cartaLista,new Promise(r=>setTimeout(()=>r("tarde"),20000))]).then(v=>{if(v==="tarde")location.replace("/wp-content/uploads/2026/carta/plana.html"+location.search)});
// precarga del collage: solo si la portada lo va a mostrar, después de la carta y nunca con ahorro de datos
(function(){
  if(REGRESO) return;
  const c=navigator.connection; if(c&&(c.saveData||/(^|-)2g$/.test(c.effectiveType||""))) return;
  Promise.race([cartaLista,new Promise(r=>setTimeout(r,6000))]).then(()=>{
    COLLAGE.forEach(([n,,tipo])=>{if(tipo!=="v"){const i=new Image();i.src=`/wp-content/uploads/2026/carta/assets/collage/${n}.jpg`}else{fetch(`/wp-content/uploads/2026/carta/assets/collage/${n}.mp4`).catch(()=>{})}});
  });
})();
})();

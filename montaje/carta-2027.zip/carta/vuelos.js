/* MAP · tablero de vuelos · 20261031b */

/* ===== tablero de vuelos: independiente de la cabina ===== */
(function(){
"use strict";
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const tab=$("#vuelos"), lista=$("#v-lista"), cols=$("#v-cols"), tecla=$("#b-vuelos");
if(!tab) return;
const SITIO="/";
const CATN={"15": "Cine", "4": "Editorial", "34": "Literatura", "908": "Crónicas", "32": "Cantinas", "545": "Taller Literatura Alajuela", "35": "Podcast", "173": "Fotografía", "33": "Ciudades", "196": "Opinión crítica", "230": "Taller literario", "479": "Clásicos revisados", "364": "Cannabis", "1": "Sin categoría"};
let REC=[["2026-10-26", "El cine independiente en Costa Rica", "el-cine-independiente-en-costa-rica", "Cine"], ["2026-10-25", "El terror de los 70 visto desde acá", "el-terror-de-los-70-visto-desde-aca", "Cine"], ["2026-10-22", "El largo declive de la izquierda europea", "el-largo-declive-de-la-izquierda-europea", "Sin categoría"], ["2026-10-17", "Bitácora de un cortometraje: Falsi Prophetae", "bitacora-de-un-cortometraje-falsi-prophetae", "Cine"], ["2026-10-11", "10 misterios de Costa Rica", "10-misterios-de-costa-rica", "Sin categoría"], ["2026-10-06", "Bitácora de un videoclip", "bitacora-de-un-videoclip", "Cine"]], SOL=[["José María Villalta: el político profesional que vive de la pose", "jose-maria-villalta-el-politico-profesional-que-vide-de-la-pose", 14782], ["Carlos Alvarado y el morbo literario del poder", "carlos-alvarado-y-el-morbo-literario-del-poder", 2095], ["El peligro de la candidez (y otros aprendizajes ochenteros)", "el-peligro-de-la-candidez-y-otros-aprendizajes-ochenteros", 2038], ["De cuclillas con estilo / La mañana más alegre", "de-cuclillas-con-estilo-la-manana-mas-alegre", 1453], ["Vitamina D, cerveza fría y un secreto en Garza", "vitamina-d-cerveza-fria-y-un-secreto-de-garza", 1387]];
const reduce=matchMedia("(prefers-reduced-motion: reduce)").matches;
const ancho=()=>innerWidth>=1100&&innerHeight>700;
const MES=["ENE","FEB","MAR","ABR","MAY","JUN","JUL","AGO","SEP","OCT","NOV","DIC"];
const sinT=s=>s.normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[«»"“”]/g,"").toUpperCase();
const hash=s=>{let h=0;for(const c of s)h=(h*31+c.charCodeAt(0))>>>0;return h};
const LARGO=()=>innerWidth<520?16:27;
const recorta=s=>{s=sinT(s).replace(/\s+/g," ");const n=LARGO();return s.length>n?s.slice(0,n-1).trimEnd()+"…":s};
const ALF="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
function paleta(el,txt,retraso){
  if(reduce){el.textContent=txt;return}
  el.textContent=""; [...txt].forEach((c,i)=>{const s=document.createElement("span");s.className="flap";s.textContent=c===" "?"\u00a0":ALF[Math.floor(Math.random()*ALF.length)];el.appendChild(s);
    if(c===" ") return; let n=3+Math.floor(Math.random()*5);
    const giro=()=>{s.classList.remove("cae");void s.offsetWidth;s.classList.add("cae");if(--n<=0){s.textContent=c;return}s.textContent=ALF[Math.floor(Math.random()*ALF.length)];setTimeout(giro,70)};
    setTimeout(giro,retraso+i*18);});
}
let vista="sal";
function pintar(){
  tab.dataset.vista=vista;
  $$(".vuelos-tabs button").forEach(b=>b.setAttribute("aria-selected",b.dataset.v===vista));
  lista.innerHTML="";
  if(vista==="sal"){
    cols.innerHTML="<span>Fecha</span><span>Vuelo</span><span>Destino</span><span>Estado</span>";
    const filas=REC.slice(0,5).map((p,i)=>{const f=p[0].split("-");return {fecha:f[2]+" "+MES[+f[1]-1],cod:"MP "+(100+hash(p[2])%900),dst:p[1],url:SITIO+p[2]+"/",est:i===0?"Abordando":(i<3?"A tiempo":"Salió"),cls:i===0?"abordando":(i<3?"":"salio")}});
    filas.push({fecha:"13 MAY",cod:"CA 420",dst:"Cannabis Airlines",url:SITIO+"cannabis-airlines-entre-la-pista-y-el-cielo/",est:"Demorado",cls:"demorado",ca:true});
    filas.forEach((r,i)=>{const li=document.createElement("li");li.innerHTML=`<a href="${r.url}"${r.ca?' class="ca"':""} title="${r.dst.replace(/"/g,"")}"><span class="fch"></span><span class="cod"></span><span class="dst"></span><span class="est ${r.cls}"></span></a>`;lista.appendChild(li);
      const a=li.firstChild; paleta(a.querySelector(".fch"),r.fecha,i*120); paleta(a.querySelector(".cod"),r.cod,i*120+60); paleta(a.querySelector(".dst"),recorta(r.dst),i*120+120); paleta(a.querySelector(".est"),sinT(r.est),i*120+300);});
  }else{
    cols.innerHTML="<span>#</span><span>Destino</span><span>Pasajeros</span>";
    SOL.slice(0,5).forEach((p,i)=>{const li=document.createElement("li");li.innerHTML=`<a href="${SITIO+p[1]}/" title="${p[0].replace(/"/g,"")}"><span class="cod"></span><span class="dst"></span><span class="est"></span></a>`;lista.appendChild(li);
      const a=li.firstChild; paleta(a.querySelector(".cod"),String(i+1).padStart(2,"0"),i*120); paleta(a.querySelector(".dst"),recorta(p[0]),i*120+60); paleta(a.querySelector(".est"),Number(p[2]).toLocaleString("es-CR"),i*120+260);});
  }
}
/* datos en vivo desde el sitio; si la red falla, queda el respaldo */
function vivos(){
  fetch(SITIO+"wp-json/wp/v2/posts?per_page=6&_fields=date,slug,title,categories").then(r=>r.ok?r.json():Promise.reject()).then(js=>{
    if(!Array.isArray(js)||!js.length) return;
    const d=document.createElement("div");
    REC=js.map(p=>{d.innerHTML=p.title.rendered;return [p.date.slice(0,10),d.textContent,p.slug,CATN[p.categories&&p.categories[0]]||"Texto"]});
    if(vista==="sal"&&!tab.matches("[data-plegado=true]")) pintar();
  }).catch(()=>{});
  fetch(SITIO+"wp-json/map/v1/populares").then(r=>r.ok?r.json():Promise.reject()).then(js=>{
    if(!Array.isArray(js)||!js.length) return;
    SOL=js.map(p=>[p.title,(p.link?new URL(p.link,location.href).pathname.replace(/^\//,""):"").replace(/\/$/,""),p.views||0]);
  }).catch(()=>{});
}
function reloj(){try{$("#vuelos-hora").textContent=new Intl.DateTimeFormat("es-CR",{hour:"2-digit",minute:"2-digit",hour12:false,timeZone:"America/Costa_Rica"}).format(new Date())}catch(e){}}
let auto=null, quieto=false;
function rotar(){clearInterval(auto);if(reduce)return;auto=setInterval(()=>{if(quieto||tab.dataset.plegado==="true")return;vista=vista==="sal"?"sol":"sal";pintar()},14000)}
function mostrar(v){
  tab.dataset.plegado=v?"false":"true"; if(tecla){tecla.setAttribute("aria-pressed",v);tecla.classList.toggle("encendida",v)}
  try{localStorage.setItem("map27.vuelos",v?"1":"0")}catch(e){}
  if(v) pintar();
}
$$(".vuelos-tabs button").forEach(b=>b.addEventListener("click",()=>{vista=b.dataset.v;pintar();rotar()}));
tab.addEventListener("pointerenter",()=>quieto=true); tab.addEventListener("pointerleave",()=>quieto=false);
tab.addEventListener("focusin",()=>quieto=true); tab.addEventListener("focusout",()=>quieto=false);
$("#vuelos-x").addEventListener("click",()=>mostrar(false));
if(tecla) tecla.addEventListener("click",()=>mostrar(tab.dataset.plegado==="true"));
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&!ancho()&&tab.dataset.plegado==="false")mostrar(false)});
/* abierto por defecto en pantalla grande (salvo que la persona lo haya cerrado); en celular, con la tecla */
let pref=null; try{pref=localStorage.getItem("map27.vuelos")}catch(e){}
function revisar(){if(tab.classList.contains("listo")&&!tab._ya){tab._ya=true;if(ancho()&&pref!=="0")mostrar(true)}else if(!tab.classList.contains("listo")&&tab._ya){tab._ya=false;tab.dataset.plegado="true";if(tecla){tecla.setAttribute("aria-pressed","false");tecla.classList.remove("encendida")}}}
new MutationObserver(revisar).observe(tab,{attributes:true,attributeFilter:["class"]}); revisar();
reloj(); setInterval(reloj,30000); vivos(); rotar();
})();

<?php
/**
 * MAP 2027 · Búsqueda en el archivo
 * Resultados (solo entradas, nunca páginas) con la palabra resaltada, filtros por categoría y «Cargar más»;
 * sin resultados: tres imperdibles al azar de lo más leído y palabras sugeridas.
 * La papelería compartida está en map-archivo.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once get_stylesheet_directory() . '/map-archivo.php';
map_ar_preparar();

$map_q      = trim( get_search_query( false ) );
$map_patron = '' !== $map_q ? map_ar_patron( $map_q ) : '';
$map_res    = array();
if ( '' !== $map_q ) {
	$q = new WP_Query( array(
		's'                   => $map_q,
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => 120,
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	) );
	// Primero las que tienen la palabra en el título; luego, de la más nueva a la más vieja.
	$con = array();
	$sin = array();
	foreach ( $q->posts as $p ) {
		if ( $map_patron && preg_match( $map_patron, $p->post_title ) ) {
			$con[] = $p;
		} else {
			$sin[] = $p;
		}
	}
	$por_fecha = function ( $a, $b ) {
		return strcmp( $b->post_date, $a->post_date );
	};
	usort( $con, $por_fecha );
	usort( $sin, $por_fecha );
	$map_res = array_merge( $con, $sin );
}
$map_n = count( $map_res );

// Imperdibles: de lo más leído (9 candidatos; el navegador muestra 3 al azar).
$map_imp = array_slice( map_ar_populares(), 0, 9 );
if ( count( $map_imp ) < 3 ) {
	$map_imp = get_posts( array( 'posts_per_page' => 9, 'orderby' => 'rand', 'fields' => 'ids' ) );
}
$map_sugeridas = array( 'cantina', 'Alajuela', 'cine', 'Arkady', 'patineta', 'podcast' );

$map_titulo = ( '' !== $map_q ? '«' . $map_q . '» · ' : '' ) . 'Búsqueda en el archivo · MAP Radio CR';
add_filter( 'rank_math/frontend/title', function () use ( $map_titulo ) {
	return $map_titulo;
}, 99 );
add_filter( 'pre_get_document_title', function () use ( $map_titulo ) {
	return $map_titulo;
}, 99 );
map_ar_abrir( 'Textos', 'Saltar a los resultados' );
?>
<main class="ap bu" id="contenido">
	<div class="ap-wrap"><header class="bu-cab ap-ancho">
		<p class="ap-kicker">Búsqueda en el archivo</p>
		<?php if ( '' !== $map_q ) : ?>
			<h1>Resultados para <span>«<?php echo esc_html( $map_q ); ?>»</span></h1>
			<p class="bu-cuenta"><?php echo $map_n ? '<b>' . (int) $map_n . '</b> ' . ( 1 === $map_n ? 'texto encontrado' : 'textos encontrados' ) : 'Ningún texto encontrado'; ?></p>
		<?php else : ?>
			<h1>¿Qué busca?</h1>
		<?php endif; ?>
		<form class="bu-form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label for="bu-q">Buscar otra palabra</label>
			<input id="bu-q" name="s" type="search" autocomplete="off" placeholder="Buscar otra palabra…" value="<?php echo esc_attr( $map_q ); ?>">
			<button type="submit">Buscar ⌕</button>
		</form>
	</header></div>

	<?php if ( $map_n ) :
		// Cuenta por categoría para los filtros.
		$cuenta = array();
		$nombres = array();
		foreach ( $map_res as $p ) {
			foreach ( get_the_category( $p->ID ) as $c ) {
				if ( 'uncategorized' === $c->slug ) {
					continue;
				}
				$cuenta[ $c->term_id ]  = isset( $cuenta[ $c->term_id ] ) ? $cuenta[ $c->term_id ] + 1 : 1;
				$nombres[ $c->term_id ] = $c->name;
			}
		}
		arsort( $cuenta );
		?>
	<div class="ap-wrap"><section class="bu-res ap-ancho" aria-label="Resultados">
		<?php if ( count( $cuenta ) > 1 ) : ?>
		<div class="ap-filtros" id="bu-filtros" role="group" aria-label="Filtrar por categoría">
			<button type="button" data-cat="todos" aria-pressed="true">Todos <small><?php echo (int) $map_n; ?></small></button>
			<?php foreach ( $cuenta as $id => $n ) : ?>
			<button type="button" data-cat="<?php echo (int) $id; ?>" aria-pressed="false"><?php echo esc_html( $nombres[ $id ] ); ?> <small><?php echo (int) $n; ?></small></button>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>
		<ol class="ar-lista" id="bu-lista"><?php
		foreach ( $map_res as $p ) {
			$cats = array_filter( get_the_category( $p->ID ), function ( $c ) {
				return 'uncategorized' !== $c->slug;
			} );
			$url  = get_permalink( $p );
			$anio = get_the_date( 'Y', $p );
			$ex   = map_ar_recorte( map_ar_texto( $p->ID ), $map_patron );
			echo '<li data-cats="' . esc_attr( implode( ',', wp_list_pluck( $cats, 'term_id' ) ) ) . '">'
				. '<span class="ar-marca ar-marca--fecha"><b>' . esc_html( get_the_date( 'd', $p ) ) . '</b>' . esc_html( map_ar_mes( $p ) . ( gmdate( 'Y' ) !== $anio ? ' ' . substr( $anio, 2 ) : '' ) ) . '</span>'
				. '<div><a href="' . esc_url( $url ) . '">' . map_ar_marcar( get_the_title( $p ), $map_patron ) . '</a>' // phpcs:ignore
				. '<span class="ar-meta">' . esc_html( implode( ' · ', wp_list_pluck( $cats, 'name' ) ) ) . '</span>'
				. ( $ex ? '<p class="bu-extracto">' . map_ar_marcar( $ex, $map_patron ) . '</p>' : '' ) // phpcs:ignore
				. '<a class="bu-leer" href="' . esc_url( $url ) . '">Leer texto →</a></div></li>';
		}
		?></ol>
		<button type="button" class="ap-mas" id="bu-mas" hidden>Cargar más →</button>
	</section></div>
	<?php else : ?>
	<div class="ap-wrap"><section class="bu-nada ap-ancho" aria-labelledby="bu-nada-t">
		<?php if ( '' !== $map_q ) : ?>
		<h2 id="bu-nada-t">Aquí no hay nada con esa palabra… <span>todavía.</span></h2>
		<p class="bu-nada__sub">Por ahora, tres imperdibles del archivo:</p>
		<?php else : ?>
		<h2 id="bu-nada-t">Tres imperdibles <span>del archivo</span></h2>
		<p class="bu-nada__sub">Para empezar:</p>
		<?php endif; ?>
		<ul class="bu-imperdibles" id="bu-imperdibles"><?php
		foreach ( $map_imp as $k => $pid ) {
			$ex = map_ar_texto( $pid );
			$ex = mb_strlen( $ex ) > 150 ? preg_replace( '/\s+\S*$/u', '', mb_substr( $ex, 0, 150 ) ) . '…' : $ex;
			echo '<li' . ( $k > 2 ? ' hidden' : '' ) . '><a href="' . esc_url( get_permalink( $pid ) ) . '"><span>' . esc_html( map_ar_categoria( $pid ) . ' · ' . get_the_date( 'd/m/Y', $pid ) ) . '</span><b>' . esc_html( get_the_title( $pid ) ) . '</b><p>' . esc_html( $ex ) . '</p><i>Leer texto →</i></a></li>';
		}
		?></ul>
		<div class="bu-otra"><span>O pruebe con:</span><?php
		foreach ( $map_sugeridas as $w ) {
			echo '<a class="bu-sug" href="' . esc_url( add_query_arg( 's', rawurlencode( $w ), home_url( '/' ) ) ) . '">' . esc_html( $w ) . '</a>';
		}
		?><button type="button" class="bu-azar" id="bu-azar">Otros tres al azar ↻</button></div>
	</section></div>
	<?php endif; ?>
</main>
<?php map_ar_cerrar();

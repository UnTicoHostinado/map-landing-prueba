<?php
/**
 * MAP 2027 · 404: Canal 404 · Sin señal
 * Televisor a pantalla completa, sin barra ni pie; tres textos del archivo al azar y búsqueda.
 * La papelería compartida está en map-archivo.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once get_stylesheet_directory() . '/map-archivo.php';
map_ar_preparar();

$map_tres = get_posts( array(
	'posts_per_page' => 3,
	'orderby'        => 'rand',
	'post_status'    => 'publish',
) );

foreach ( array( 'rank_math/frontend/title', 'pre_get_document_title' ) as $map_f ) {
	add_filter( $map_f, function () {
		return 'Sin señal · MAP Radio CR';
	}, 99 );
}
map_ar_abrir( '', '', false );
?>
<main class="tv" id="contenido">
	<video class="tv__video" src="<?php echo esc_url( content_url( '/uploads/2026/06/404.mp4' ) ); ?>" autoplay muted loop playsinline aria-hidden="true"></video>
	<div class="tv__estatica" aria-hidden="true"></div>
	<div class="tv__barrido" aria-hidden="true"></div>
	<div class="tv__franja" aria-hidden="true"></div>
	<div class="tv__vineta" aria-hidden="true"></div>

	<span class="tv__osd tv__osd--izq">Canal 404</span>
	<span class="tv__osd tv__osd--der">AV-1</span>

	<div class="tv__centro">
		<h1 class="tv__titulo">Sin señal</h1>
		<p class="tv__mensaje">Esta página no existe. Como tantas cosas buenas que le hacen falta a este país.</p>
		<a class="tv__volver" href="<?php echo esc_url( home_url( '/' ) ); ?>">Volver a la programación</a>

		<?php if ( $map_tres ) : ?>
		<div class="tv__tele">
			<span class="tv__tele-lab">Hasta que vuelva la señal, sintonice esto:</span>
			<ul><?php
			foreach ( $map_tres as $p ) {
				$cat = map_ar_categoria( $p->ID );
				echo '<li><a href="' . esc_url( get_permalink( $p ) ) . '"><b>' . esc_html( ( $cat ? $cat : 'Texto' ) . ' ▸ ' ) . '</b>' . esc_html( get_the_title( $p ) ) . '</a></li>';
			}
			?></ul>
		</div>
		<?php endif; ?>

		<form class="tv__buscar" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label for="tv-q">Buscar en el archivo</label>
			<input id="tv-q" name="s" type="search" placeholder="O busque en el archivo…" autocomplete="off">
			<button type="submit">Buscar ⌕</button>
		</form>
	</div>
</main>
<?php map_ar_cerrar( false );

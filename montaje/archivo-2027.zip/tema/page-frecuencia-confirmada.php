<?php
/**
 * MAP 2027 · Frecuencia confirmada (a donde llega quien toca «Sintonizar Frecuencia MAP» en el correo de confirmación)
 * Dirección fija /frecuencia-confirmada/: MailPoet la usa como «página de confirmación». No sale en menús; Rank Math la tiene en noindex.
 * MailPoet confirma la suscripción al cargar la página (parámetros en la dirección); la plantilla solo muestra el sello y las tres puertas.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_stylesheet_directory() . '/map-archivo.php';
map_ar_preparar();
map_ar_abrir( '', 'Saltar al contenido' );

$map_leer = 6319; // De cuclillas con estilo / La mañana más alegre
?>
<main class="hr-root gr fc" id="contenido">

	<div class="hr-wrap"><header class="gr-cab">
		<p class="gr-sello" role="note"><b>Señal recibida</b><span>Frecuencia MAP · todos los lunes</span><span class="gr-sello__fecha" id="gr-fecha"></span></p>
		<p class="gr-kicker"><?php echo map_ar_texto_campo( 'fc_kicker', 'Frecuencia MAP · el boletín de los lunes de mapradiocr.com' ); ?></p>
		<h1 class="hr-title gr-titulo"><?php echo map_ar_texto_campo( 'fc_titulo', 'Ya estás en la Frecuencia MAP' ); ?></h1>
		<p class="gr-bajada"><?php echo map_ar_texto_campo( 'fc_bajada', 'El primer boletín te llega el lunes. Mientras tanto, pasá por el archivo:' ); ?></p>
	</header></div>

	<div class="hr-wrap"><section class="gr-sec" aria-labelledby="fc-puertas-t">
		<div class="ar-tit"><h2 id="fc-puertas-t"><?php echo map_ar_texto_campo( 'fc_puertas_titulo', 'Tres puertas pa entrar ya' ); ?></h2><span>Escuchar · Leer · Ver</span></div>
		<ol class="gr-tres">
			<li class="gr-carta">
				<span class="gr-carta__tipo">01 · Escuchar</span>
				<button type="button" class="hr-proj__screen gr-rollo fc-rollo fc-rollo--cabina" data-spotify="0bQOtOpPP0W8T4Aj1Gtwma">
					<span class="hr-proj__top"><span>Cabina</span><span>Radio Pachuko</span></span>
					<span class="hr-proj__name">Luis Poveda</span>
					<span class="hr-proj__play"><i></i>Escuchar aquí</span>
				</button>
				<a class="fc-fuera" href="https://open.spotify.com/episode/0bQOtOpPP0W8T4Aj1Gtwma" target="_blank" rel="noopener">Escuchar en Spotify ↗</a>
				<p><?php echo map_ar_texto_campo( 'fc_escuchar', 'En Los Bastardos de Poveda, el podcast de MAP Radio Radio Pachuko.' ); ?></p>
			</li>
			<li class="gr-carta">
				<span class="gr-carta__tipo">02 · Leer</span>
				<a class="gr-carta__tit gr-carta__tit--chico" href="<?php echo esc_url( 'publish' === get_post_status( $map_leer ) ? get_permalink( $map_leer ) : home_url( '/de-cuclillas-con-estilo-la-manana-mas-alegre/' ) ); ?>">De cuclillas con estilo / La mañana más alegre</a>
				<p><?php echo map_ar_texto_campo( 'fc_leer', 'De Crónicas del Refugio.' ); ?></p>
			</li>
			<li class="gr-carta">
				<span class="gr-carta__tipo">03 · Ver</span>
				<button type="button" class="hr-proj__screen gr-rollo fc-rollo" data-yt="xSK0iZdmSog" style="--gr-poster:url('https://i.ytimg.com/vi/xSK0iZdmSog/hqdefault.jpg')">
					<span class="hr-proj__top"><span>Proyección</span><span>Serie MAP</span></span>
					<span class="hr-proj__name">Teaser EP. 7</span>
					<span class="hr-proj__play"><i></i>Ver aquí</span>
				</button>
				<a class="fc-fuera" href="https://youtu.be/xSK0iZdmSog" target="_blank" rel="noopener">Ver en YouTube ↗</a>
				<p><?php echo map_ar_texto_campo( 'fc_ver', 'El adelanto del episodio 7 de la Serie MAP.' ); ?></p>
			</li>
		</ol>
	</section></div>

	<div class="hr-wrap"><section class="gr-sec fc-cierre">
		<p class="fc-cierre__tx"><?php echo map_ar_texto_campo( 'fc_cierre', 'En unos minutos te llega al correo una carta de bienvenida, firmada por mí. Si algo de lo que escuchés, leás o veás te mueve, contestá esa carta: las respuestas me llegan directo y las leo yo.' ); ?></p>
		<p class="fc-cierre__firma"><?php echo map_ar_texto_campo( 'fc_firma', 'Valdo · Frecuencia MAP' ); ?></p>
		<a class="gr-boton" href="<?php echo esc_url( home_url( '/' ) ); ?>">Seguir al archivo →</a>
	</section></div>

</main>
<script>
(function () {
	var f = document.getElementById('gr-fecha');
	if (f) {
		try { f.textContent = new Date().toLocaleDateString('es-CR', { day: 'numeric', month: 'short', year: 'numeric' }); } catch (e) {}
	}
})();
</script>
<?php map_ar_cerrar();

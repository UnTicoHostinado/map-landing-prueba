<?php
/**
 * MAP 2027 · Crónicas del Refugio (página «cronicas-del-refugio»)
 * Generada desde la maqueta aprobada (gen_cronicas.py). La papelería compartida está en map-archivo.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once get_stylesheet_directory() . '/map-archivo.php';
map_ar_preparar();
map_ar_abrir( 'Textos', 'Saltar al libro' );
?>
<main class="ap lb" id="contenido">

  <!-- 1 · cabecera de libro -->
  <div class="ap-wrap"><header class="lb-cab ap-ancho">
    <a class="ap-libro lb-portada" href="#lb-portada-t" aria-label="Por qué esta imagen de portada">
      <img src="<?php echo esc_url( home_url( '/' ) ); ?>wp-content/uploads/2026/04/idcdr2.webp" width="1200" height="1800" alt="Portada de Crónicas del Refugio: grabado en blanco y negro de un niño descalzo sentado en la rama de un palo de mango, con un mango rojo intenso colgando a su lado." onerror="this.parentNode.classList.add('sin-foto')">
      <span class="ap-libro__alt" aria-hidden="true"><b>Crónicas del Refugio</b><i>una Costa Rica que no aparece en las películas</i><small>Valdo Jiménez V.</small></span>
    </a>
    <div class="lb-cab__txt">
      <div class="ap-proyecto__ficha"><span>Proyecto literario</span><span><?php echo map_ar_texto_campo( 'lb_ficha_estado', 'En curso' ); ?></span><span><?php echo map_ar_texto_campo( 'lb_ficha_cantidad', '17 crónicas' ); ?></span><span>Desde 2022</span></div>
      <h1>Crónicas del Refugio</h1>
      <p class="lb-sub"><?php echo map_ar_texto_campo( 'lb_sub', 'una Costa Rica que no aparece en las películas' ); ?></p>
      <p class="lb-desc"><?php echo map_ar_html_campo( 'lb_desc', 'Este compilado comenzó a tomar forma en el 2022, luego de que una crecida desapareciera mi casa. Aquí hablo del barrio, la bicicleta, la rabia y las extrañas maneras en que el ser humano siente afecto. Son crónicas de una <b>Costa Rica que no aparece en las guías turísticas</b>, y que sin embargo está muy viva, respirando en cada esquina. Textos donde la memoria se pelea con el olvido, donde personajes que resisten a su manera encuentran su lugar.' ); ?></p>
      <div class="ap-acciones">
        <a class="ap-boton" href="#lb-indice">Ver el índice</a>
        <a class="ap-boton ap-boton--linea" href="<?php echo esc_url( home_url( '/' ) ); ?>80-anos/">Empezar por la 01 →</a>
      </div>
    </div>
  </header></div>

  <!-- 2 · sobre el libro -->
  <div class="ap-wrap"><section class="lb-sec lb-col" aria-labelledby="lb-sobre-t">
    <div class="ar-tit"><h2 id="lb-sobre-t">Sobre el libro</h2><span><?php echo map_ar_texto_campo( 'lb_sobre_nota', '17 textos · 3 territorios' ); ?></span></div>
    <div class="lb-texto">
      <?php echo map_ar_html_campo( 'lb_sobre', '<p><em>Crónicas del refugio</em> reúne 17 textos que exploran los bordes del país: la soda El Refugio como territorio de resistencia, la bicicleta como extensión del cuerpo, los barrios como canteras de historias. Hay sátira política, humor negro, realismo sucio, crónica íntima.</p>
      <p>Un presidente que firma una ley basada en tortugas centenarias, una mujer que incendia la casa de sus padres al tiempo que registra, cámara en mano, todo para un medio extranjero. Un policía de tránsito que detiene a "un ocelote" al volante de un vehículo bastante destartalado. Y, sobre todo, una forma de mirar que viene de abajo, donde las instituciones fallan y los personajes buscan —a veces con ferocidad, a veces con humor, a veces con autodestrucción— formas propias de existir.</p>
      <p>Este libro también es un acto de gratitud. Hay personas reales detrás de estas páginas —compañeros de ruta, amigos de mi padre, vecinos— con quienes conviví años. Gente cuya existencia fue tan extraordinaria que parecía sacada de una película. <b><a href="/andolfo-santa-tecla/">"Andolfo Santa Tecla: el cardenal matemático"</a></b> es el caso más claro.</p>
      <p>Este libro no busca redimir a nadie. No denuncia ni propone. Es una grieta en la pantalla donde aún se filtra el humo del espectáculo. <em>Si algo se entiende, fue por error. Si algo no se entiende, fue por diseño.</em></p>' ); ?>
    </div>
  </section></div>

  <!-- 3 · índice -->
  <div class="ap-wrap"><section class="lb-sec lb-col" id="lb-indice" aria-labelledby="lb-indice-t">
    <div class="ar-tit"><h2 id="lb-indice-t">Índice</h2><span><?php echo map_ar_texto_campo( 'lb_indice_nota', 'las marcadas en rojo quedaron fuera del compilado' ); ?></span></div>
    <p class="lb-aviso"><b><?php echo map_ar_texto_campo( 'lb_aviso_titulo', 'Avance de lectura' ); ?></b><span><?php echo map_ar_texto_campo( 'lb_aviso', 'Cada crónica se puede leer hasta la segunda página. El libro sigue en revisión.' ); ?></span></p>
    <div class="lb-cap"><div class="lb-cap__cab"><span class="lb-cap__num">Territorio 01</span><h3><?php echo map_ar_texto_campo( 'lb_t1_nombre', 'Memorias del barrio' ); ?></h3><p><?php echo map_ar_texto_campo( 'lb_t1_desc', 'Crónica íntima, el barrio, la bicicleta, la universidad.' ); ?></p></div><ol class="lb-lista"><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>80-anos/"><span class="lb-n">01</span><span class="lb-t">Los Cangrejos Salados</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca"></span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>cronica-menor/" class="lb-fuera"><span class="lb-n">02</span><span class="lb-t">Crónica menor de una voluntad intacta</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca">Fuera del compilado</span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>el-ano-del-basurero/"><span class="lb-n">03</span><span class="lb-t">El año del basurero</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca"></span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>la-partera-de-sartenes/"><span class="lb-n">04</span><span class="lb-t">La partera de sartenes</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca"></span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>dios-santo-y-ahora-que/"><span class="lb-n">05</span><span class="lb-t">Dios santo, ¿y ahora qué?</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca"></span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>el-hombre-que-cago/"><span class="lb-n">06</span><span class="lb-t">El hombre que se cagó desde un palo de mango</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca"></span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>de-cuclillas-con-estilo-la-manana-mas-alegre/"><span class="lb-n">07</span><span class="lb-t">De cuclillas con estilo / La mañana más alegre</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca"></span></a></li></ol></div>
<div class="lb-cap"><div class="lb-cap__cab"><span class="lb-cap__num">Territorio 02</span><h3><?php echo map_ar_texto_campo( 'lb_t2_nombre', 'El país como escenario' ); ?></h3><p><?php echo map_ar_texto_campo( 'lb_t2_desc', 'Sátira política, poder, medios, identidades fabricadas.' ); ?></p></div><ol class="lb-lista"><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>parte-por-conducir-como-animal/"><span class="lb-n">08</span><span class="lb-t">Parte por conducir como animal</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca"></span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>estudios-quelonios/" class="lb-fuera"><span class="lb-n">09</span><span class="lb-t">Estudios quelonios</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca">Fuera del compilado</span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>protocolo-de-misericordia/" class="lb-fuera"><span class="lb-n">10</span><span class="lb-t">Protocolo de misericordia</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca">Fuera del compilado</span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>perro-de-nadie/"><span class="lb-n">11</span><span class="lb-t">Perro de nadie</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca"></span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>irene-luna-danilo/" class="lb-fuera"><span class="lb-n">12</span><span class="lb-t">Irene, Luna &amp; Danilo</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca">Fuera del compilado</span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>la-senora-korolenko/"><span class="lb-n">13</span><span class="lb-t">La señora Korolenko</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca"></span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>relato-breve-en-obra-gris/"><span class="lb-n">14</span><span class="lb-t">Relato breve en obra gris</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca"></span></a></li></ol></div>
<div class="lb-cap"><div class="lb-cap__cab"><span class="lb-cap__num">Territorio 03</span><h3><?php echo map_ar_texto_campo( 'lb_t3_nombre', 'Ficciones y umbrales' ); ?></h3><p><?php echo map_ar_texto_campo( 'lb_t3_desc', 'Relatos abstractos, líricos, entre realidad y sueño.' ); ?></p></div><ol class="lb-lista"><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>el-gran-reportaje-de-carlitos/"><span class="lb-n">15</span><span class="lb-t">El gran reportaje de Carlitos</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca"></span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>la-gran-documentalista/"><span class="lb-n">16</span><span class="lb-t">La gran documentalista</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca"></span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>3-testigos-y-un-encargo/"><span class="lb-n">17</span><span class="lb-t">Tres testigos y un encargo</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca"></span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>el-puente-el-viento/"><span class="lb-n">18</span><span class="lb-t">El puente y el viento</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca"></span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>contrato-de-domingo/"><span class="lb-n">19</span><span class="lb-t">Contrato de domingo</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca"></span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>andolfo-santa-tecla/"><span class="lb-n">20</span><span class="lb-t">Andolfo Santa Tecla: el cardenal matemático</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca"></span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>alambre-pila-ceniza/"><span class="lb-n">21</span><span class="lb-t">Alambre, pila &amp; ceniza</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca"></span></a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>la-patrulla-espiritual/" class="lb-dev"><span class="lb-n">22</span><span class="lb-t">La patrulla espiritual</span><span class="lb-guia" aria-hidden="true"></span><span class="lb-marca">En desarrollo</span></a></li></ol></div>
  </section></div>

  <!-- 4 · por qué esta portada -->
  <div class="ap-wrap"><section class="lb-sec lb-col" aria-labelledby="lb-portada-t">
    <div class="ar-tit"><h2 id="lb-portada-t">Por qué esta imagen de portada</h2><span>el mango rojo</span></div>
    <div class="lb-texto">
      <?php echo map_ar_html_campo( 'lb_portada', '<p>El niño descalzo está sentado en la rama gruesa del palo de mango, con la mirada seria y limpia dirigida hacia nosotros. A su derecha, casi al alcance de la mano pero sin tocarla, cuelga un mango rojo intenso, vibrante, casi irreal en medio del grabado en blanco y negro.</p>
      <p>Esta imagen no ilustra un cuento: es el libro entero. Es el instante preciso en que la infancia todavía está arriba, todavía tiene el mango rojo suspendido a su lado como una promesa, abajo la identidad nacional, la patria y la memoria se rompen sin remedio. El niño no llora. No grita. Solo observa.</p>
      <p>El mango rojo intenso no es un detalle decorativo. Es el último resto de vida, de deseo, de infancia intacta que todavía cuelga en el aire. <em>Ese rojo grita: aquí todavía hay algo vivo, algo que duele precisamente porque sigue siendo puro en medio de la ruina.</em></p>
      <p>Esta portada no es decorativa. Es el mapa emocional del libro. Por eso elegí esta ilustración. Porque resume, mejor que cualquier frase, lo que este libro viene a hacer: <b>contar, desde la rama más alta, cómo se ve Costa Rica cuando uno ya no puede bajar.</b></p>' ); ?>
    </div>
  </section></div>

  <!-- 5 · lectura crítica -->
  <div class="ap-wrap"><section class="lb-sec lb-col" aria-labelledby="lb-lectura-t">
    <div class="ar-tit"><h2 id="lb-lectura-t">Una lectura</h2><span>crítica</span></div>
    <blockquote class="lb-cita">
      <p><?php echo map_ar_texto_campo( 'lb_cita', '"El mecanismo que \'Chuz\' emplea para dar sustancia a su praxis política no tiene su sidero ni en el dogmatismo ni en el proselitismo. Lo que ha comprendido es que el catalizador que le permitirá urdir su plan es la creación de una sensación de sed incesante y presentarse, de primero, con medio vaso de agua."' ); ?></p>
      <footer><b><?php echo map_ar_texto_campo( 'lb_cita_autor', 'Ignacio Castillo' ); ?></b><span><?php echo map_ar_texto_campo( 'lb_cita_fuente', 'Análisis sobre «Estudios quelonios»' ); ?></span><a href="<?php echo esc_url( home_url( '/' ) ); ?>etica-tortuguista/">Leer el análisis completo →</a></footer>
    </blockquote>
  </section></div>

  <!-- 6 · cierre -->
  <div class="ap-wrap"><section class="lb-cierre ap-ancho">
    <p><?php echo map_ar_texto_campo( 'lb_frase', 'Contar, desde la rama más alta, cómo se ve Costa Rica cuando uno ya no puede' ); ?> <span><?php echo map_ar_texto_campo( 'lb_frase_remate', 'bajar.' ); ?></span></p>
    <span class="lb-cierre__src">Crónicas del Refugio · 2022 — mapradiocr.com</span>
  </section></div>
</main>
<?php map_ar_cerrar();

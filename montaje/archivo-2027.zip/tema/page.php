<?php
/**
 * MAP 2027 · Página sencilla (Archivo MAP)
 * Marco nuevo para las páginas de texto que no tienen plantilla propia
 * (Términos y condiciones, Política de privacidad y las que vengan): barra, migas, título, cuerpo y pie.
 * Las páginas con plantilla de Elementor (Lienzo, Cabecera y pie) no pasan por aquí.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_stylesheet_directory() . '/map-archivo.php';
map_ar_preparar();
map_ar_abrir( '', 'Saltar al texto' );

while ( have_posts() ) : the_post();
	$map_cuerpo = apply_filters( 'the_content', get_the_content() );
	$map_cuerpo = str_replace( ']]>', ']]&gt;', $map_cuerpo );
	?>
<main class="hr-root ar-pagina" id="contenido">
	<div class="hr-wrap"><header class="hr-head hr-col ar-head">
		<?php echo map_ar_migas(); // phpcs:ignore ?>
		<h1 class="hr-title"><?php echo esc_html( get_the_title() ); ?></h1>
	</header></div>

	<div class="hr-wrap ar-cuerpo"><div class="hr-col hr-body">
		<?php echo $map_cuerpo; // phpcs:ignore ?>
	</div></div>
</main>
<?php endwhile; ?>

<?php map_ar_cerrar();

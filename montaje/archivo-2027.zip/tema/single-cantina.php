<?php
/**
 * MAP 2027 · Cantinas: cada cantina vive solo en el mapa de /cantinas/.
 * Su dirección vieja (/cantina/<nombre>/) manda directo a su ficha en el mapa.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$map_slug = get_post_field( 'post_name', get_queried_object_id() );
wp_safe_redirect( home_url( '/cantinas/' ) . ( $map_slug ? '#' . rawurlencode( $map_slug ) : '' ), 301 );
exit;

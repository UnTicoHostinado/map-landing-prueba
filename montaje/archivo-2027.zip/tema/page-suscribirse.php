<?php
/**
 * MAP 2027 · Suscribirse a Frecuencia MAP (pestaña del menú)
 * Cabecera → formulario → qué te llega cada lunes → cómo funciona.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_stylesheet_directory() . '/map-archivo.php';
map_ar_preparar();
map_ar_abrir( 'Frecuencia', 'Saltar al contenido' );

$map_u = wp_get_upload_dir();
?>
<main class="hr-root gr su" id="contenido">

	<div class="hr-wrap"><header class="gr-cab">
		<p class="gr-kicker">Frecuencia MAP · el boletín de los lunes de mapradiocr.com</p>
		<h1 class="hr-title gr-titulo">Sintonizá la Frecuencia MAP</h1>
		<p class="gr-bajada">Cada lunes te mando un correo corto, escrito por mí, con lo que vale la pena ver, leer y escuchar esa semana. Sin pauta y sin relleno.</p>
	</header></div>

	<div class="hr-wrap"><?php map_ar_frecuencia( 'pagina', 'Escribí tu correo y tocá Sintonizar', '' ); ?></div>

	<div class="hr-wrap"><section class="gr-sec" aria-labelledby="su-lunes-t">
		<div class="ar-tit"><h2 id="su-lunes-t">Qué te llega cada lunes</h2><span>Un correo · cinco cosas</span></div>
		<ol class="su-lista">
			<li><b>Un texto corto mío</b><span>Sobre lo que esa semana me ronda la cabeza.</span></li>
			<li><b>Clip recomendado</b><span>Un video del archivo MAP o de afuera.</span></li>
			<li><b>Película recomendada</b><span>He visto cientos; aquí van las que valen la pena, con el porqué y dónde verlas.</span></li>
			<li><b>Lo nuevo en mapradiocr.com</b><span>Los últimos textos del sitio, en enlaces.</span></li>
			<li><b>Del archivo MAP</b><span>Una pieza del archivo para cerrar.</span></li>
		</ol>
		<p class="su-nasional">Y, de vez en cuando, noticias de NASIONAL: piezas nuevas, ofertas o concursos.</p>
	</section></div>

	<div class="hr-wrap"><section class="gr-sec" aria-labelledby="su-como-t">
		<div class="ar-tit"><h2 id="su-como-t">Cómo funciona</h2><span>Tres pasos</span></div>
		<div class="su-como">
			<ol class="su-pasos">
				<li><b>01</b><span>Escribí tu correo arriba y tocá <strong>Sintonizar</strong>.</span></li>
				<li><b>02</b><span>Te llega un correo de Frecuencia MAP. Abrilo y tocá el botón rojo. Si no lo ves en unos minutos, revisá la carpeta de spam.</span></li>
				<li><b>03</b><span>Listo: te llega la carta de bienvenida, y el lunes siguiente, tu primera Frecuencia MAP.</span></li>
			</ol>
			<img class="su-boton" src="<?php echo esc_url( $map_u['baseurl'] . '/2026/11/boton-sintonizar-frecuencia-map.jpg' ); ?>" width="480" height="480" loading="lazy" alt="El botón rojo del correo de confirmación, con el texto Sintonizar Frecuencia MAP alrededor">
		</div>
	</section></div>

</main>
<?php map_ar_cerrar();

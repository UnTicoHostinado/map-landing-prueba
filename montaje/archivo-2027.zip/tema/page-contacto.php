<?php
/**
 * MAP 2027 · página «contacto»
 * Generada desde la maqueta aprobada (gen_pagina.py contacto). La papelería compartida está en map-archivo.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once get_stylesheet_directory() . '/map-archivo.php';
map_ar_preparar();
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_script( 'map-contacto', content_url( '/uploads/2026/archivo/contacto.js' ), array(), MAP_AR_VER, array( 'in_footer' => true, 'strategy' => 'defer' ) );
}, 21 );
map_ar_abrir( 'Contacto', 'Saltar al formulario' );
?>
<main class="ap ct" id="contenido">

  <!-- 1 · cabecera -->
  <div class="ap-wrap"><header class="ct-cab ap-ancho">
    <p class="ap-kicker"><?php echo map_ar_texto_campo( 'ct_kicker', 'Contacto · MAP Radio CR' ); ?></p>
    <h1><?php echo map_ar_texto_campo( 'ct_titulo', 'Escribinos.' ); ?><br><span><?php echo map_ar_texto_campo( 'ct_titulo_2', 'Escuchamos.' ); ?></span></h1>
    <p class="ct-cab__sub"><?php echo map_ar_texto_campo( 'ct_sub', 'Colaboraciones · prensa · convocatorias · lo que sea' ); ?></p>
  </header></div>

  <!-- 2 · tres ventanillas -->
  <div class="ap-wrap"><section class="ct-ventanillas ap-ancho" aria-labelledby="ct-v-t">
    <div class="ar-tit"><h2 id="ct-v-t"><?php echo map_ar_texto_campo( 'ct_ventanillas_titulo', '¿Por cuál ventanilla?' ); ?></h2><span><?php echo map_ar_texto_campo( 'ct_ventanillas_nota', 'elegí una y el mensaje sale con su asunto' ); ?></span></div>
    <div class="ct-v-fila" role="group" aria-label="Asunto del mensaje">
      <button type="button" class="ct-v" data-asunto="Frecuencia abierta" aria-pressed="true">
        <span class="ct-v__n">01</span>
        <b>Frecuencia abierta</b>
        <span class="ct-v__txt"><?php echo map_ar_texto_campo( 'ct_v1_texto', 'Una historia de cantina, una banda que hay que grabar, un patinador que nadie ha documentado.' ); ?></span>
      </button>
      <button type="button" class="ct-v" data-asunto="El Pañol · merch" aria-pressed="false">
        <span class="ct-v__n">02</span>
        <b>El Pañol</b>
        <span class="ct-v__txt"><?php echo map_ar_texto_campo( 'ct_v2_texto', 'Preguntas por la merch: tallas, colores, cuándo sale y cómo apartar.' ); ?></span>
      </button>
      <button type="button" class="ct-v" data-asunto="El Astillero · patrocinio y producción" aria-pressed="false">
        <span class="ct-v__n">03</span>
        <b>El Astillero</b>
        <span class="ct-v__txt"><?php echo map_ar_texto_campo( 'ct_v3_texto', 'Patrocinio, producción audiovisual, podcast y series con el sello MAP.' ); ?></span>
      </button>
    </div>
  </section></div>

  <!-- 3 · formulario -->
  <div class="ap-wrap"><section class="ct-form-sec ap-ancho" id="ct-form" aria-labelledby="ct-f-t">
    <div class="ar-tx ct-form" id="ct-tx">
      <h2 id="ct-f-t" class="ct-form__t"><?php echo map_ar_texto_campo( 'ct_form_titulo', 'Transmitir mensaje' ); ?></h2>
      <div class="ct-asunto" aria-live="polite"><span>Asunto</span><b id="ct-asunto">Frecuencia abierta</b></div>
      <?php echo do_shortcode( '[wpforms id="18966" title="false" description="false"]' ); // phpcs:ignore ?>
    </div>
  </section></div>

  <!-- 4 · el pañol -->
  <div class="ap-wrap"><section class="ct-sec ap-ancho" id="panol" aria-labelledby="ct-panol-t">
    <div class="ct-sec__cab">
      <p class="ap-kicker"><?php echo map_ar_texto_campo( 'ct_panol_kicker', 'Depósito de a bordo · MAP × Nasional 20 años' ); ?></p>
      <h2 id="ct-panol-t">El Pañol</h2>
      <p class="ct-sec__intro"><?php echo map_ar_texto_campo( 'ct_panol_intro', 'Piezas en el taller. Pocas, bien hechas y pensadas para el calor y la lluvia de este país. Apuntate y te avisamos primero cuando salgan.' ); ?></p>
    </div>
    <ol class="ct-piezas">
      <li>
        <div class="ct-foto ct-foto--doble" data-otra="Espalda">
          <img src="<?php echo esc_url( content_url( '/uploads/2026/carta/assets/panol/' ) ); ?>coach-jacket-nasional-frente.jpg" alt="Coach jacket Nasional azul marino de nailon, vista de frente, con broches y el escudo 15 bordado en rojo sobre el pecho." loading="lazy">
          <img src="<?php echo esc_url( content_url( '/uploads/2026/carta/assets/panol/' ) ); ?>coach-jacket-nasional-espalda.jpg" alt="Espalda de la coach jacket Nasional en malla naranja, con el puño de Nasional estampado en blanco." loading="lazy">
        </div>
        <b><?php echo map_ar_texto_campo( 'ct_pieza_1_nombre', 'Coach jacket' ); ?></b><span><?php echo map_ar_texto_campo( 'ct_pieza_1_texto', 'La pieza ancla. Cien hechas para Nasional, cien vendidas.' ); ?></span><i><?php echo map_ar_texto_campo( 'ct_pieza_1_estado', 'En el taller' ); ?></i>
      </li>
      <li>
        <div class="ct-foto ct-foto--doble" data-otra="Negro">
          <img src="<?php echo esc_url( content_url( '/uploads/2026/carta/assets/panol/' ) ); ?>sueter-capucha-gris.jpg" alt="Suéter con capucha gris jaspeado, holgado, con bolsillo canguro." loading="lazy">
          <img src="<?php echo esc_url( content_url( '/uploads/2026/carta/assets/panol/' ) ); ?>sueter-capucha-negro.jpg" alt="Suéter con capucha negro, holgado, con bolsillo canguro." loading="lazy">
        </div>
        <b><?php echo map_ar_texto_campo( 'ct_pieza_2_nombre', 'Suéter con capucha' ); ?></b><span><?php echo map_ar_texto_campo( 'ct_pieza_2_texto', 'Unisex. Gris jaspeado y negro.' ); ?></span><i><?php echo map_ar_texto_campo( 'ct_pieza_2_estado', 'En el taller' ); ?></i><small>Foto: Los Angeles Apparel</small>
      </li>
      <li>
        <div class="ct-foto ct-foto--doble" data-otra="Negro">
          <img src="<?php echo esc_url( content_url( '/uploads/2026/carta/assets/panol/' ) ); ?>sueter-ziper-gris.jpg" alt="Suéter con capucha y zíper, gris jaspeado, con cordones blancos." loading="lazy">
          <img src="<?php echo esc_url( content_url( '/uploads/2026/carta/assets/panol/' ) ); ?>sueter-ziper-negro.jpg" alt="Suéter con capucha y zíper, negro, con cordones blancos." loading="lazy">
        </div>
        <b><?php echo map_ar_texto_campo( 'ct_pieza_3_nombre', 'Suéter con zíper' ); ?></b><span><?php echo map_ar_texto_campo( 'ct_pieza_3_texto', 'Unisex. Gris jaspeado y negro.' ); ?></span><i><?php echo map_ar_texto_campo( 'ct_pieza_3_estado', 'En el taller' ); ?></i><small>Foto: Los Angeles Apparel</small>
      </li>
      <li>
        <div class="ct-foto"><img src="<?php echo esc_url( content_url( '/uploads/2026/carta/assets/panol/' ) ); ?>gorra-ripstop-map.jpg" alt="Gorra ripstop negra de cinco paneles con el logo MAP y el contorno de Costa Rica estampados en blanco." loading="lazy"></div>
        <b><?php echo map_ar_texto_campo( 'ct_pieza_4_nombre', 'Gorra ripstop' ); ?></b><span><?php echo map_ar_texto_campo( 'ct_pieza_4_texto', 'Tela liviana, aire retro. El mapa de Costa Rica al frente.' ); ?></span><i><?php echo map_ar_texto_campo( 'ct_pieza_4_estado', 'En el taller' ); ?></i>
      </li>
    </ol>
    <form class="ct-lista" id="ct-lista" novalidate><input type="text" name="web" class="ct-trampa" tabindex="-1" autocomplete="off" aria-hidden="true">
      <label for="ct-lista-correo">Correo para la lista</label>
      <div class="ct-lista__fila"><input id="ct-lista-correo" type="email" autocomplete="email" placeholder="tu@correo.com" required><button type="submit" class="ap-boton">Apuntarme</button></div>
      <span id="ct-lista-estado" role="status"></span>
    </form>
  </section></div>

  <!-- 5 · el astillero -->
  <div class="ap-wrap"><section class="ct-sec ap-ancho" id="astillero" aria-labelledby="ct-ast-t">
    <div class="ct-sec__cab">
      <p class="ap-kicker"><?php echo map_ar_texto_campo( 'ct_astillero_kicker', 'Donde se construye para otros' ); ?></p>
      <h2 id="ct-ast-t">El Astillero</h2>
      <p class="ct-sec__intro"><?php echo map_ar_texto_campo( 'ct_astillero_intro', 'Producción audiovisual, podcast y series con el sello MAP. ¿Te gustaría ser parte de este archivo, colaborando como patrocinador? Escribinos.' ); ?></p>
    </div>
    <div class="ct-hacemos">
      <div class="ct-hace"><b>Documentales</b><span>Del rodaje al festival</span><button type="button" class="ct-link" data-yt="_g5LaE4DjVA" data-titulo="RUIDO">Proyectar RUIDO ▸</button></div>
      <div class="ct-hace"><b>Series</b><span>Serie MAP · música, arte y patinetas</span><button type="button" class="ct-link" data-yt="xSK0iZdmSog" data-titulo="Serie MAP · capítulo 7">Proyectar el capítulo 7 ▸</button></div>
      <div class="ct-hace"><b>Podcast</b><span>MAP Radio Pachuko · más de 200 episodios</span><a class="ct-link" href="https://open.spotify.com/episode/4WgYe3dCdDqhNTlQtE84zX">Escuchar «Del palco al infierno» ↗</a></div>
    </div>

    <div class="ct-sala" id="ct-sala">
      <div class="ct-pantalla" id="ct-pantalla" aria-live="polite">
        <div class="ct-pantalla__reposo"><span>Sala de proyección</span><b>Elegí un rollo</b></div>
      </div>
      <div class="ct-sala__lista">
        <h3 class="ct-h3">Producciones</h3>
        <ol class="ct-prod">
          <li><span class="ct-prod__a">2014</span><div><b>4 Historias de Patineta</b><i>Corto documental</i></div><button type="button" class="ct-proy" data-yt="i5xr9GPTt6c" data-titulo="4 Historias de Patineta" aria-label="Proyectar 4 Historias de Patineta">▸</button></li>
          <li><span class="ct-prod__a">2018</span><div><b>RUIDO</b><i>Documental · selección oficial FICCR</i></div><button type="button" class="ct-proy" data-yt="_g5LaE4DjVA" data-titulo="RUIDO" aria-label="Proyectar RUIDO">▸</button></li>
          <li><span class="ct-prod__a">2019</span><div><b>Finca Fest</b><i>Corto documental</i></div><button type="button" class="ct-proy" data-yt="lVAREwuqz_A" data-titulo="Finca Fest" aria-label="Proyectar Finca Fest">▸</button></li>
          <li><span class="ct-prod__a">2019</span><div><b>Continental y la versión extendida de las cosas</b><i>Corto documental</i></div><button type="button" class="ct-proy" data-yt="22LSFONUBcc" data-titulo="Continental y la versión extendida de las cosas" aria-label="Proyectar Continental y la versión extendida de las cosas">▸</button></li>
          <li><span class="ct-prod__a">2024</span><div><b>Sentido Común</b><i>Corto documental</i></div><button type="button" class="ct-proy" data-yt="8dDkYGbBD5o" data-titulo="Sentido Común" aria-label="Proyectar Sentido Común">▸</button></li>
          <li><span class="ct-prod__a">2026</span><div><b>YSM · Palo Miao</b><i>Videoclip</i></div><button type="button" class="ct-proy" data-yt="pHEW-0JTXRI" data-titulo="YSM · Palo Miao" aria-label="Proyectar YSM · Palo Miao">▸</button></li>
          <li><span class="ct-prod__a">2026</span><div><b>Falsi Prophetae</b><i>Cortometraje</i></div><button type="button" class="ct-proy" data-yt="bqpJXJAWjPA" data-titulo="Falsi Prophetae" aria-label="Proyectar Falsi Prophetae">▸</button></li>
        </ol>
      </div>
    </div>

    <div class="ct-patrocinio">
      <span class="ct-patrocinio__sello"><?php echo map_ar_texto_campo( 'ct_patrocinio_sello', 'Busca patrocinio' ); ?></span>
      <p><?php echo map_ar_html_campo( 'ct_patrocinio_texto', '<b>Serie MAP · segunda temporada.</b> Las marcas que la acompañen quedan en los créditos de cada episodio y en la carta.' ); ?></p>
      <div class="ap-acciones">
        <button type="button" class="ap-boton" data-ir-asunto="El Astillero · patrocinio y producción">Proponer un proyecto</button>
        <a class="ap-boton ap-boton--linea" href="<?php echo esc_url( home_url( '/' ) ); ?>serie-map/">Ver la Serie MAP →</a>
      </div>
    </div>
  </section></div>

  <!-- 6 · apoyo directo -->
  <div class="ap-wrap"><section class="ct-apoyo ap-ancho" aria-labelledby="ct-apoyo-t">
    <div>
      <p class="ap-kicker"><?php echo map_ar_texto_campo( 'ct_apoyo_kicker', 'Apoyo directo' ); ?></p>
      <h2 id="ct-apoyo-t"><?php echo map_ar_texto_campo( 'ct_apoyo_titulo', 'Mantener la señal al aire' ); ?></h2>
      <p><?php echo map_ar_texto_campo( 'ct_apoyo_texto', 'MAP se sostiene sin pauta. Un café en Ko-fi paga horas de edición, discos duros y cervezas de entrevista.' ); ?></p>
    </div>
    <div class="ap-acciones">
      <a class="ap-boton" href="https://ko-fi.com/mapradiocr">Invitar un café en Ko-fi</a>
    </div>
  </section></div>
</main>
<?php map_ar_cerrar();

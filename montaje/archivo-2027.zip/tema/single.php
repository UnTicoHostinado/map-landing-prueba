<?php
/**
 * MAP 2027 · Plantilla de entrada (Archivo MAP)
 * Reemplaza al single.php negro de 2026 (copia en single.php.antes-2027).
 * El cuerpo de cada entrada sigue saliendo de Elementor; esta plantilla pone el marco:
 * barra, migas, cabecera, imagen destacada, serie, lo más leído, últimos artículos, radiogramas y pie.
 * Estilos y scripts en /wp-content/uploads/2026/archivo/.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Fecha en que se instala el sitio nuevo: lo publicado antes lleva el sello SEÑAL PREVIA.
if ( ! defined( 'MAP_INSTRUMENTO' ) ) {
	define( 'MAP_INSTRUMENTO', '2026-11-15' );
}
$map_ver = '20261031b';
$map_base = content_url( '/uploads/2026/archivo/' );

// Esta plantilla trae su propia papelería: fuera los estilos del tema y el CSS adicional del 2026.
add_action( 'wp_enqueue_scripts', function () use ( $map_ver, $map_base ) {
	wp_enqueue_style( 'map-fuentes', 'https://fonts.googleapis.com/css2?family=B612+Mono:wght@400;700&family=Bebas+Neue&family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans:ital,wght@0,300;0,400;0,500;0,600;1,300&display=swap', array(), null );
	wp_enqueue_style( 'map-archivo', $map_base . 'entrada.css', array(), $map_ver );
	wp_enqueue_script( 'map-archivo', $map_base . 'entrada.js', array(), $map_ver, array( 'in_footer' => true, 'strategy' => 'defer' ) );
}, 20 );
add_action( 'wp_print_styles', function () {
	$ws = wp_styles();
	foreach ( (array) $ws->queue as $h ) {
		$src = isset( $ws->registered[ $h ] ) ? (string) $ws->registered[ $h ]->src : '';
		if ( 0 === strpos( $h, 'neve' ) || 'chld_thm_cfg_child' === $h || false !== strpos( $src, '/wp-content/themes/' ) ) {
			wp_dequeue_style( $h );
		}
	}
	wp_deregister_style( 'neve-style' );
}, 1 );
remove_action( 'wp_head', 'wp_custom_css_cb', 101 );

if ( ! function_exists( 'map_ar_minutos' ) ) {
	function map_ar_minutos( $html ) {
		$txt = wp_strip_all_tags( preg_replace( '#<(script|style)[^>]*>.*?</\1>#is', ' ', $html ) );
		$n   = count( preg_split( '/\s+/u', trim( $txt ), -1, PREG_SPLIT_NO_EMPTY ) );
		return max( 1, (int) round( $n / 220 ) );
	}
}
if ( ! function_exists( 'map_ar_categoria' ) ) {
	function map_ar_categoria( $post_id ) {
		$c = get_the_category( $post_id );
		if ( ! $c ) {
			return '';
		}
		if ( function_exists( 'rank_math' ) ) {
			$pri = (int) get_post_meta( $post_id, 'rank_math_primary_category', true );
			foreach ( $c as $x ) {
				if ( $x->term_id === $pri ) {
					return $x->name;
				}
			}
		}
		return $c[0]->name;
	}
}

/* Series con anterior / siguiente: categoría => nombre, unidad y total previsto (0 = las publicadas). */
if ( ! function_exists( 'map_ar_serie' ) ) {
	function map_ar_serie( $post_id ) {
		$series = array(
			1097 => array( 'Los Estudios de Campo', 'Bitácora', 10 ),
			1080 => array( 'Crónicas del Refugio', 'Crónica', 0 ),
			1096 => array( 'La Cantina Ideal', 'Estudio', 0 ),
		);
		foreach ( $series as $cat => $s ) {
			if ( ! has_category( $cat, $post_id ) ) {
				continue;
			}
			$ids = get_posts( array(
				'cat'              => $cat,
				'orderby'          => 'date',
				'order'            => 'ASC',
				'posts_per_page'   => 60,
				'fields'           => 'ids',
				'suppress_filters' => false,
			) );
			$i = array_search( $post_id, $ids, true );
			if ( false === $i ) {
				return '';
			}
			$total = max( (int) $s[2], count( $ids ) );
			$num   = function ( $n ) {
				return str_pad( (string) $n, 2, '0', STR_PAD_LEFT );
			};
			ob_start(); ?>
<div class="hr-wrap"><nav class="ar-serie hr-col" aria-label="Serie <?php echo esc_attr( $s[0] ); ?>">
	<div class="ar-tit"><h2><?php echo esc_html( $s[0] ); ?></h2><span><?php echo esc_html( $s[1] . ' ' . $num( $i + 1 ) . ' de ' . $num( $total ) ); ?></span></div>
	<ol class="ar-serie__tira"><?php
			for ( $k = 0; $k < $total; $k++ ) {
				if ( $k === $i ) {
					echo '<li><span class="ar-serie__n ar-serie__n--aqui" aria-current="page" title="' . esc_attr( $s[1] . ' ' . $num( $k + 1 ) . ': ' . get_the_title( $ids[ $k ] ) ) . '">' . $num( $k + 1 ) . '</span></li>';
				} elseif ( isset( $ids[ $k ] ) ) {
					echo '<li><a class="ar-serie__n" href="' . esc_url( get_permalink( $ids[ $k ] ) ) . '" title="' . esc_attr( $s[1] . ' ' . $num( $k + 1 ) . ': ' . get_the_title( $ids[ $k ] ) ) . '">' . $num( $k + 1 ) . '</a></li>';
				} else {
					echo '<li><span class="ar-serie__n ar-serie__n--prep" title="En preparación">' . $num( $k + 1 ) . '</span></li>';
				}
			}
			?></ol>
	<div class="ar-serie__nav"><?php
			if ( $i > 0 ) {
				$a = $ids[ $i - 1 ];
				echo '<a class="ar-serie__paso ar-serie__paso--ant" href="' . esc_url( get_permalink( $a ) ) . '" rel="prev"><span>← Anterior · ' . esc_html( $s[1] . ' ' . $num( $i ) ) . '</span><b>' . esc_html( get_the_title( $a ) ) . '</b></a>';
			} else {
				echo '<span class="ar-serie__paso ar-serie__paso--vacio"><span>← Anterior</span><b>Es la primera</b></span>';
			}
			if ( isset( $ids[ $i + 1 ] ) ) {
				$b = $ids[ $i + 1 ];
				echo '<a class="ar-serie__paso ar-serie__paso--sig" href="' . esc_url( get_permalink( $b ) ) . '" rel="next"><span>Siguiente · ' . esc_html( $s[1] . ' ' . $num( $i + 2 ) ) . ' →</span><b>' . esc_html( get_the_title( $b ) ) . '</b></a>';
			} else {
				echo '<span class="ar-serie__paso ar-serie__paso--sig ar-serie__paso--vacio"><span>Siguiente →</span><b>' . ( $total > count( $ids ) ? 'En preparación' : 'Es la última' ) . '</b></span>';
			}
			?></div>
</nav></div>
<?php
			return ob_get_clean();
		}
		return '';
	}
}

/* Lo más leído: el contador del sitio (/map/v1/populares), guardado una hora. */
if ( ! function_exists( 'map_ar_populares' ) ) {
	function map_ar_populares() {
		$lista = get_transient( 'map_ar_populares' );
		if ( false === $lista ) {
			$lista = array();
			$r     = rest_do_request( new WP_REST_Request( 'GET', '/map/v1/populares' ) );
			if ( ! $r->is_error() ) {
				foreach ( (array) $r->get_data() as $p ) {
					if ( empty( $p['id'] ) ) {
						continue;
					}
					$lista[] = (int) $p['id'];
				}
			}
			set_transient( 'map_ar_populares', $lista, HOUR_IN_SECONDS );
		}
		return $lista;
	}
}

$map_menu = array(
	'Serie MAP'         => home_url( '/serie-map/' ),
	'Textos'            => home_url( '/textos/' ),
	'Podcast'           => home_url( '/podcast/' ),
	'Sobre el director' => home_url( '/sobre-el-director/' ),
	'Contacto'          => home_url( '/contacto/' ),
);
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class( 'map-archivo' ); ?>>
<?php wp_body_open(); ?>
<a class="ar-saltar" href="#contenido">Saltar al texto</a>

<header class="ar-barra">
	<div class="ar-barra__in">
		<a class="ar-sello" href="<?php echo esc_url( home_url( '/?desde=textos' ) ); ?>" title="Volver a la carta">MAP</a>
		<nav class="ar-menu" id="ar-menu" aria-label="Secciones"><?php
		foreach ( $map_menu as $txt => $url ) {
			echo '<a href="' . esc_url( $url ) . '"' . ( 'Textos' === $txt ? ' aria-current="true"' : '' ) . '>' . esc_html( $txt ) . '</a>';
		}
		?></nav>
		<button type="button" class="ar-btn ar-btn--menu" id="ar-menu-btn" aria-expanded="false" aria-controls="ar-menu">Menú</button>
		<button type="button" class="ar-btn" id="ar-buscar-btn">Buscar ⌕</button>
	</div>
</header>

<div class="ar-buscador" id="ar-buscador" hidden>
	<form class="ar-buscador__in" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<label for="ar-q">Buscar en el archivo</label>
		<input id="ar-q" name="s" type="search" placeholder="Bolaño, patinetas, cantina…" autocomplete="off">
		<p>Busca en títulos, textos y etiquetas de todas las entradas.</p>
		<button type="button" class="ar-btn ar-btn--claro" id="ar-buscar-cerrar">Cerrar ✕</button>
	</form>
</div>

<?php while ( have_posts() ) : the_post();
	$map_id     = get_the_ID();
	$map_cuerpo = apply_filters( 'the_content', get_the_content() );
	$map_cuerpo = str_replace( ']]>', ']]&gt;', $map_cuerpo );
	// Las entradas que ya traen su propio encabezado (bitácoras de Arkady, Cannabis Airlines) no repiten el título.
	$map_propio = (bool) preg_match( '/<h1[\s>]/i', $map_cuerpo );
	$map_min    = map_ar_minutos( $map_cuerpo );
	$map_previa = get_the_date( 'Y-m-d' ) < MAP_INSTRUMENTO;
	?>
<main class="hr-root" id="contenido">
	<div class="hr-wrap"><header class="hr-head hr-col ar-head<?php echo $map_propio ? ' ar-head--propio' : ''; ?>">
		<?php
		if ( function_exists( 'rank_math_the_breadcrumbs' ) ) {
			ob_start();
			rank_math_the_breadcrumbs();
			$migas = ob_get_clean();
			echo str_replace( 'class="rank-math-breadcrumb"', 'class="rank-math-breadcrumb ar-migas" aria-label="Migas de pan"', $migas ); // phpcs:ignore
		}
		if ( $map_previa ) {
			echo '<div class="ar-previa" role="note"><b>Señal previa</b><span>Captada antes de instalar el instrumento</span></div>';
		}
		if ( $map_propio ) {
			echo '<h1 class="ar-oculto">' . esc_html( get_the_title() ) . '</h1>';
		} else {
			echo '<h1 class="hr-title">' . esc_html( get_the_title() ) . '</h1>';
			// El extracto sale como bajada solo si es corto y no repite el arranque del texto.
			$map_ext = has_excerpt() ? trim( wp_strip_all_tags( get_the_excerpt() ) ) : '';
			$map_ini = mb_substr( trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $map_cuerpo ) ) ), 0, 900 );
			if ( $map_ext && mb_strlen( $map_ext ) <= 220 && false === mb_strpos( $map_ini, mb_substr( $map_ext, 0, 60 ) ) ) {
				echo '<p class="hr-sub">' . esc_html( $map_ext ) . '</p>';
			}
			echo '<div class="hr-meta"><span>' . esc_html( get_the_author() ) . '</span><span>' . esc_html( ucfirst( date_i18n( 'F Y', get_post_time( 'U', true ) ) ) ) . '</span><span>' . esc_html( $map_min . ' min de lectura' ) . '</span></div>';
		}
		?>
	</header></div>

	<?php if ( ! $map_propio && has_post_thumbnail() ) :
		$map_tid = get_post_thumbnail_id();
		$map_cap = wp_get_attachment_caption( $map_tid );
		?>
	<div class="hr-wrap"><figure class="hr-fig ar-hero"><?php
		echo wp_get_attachment_image( $map_tid, 'full', false, array(
			'class'         => 'ar-hero__img',
			'fetchpriority' => 'high',
			'loading'       => 'eager',
			'sizes'         => '(max-width: 1132px) 100vw, 1100px',
		) );
		if ( $map_cap ) {
			echo '<figcaption class="hr-cap"><b>FIG. 01</b><span>' . esc_html( $map_cap ) . '</span></figcaption>';
		}
		?></figure></div>
	<?php endif; ?>

	<div class="hr-wrap ar-cuerpo"><div class="hr-col hr-body">
		<?php echo $map_cuerpo; // phpcs:ignore ?>
	</div></div>

	<?php echo map_ar_serie( $map_id ); // phpcs:ignore ?>

	<?php
	$map_pop = array_values( array_diff( map_ar_populares(), array( $map_id ) ) );
	$map_pop = array_slice( $map_pop, 0, 5 );
	$map_ult = get_posts( array(
		'posts_per_page'   => 5,
		'post__not_in'     => array( $map_id ),
		'suppress_filters' => false,
	) );
	if ( $map_pop || $map_ult ) :
		?>
	<div class="hr-wrap"><section class="ar-dos" aria-label="Para seguir leyendo">
		<?php if ( $map_pop ) : ?>
		<div class="ar-col"><div class="ar-tit"><h2>Lo más leído</h2><span>Contador del sitio</span></div><ol class="ar-lista"><?php
			foreach ( $map_pop as $k => $pid ) {
				$cat = map_ar_categoria( $pid );
				echo '<li><span class="ar-marca">' . ( $k + 1 ) . '</span><div><a href="' . esc_url( get_permalink( $pid ) ) . '">' . esc_html( get_the_title( $pid ) ) . '</a><span class="ar-meta">' . esc_html( $cat ) . '</span></div></li>';
			}
		?></ol></div>
		<div class="ar-eje" aria-hidden="true"></div>
		<?php endif; ?>
		<div class="ar-col"><div class="ar-tit"><h2>Últimos artículos</h2><span>Del registro</span></div><ol class="ar-lista"><?php
			foreach ( $map_ult as $p ) {
				$cat = map_ar_categoria( $p->ID );
				echo '<li><span class="ar-marca ar-marca--fecha"><b>' . esc_html( get_the_date( 'd', $p ) ) . '</b>' . esc_html( ucfirst( date_i18n( 'M', get_post_time( 'U', true, $p ) ) ) ) . '</span><div><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a><span class="ar-meta">' . esc_html( $cat ) . '</span></div></li>';
			}
		?></ol></div>
	</section></div>
	<?php endif; ?>

	<?php if ( comments_open() || get_comments_number() ) : ?>
	<div class="hr-wrap"><section class="ar-radio hr-col" id="radiogramas" aria-label="Radiogramas">
		<div class="ar-tit"><h2>Radiogramas</h2><span><?php
			$n = (int) get_comments_number();
			echo esc_html( 0 === $n ? 'Ninguno todavía' : ( 1 === $n ? '1 recibido' : $n . ' recibidos' ) );
		?></span></div>
		<?php comments_template(); ?>
	</section></div>
	<?php endif; ?>
</main>
<?php endwhile; ?>

<footer class="ar-pie">
	<div class="ar-pie__in">
		<a class="ar-pie__marca" href="<?php echo esc_url( home_url( '/' ) ); ?>">MAP — 2016 ⚡</a>
		<span class="ar-pie__cred">Ingeniería web — Dr. Arkady Volkov Lazenko · Instituto Cuántico Costarricense para la Investigación Interdimensional</span>
		<nav aria-label="Legal"><a href="<?php echo esc_url( home_url( '/politica-de-privacidad/' ) ); ?>">Privacidad</a><span aria-hidden="true">·</span><a href="<?php echo esc_url( home_url( '/terminos-y-condiciones/' ) ); ?>">Términos</a></nav>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>

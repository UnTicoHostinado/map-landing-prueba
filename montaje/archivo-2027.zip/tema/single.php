<?php
/**
 * MAP 2027 · Plantilla de entrada (Archivo MAP)
 * Reemplaza al single.php negro de 2026 (copia en single.php.antes-2027).
 * El cuerpo de cada entrada sigue saliendo de Elementor; esta plantilla pone el marco:
 * barra, migas, cabecera, imagen destacada, serie, lo más leído, últimos artículos, radiogramas y pie.
 * La papelería compartida (barra, pie, estilos, series, más leído) está en map-archivo.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_stylesheet_directory() . '/map-archivo.php';
map_ar_preparar();
map_ar_abrir( 'Textos', 'Saltar al texto' );

while ( have_posts() ) : the_post();
	$map_id     = get_the_ID();
	$map_cuerpo = apply_filters( 'the_content', get_the_content() );
	$map_cuerpo = str_replace( ']]>', ']]&gt;', $map_cuerpo );
	// Las entradas que ya traen su propio encabezado (bitácoras de Arkady, Cannabis Airlines) no repiten el título.
	$map_propio = (bool) preg_match( '/<h1[\s>]/i', $map_cuerpo );
	$map_min    = map_ar_minutos( $map_cuerpo );
	$map_previa = get_the_date( 'Y-m-d' ) < MAP_INSTRUMENTO;
	?>
<main class="hr-root" id="contenido">
	<div class="hr-wrap"><header class="hr-head hr-col ar-head<?php echo $map_propio ? ' ar-head--propio' : ''; ?>">
		<?php
		echo map_ar_migas(); // phpcs:ignore
		if ( $map_previa ) {
			echo '<div class="ar-previa" role="note"><b>Señal previa</b><span>Captada antes de instalar el instrumento</span></div>';
		}
		if ( $map_propio ) {
			echo '<h1 class="ar-oculto">' . esc_html( get_the_title() ) . '</h1>';
		} else {
			echo '<h1 class="hr-title">' . esc_html( get_the_title() ) . '</h1>';
			// El extracto sale como bajada solo si es corto y no repite el arranque del texto.
			$map_ext = has_excerpt() ? trim( wp_strip_all_tags( get_the_excerpt() ) ) : '';
			$map_ini = mb_substr( trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $map_cuerpo ) ) ), 0, 900 );
			if ( $map_ext && mb_strlen( $map_ext ) <= 220 && false === mb_strpos( $map_ini, mb_substr( $map_ext, 0, 60 ) ) ) {
				echo '<p class="hr-sub">' . esc_html( $map_ext ) . '</p>';
			}
			echo '<div class="hr-meta"><span>' . esc_html( get_the_author() ) . '</span><span>' . esc_html( ucfirst( date_i18n( 'F Y', get_post_time( 'U', true ) ) ) ) . '</span><span>' . esc_html( $map_min . ' min de lectura' ) . '</span></div>';
		}
		?>
	</header></div>

	<?php if ( ! $map_propio && has_post_thumbnail() ) :
		$map_tid = get_post_thumbnail_id();
		$map_cap = wp_get_attachment_caption( $map_tid );
		?>
	<div class="hr-wrap"><figure class="hr-fig ar-hero"><?php
		echo wp_get_attachment_image( $map_tid, 'full', false, array(
			'class'         => 'ar-hero__img',
			'fetchpriority' => 'high',
			'loading'       => 'eager',
			'sizes'         => '(max-width: 1132px) 100vw, 1100px',
		) );
		if ( $map_cap ) {
			echo '<figcaption class="hr-cap"><b>FIG. 01</b><span>' . esc_html( $map_cap ) . '</span></figcaption>';
		}
		?></figure></div>
	<?php endif; ?>

	<div class="hr-wrap ar-cuerpo"><div class="hr-col hr-body">
		<?php echo $map_cuerpo; // phpcs:ignore ?>
	</div></div>

	<?php echo map_ar_serie( $map_id ); // phpcs:ignore ?>

	<?php
	$map_pop = array_values( array_diff( map_ar_populares(), array( $map_id ) ) );
	$map_pop = array_slice( $map_pop, 0, 5 );
	$map_ult = get_posts( array(
		'posts_per_page'   => 5,
		'post__not_in'     => array( $map_id ),
		'suppress_filters' => false,
	) );
	if ( $map_pop || $map_ult ) :
		?>
	<div class="hr-wrap"><section class="ar-dos" aria-label="Para seguir leyendo">
		<?php if ( $map_pop ) : ?>
		<div class="ar-col"><div class="ar-tit"><h2>Lo más leído</h2><span>Contador del sitio</span></div><ol class="ar-lista"><?php
			foreach ( $map_pop as $k => $pid ) {
				$cat = map_ar_categoria( $pid );
				echo '<li><span class="ar-marca">' . ( $k + 1 ) . '</span><div><a href="' . esc_url( get_permalink( $pid ) ) . '">' . esc_html( get_the_title( $pid ) ) . '</a><span class="ar-meta">' . esc_html( $cat ) . '</span></div></li>';
			}
		?></ol></div>
		<div class="ar-eje" aria-hidden="true"></div>
		<?php endif; ?>
		<div class="ar-col"><div class="ar-tit"><h2>Últimos artículos</h2><span>Del registro</span></div><ol class="ar-lista"><?php
			foreach ( $map_ult as $p ) {
				$cat = map_ar_categoria( $p->ID );
				echo '<li><span class="ar-marca ar-marca--fecha"><b>' . esc_html( get_the_date( 'd', $p ) ) . '</b>' . esc_html( map_ar_mes( $p ) ) . '</span><div><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a><span class="ar-meta">' . esc_html( $cat ) . '</span></div></li>';
			}
		?></ol></div>
	</section></div>
	<?php endif; ?>

	<div class="hr-wrap"><?php map_ar_frecuencia( 'entrada', '¿Te gustó? Sintonizá la Frecuencia MAP', 'Cada lunes te llega un correo corto mío: un texto, un clip, una película que vale la pena y algo del archivo MAP.' ); ?></div>

	<?php if ( comments_open() || get_comments_number() ) : ?>
	<div class="hr-wrap"><section class="ar-radio hr-col" id="radiogramas" aria-label="Radiogramas">
		<div class="ar-tit"><h2>Radiogramas</h2><span><?php
			$n = (int) get_comments_number();
			echo esc_html( 0 === $n ? 'Ninguno todavía' : ( 1 === $n ? '1 recibido' : $n . ' recibidos' ) );
		?></span></div>
		<?php comments_template(); ?>
	</section></div>
	<?php endif; ?>
</main>
<?php endwhile; ?>

<?php map_ar_cerrar();

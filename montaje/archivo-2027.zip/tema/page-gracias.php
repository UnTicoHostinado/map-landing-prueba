<?php
/**
 * MAP 2027 · Gracias (página escondida del QR de los productos Nasional)
 * Dirección fija /gracias/ (el QR está impreso). No sale en menús ni en el buscador; Rank Math la tiene en noindex.
 * Señal recibida → Por dónde arrancar → Del taller Nasional → Mantener la señal al aire.
 * Los dos videos son rollos: solo cargan YouTube al tocarlos (archivo.js).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_stylesheet_directory() . '/map-archivo.php';
map_ar_preparar();
map_ar_abrir( '', 'Saltar al contenido' );

$map_u     = wp_get_upload_dir();
$map_media = $map_u['baseurl'] . '/2025/11/medias-1.webp';
$map_tex   = array(
	array( 8528, 'La radiografía más bastarda sobre el socialista quántico.' ),
	array( 5589, 'Una crónica explosiva sobre una extinta cantina escondida entre Playa Garza y Nosara.' ),
);
?>
<main class="hr-root gr" id="contenido">

	<div class="hr-wrap"><header class="gr-cab">
		<p class="gr-sello" role="note"><b>Señal recibida</b><span>Tropa MAP · Radio Pachuko</span><span class="gr-sello__fecha" id="gr-fecha"></span></p>
		<p class="gr-kicker">Bienvenido a la tropa MAP Radio / Radio Pachuko</p>
		<h1 class="hr-title gr-titulo">¡Gracias de verdad!</h1>
		<p class="gr-bajada">Gracias por comprar lo que tenés en la mano: es de NASIONAL, y con eso nos ayudás a sostener este apostolado. Aquí te contamos cómo colaborar para mantener vivo mapradiocr.com y seguir grabando podcast, escribiendo y armando más cultura.</p>
	</header></div>

	<div class="hr-wrap"><section class="gr-sec" aria-labelledby="gr-arrancar-t">
		<div class="ar-tit"><h2 id="gr-arrancar-t">Por dónde arrancar</h2><span>Escuchar · Leer · Ver</span></div>
		<ol class="gr-tres">
			<li class="gr-carta">
				<span class="gr-carta__tipo">01 · Escuchar</span>
				<a class="gr-carta__tit" href="<?php echo esc_url( home_url( '/podcast/#origen' ) ); ?>">Donde empezó todo</a>
				<p>Los Bastardos de Poveda, episodio 1: la primera conversación de la serie, grabada en agosto de 2020.</p>
			</li>
			<li class="gr-carta">
				<span class="gr-carta__tipo">02 · Leer</span>
				<?php foreach ( $map_tex as $t ) :
					if ( 'publish' !== get_post_status( $t[0] ) ) {
						continue;
					}
					?>
				<a class="gr-carta__tit gr-carta__tit--chico" href="<?php echo esc_url( get_permalink( $t[0] ) ); ?>"><?php echo esc_html( get_the_title( $t[0] ) ); ?></a>
				<p><?php echo esc_html( $t[1] ); ?></p>
				<?php endforeach; ?>
			</li>
			<li class="gr-carta">
				<span class="gr-carta__tipo">03 · Ver</span>
				<a class="gr-carta__tit" href="<?php echo esc_url( home_url( '/serie-map/' ) ); ?>">Serie MAP</a>
				<p>La serie documental sobre la música independiente, el arte y la patineta en Costa Rica. Se proyecta en la página, al tocar cada rollo.</p>
			</li>
		</ol>
	</section></div>

	<div class="hr-wrap"><section class="gr-sec" aria-labelledby="gr-taller-t">
		<div class="ar-tit"><h2 id="gr-taller-t">Del taller Nasional</h2><span>Nasional Skateboards · desde 2007</span></div>
		<div class="gr-fichas">
			<article class="gr-ficha">
				<button type="button" class="hr-proj__screen gr-rollo" data-yt="4Iz6gs24U30" style="--gr-poster:url('<?php echo esc_url( $map_media ); ?>')">
					<span class="hr-proj__top"><span>Proyección</span><span>Rollo 01</span></span>
					<span class="hr-proj__name">Medias Nasional</span>
					<span class="hr-proj__play"><i></i>Ver el video</span>
				</button>
				<div class="gr-ficha__tx">
					<p>Las nuevas medias Nasional ya están aquí. Diseñadas pa aguantar calle, patineta y lo que venga.</p>
					<p>80 % algodón, 17 % poliéster y 3 % spandex: comodidad, ajuste y resistencia donde realmente importa. Unisex.</p>
					<p>Colores: negro clásico e intenso (como nuestra consciencia), negro con franjas blancas, negro con franjas rojas, blanco Vaticano y naranja cúrcuma.</p>
					<p>Pa patinar. Pa caminar la ciudad. Pa todos los días, y pa bailarshhh.</p>
					<p class="gr-ficha__nota">Música del video: Los Crveles</p>
					<a class="gr-boton" href="https://www.nasionalsb.com/" target="_blank" rel="noopener">Ir a la tienda Nasional ↗</a>
				</div>
			</article>
			<article class="gr-ficha">
				<button type="button" class="hr-proj__screen gr-rollo" data-yt="dxRJO021p78" style="--gr-poster:url('https://i.ytimg.com/vi/dxRJO021p78/maxresdefault.jpg')">
					<span class="hr-proj__top"><span>Proyección</span><span>Rollo 02</span></span>
					<span class="hr-proj__name">La Camisa Negra</span>
					<span class="hr-proj__play"><i></i>Ver el video</span>
				</button>
				<div class="gr-ficha__tx">
					<p>Hay prendas e historias que se cargan en el pecho como cicatrices. No es una camisa cualquiera: es un tejido con carácter, resistencia y cultura. La Camisa Negra Nasional no solo viste: marca, cuenta y aguanta.</p>
					<p>Cada detalle es memoria:</p>
					<ul>
						<li>Botones color chocolate con la historia grabada (Nacional est. 07).</li>
						<li>Bolsillo doble con espacio para lápiz o pincel: porque vivir también es dejar rastro.</li>
						<li>Bordado oculto en hilo dorado: solo para el que realmente lleva la historia en la piel.</li>
					</ul>
					<p>Hecha pal que camina consciente de su destino.</p>
					<a class="gr-boton" href="https://www.nasionalsb.com/" target="_blank" rel="noopener">Ir a la tienda Nasional ↗</a>
				</div>
			</article>
		</div>
	</section></div>

	<div class="hr-wrap"><section class="gr-sec" aria-labelledby="gr-senal-t">
		<div class="ar-tit"><h2 id="gr-senal-t">Mantener la señal al aire</h2><span>Otras formas de sostener MAP</span></div>
		<ul class="gr-apoyo">
			<li><a href="<?php echo esc_url( home_url( '/contacto/#panol' ) ); ?>"><b>El Pañol</b><span>Piezas MAP × Nasional en el taller. Apuntate a la lista y te avisamos primero cuando salgan.</span></a></li>
			<li><a href="https://ko-fi.com/mapradiocr" target="_blank" rel="noopener"><b>Un café en Ko-fi ↗</b><span>MAP se sostiene sin pauta. Un café paga horas de edición, discos duros y cervezas de entrevista.</span></a></li>
			<li><a href="https://open.spotify.com/show/6XGk2uLzxlDTm7Op6mqEBB" target="_blank" rel="noopener"><b>Seguir el podcast ↗</b><span>En Spotify, pa que cada episodio nuevo te llegue solo.</span></a></li>
			<li><button type="button" id="gr-compartir"><b>Compartir MAP</b><span id="gr-compartir-tx">Pasale mapradiocr.com a alguien que lo vaya a disfrutar.</span></button></li>
		</ul>
	</section></div>

</main>
<script>
(function () {
	var f = document.getElementById('gr-fecha');
	if (f) {
		try { f.textContent = new Date().toLocaleDateString('es-CR', { day: 'numeric', month: 'short', year: 'numeric' }); } catch (e) {}
	}
	var b = document.getElementById('gr-compartir'), tx = document.getElementById('gr-compartir-tx');
	if (!b) return;
	var url = <?php echo wp_json_encode( home_url( '/' ) ); ?>;
	b.addEventListener('click', function () {
		if (navigator.share) {
			navigator.share({ title: 'MAP Radio CR · Música, Arte & Patinetas', url: url }).catch(function () {});
		} else if (navigator.clipboard) {
			navigator.clipboard.writeText(url).then(function () { tx.textContent = 'Enlace copiado: ' + url; });
		} else {
			tx.textContent = url;
		}
	});
})();
</script>
<?php map_ar_cerrar();

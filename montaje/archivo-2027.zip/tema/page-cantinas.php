<?php
/**
 * MAP 2027 · Cantinas legendarias (página /cantinas/)
 * El mapa vivo del Dr. Arkady: cada cantina vive SOLO aquí, sin entrada propia (las direcciones /cantina/<nombre>/ mandan a su ficha).
 * Datos: tipo de contenido «cantina» (campos ACF coordenadas, ubicacion, resena, imagen_1..3, podcast, motivo_de_la_cruz,
 * bar_iconico, cronica) + «Estado en el mapa» (punto_aliado, cerro, senal_activa).
 * Mapa: Leaflet alojado en el sitio, cartas aeronáuticas (país y Valle Central) y, al acercarse a las calles, OpenStreetMap.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_stylesheet_directory() . '/map-archivo.php';
map_ar_preparar();

add_action( 'wp_enqueue_scripts', function () {
	$b = content_url( '/uploads/2026/archivo/cantinas/' );
	wp_enqueue_style( 'map-leaflet', $b . 'leaflet.css', array(), '1.9.4' );
	wp_enqueue_style( 'map-cantinas', $b . 'cantinas.css', array( 'map-leaflet' ), MAP_AR_VER );
	wp_enqueue_script( 'map-leaflet', $b . 'leaflet.js', array(), '1.9.4', array( 'in_footer' => true ) );
	wp_enqueue_script( 'map-cantinas', $b . 'cantinas.js', array( 'map-leaflet' ), MAP_AR_VER, array( 'in_footer' => true ) );
}, 30 );

/* ---------- los datos ---------- */
$map_prov_orden = array( 'San José', 'Alajuela', 'Heredia', 'Cartago', 'Puntarenas', 'Guanacaste', 'Limón' );
$map_cn         = array();
$map_q          = new WP_Query( array(
	'post_type'      => 'cantina',
	'post_status'    => 'publish',
	'posts_per_page' => -1,
	'orderby'        => 'title',
	'order'          => 'ASC',
	'no_found_rows'  => true,
) );
foreach ( $map_q->posts as $map_p ) {
	$id  = $map_p->ID;
	$raw = function_exists( 'get_field' ) ? trim( (string) get_field( 'coordenadas', $id ) ) : '';
	$xy  = array_map( 'trim', explode( ',', $raw ) );
	if ( 2 !== count( $xy ) || ! is_numeric( $xy[0] ) || ! is_numeric( $xy[1] ) ) {
		continue;
	}
	$nombre = get_the_title( $id );
	if ( mb_strtoupper( $nombre, 'UTF-8' ) === $nombre ) {
		$nombre = mb_convert_case( mb_strtolower( $nombre, 'UTF-8' ), MB_CASE_TITLE, 'UTF-8' );
	}
	$lugar = trim( preg_replace( '/\s+/', ' ', (string) get_field( 'ubicacion', $id ) ), " .\t\n\r" );
	$prov  = 'San José';
	foreach ( array( 'Guanacaste', 'Puntarenas', 'Limón', 'Limon', 'Cartago', 'Heredia', 'Alajuela' ) as $pv ) {
		if ( false !== mb_stripos( $lugar, $pv ) ) {
			$prov = 'Limon' === $pv ? 'Limón' : $pv;
			break;
		}
	}
	$fotos = array();
	foreach ( array( 'imagen_1', 'imagen_2', 'imagen_3' ) as $campo ) {
		$u = get_field( $campo, $id );
		if ( is_array( $u ) ) {
			$u = isset( $u['url'] ) ? $u['url'] : '';
		}
		if ( ! $u ) {
			continue;
		}
		$aid   = attachment_url_to_postid( $u );
		$chico = $aid ? wp_get_attachment_image_url( $aid, 'medium_large' ) : '';
		$fotos[] = array( 'g' => esc_url_raw( $u ), 'c' => esc_url_raw( $chico ? $chico : $u ) );
	}
	$map_cn[] = array(
		'slug'    => $map_p->post_name,
		'nombre'  => $nombre,
		'lat'     => (float) $xy[0],
		'lng'     => (float) $xy[1],
		'lugar'   => $lugar,
		'prov'    => $prov,
		'resena'  => trim( (string) get_field( 'resena', $id ) ),
		'fotos'   => $fotos,
		'podcast' => esc_url_raw( (string) get_field( 'podcast', $id ) ),
		'cronica' => esc_url_raw( (string) get_field( 'cronica', $id ) ),
		'cruz'    => trim( (string) get_field( 'motivo_de_la_cruz', $id ) ),
		'iconico' => (bool) get_field( 'bar_iconico', $id ),
		'aliado'  => (bool) get_field( 'punto_aliado', $id ),
		'cerro'   => (bool) get_field( 'cerro', $id ),
		'senal'   => (bool) get_field( 'senal_activa', $id ),
	);
}
usort( $map_cn, function ( $a, $b ) use ( $map_prov_orden ) {
	$pa = array_search( $a['prov'], $map_prov_orden, true );
	$pb = array_search( $b['prov'], $map_prov_orden, true );
	if ( $pa !== $pb ) {
		return $pa - $pb;
	}
	if ( $a['aliado'] !== $b['aliado'] ) {
		return $a['aliado'] ? 1 : -1;
	}
	return strcoll( preg_replace( '/^Bar /i', '', $a['nombre'] ), preg_replace( '/^Bar /i', '', $b['nombre'] ) );
} );
$map_n = array( 'aire' => 0, 'aliados' => 0, 'cerro' => 0, 'cruz' => 0 );
foreach ( $map_cn as $i => $c ) {
	$map_cn[ $i ]['num'] = sprintf( '%02d', $i + 1 );
	if ( $c['cerro'] ) {
		$map_n['cerro']++;
	} elseif ( $c['aliado'] ) {
		$map_n['aliados']++;
	} else {
		$map_n['aire']++;
	}
	if ( $c['cruz'] ) {
		$map_n['cruz']++;
	}
}

map_ar_abrir( '', 'Saltar al mapa' );
?>
<main class="hr-root cn" id="contenido">

	<div class="hr-wrap"><header class="cn-cab">
		<?php echo map_ar_migas(); // phpcs:ignore ?>
		<p class="cn-kicker"><?php echo map_ar_texto_campo( 'cn_kicker', 'Mapa vivo de Costa Rica · trazado a mano por el Dr. Arkady Volkov Lazenko' ); ?></p>
		<h1 class="hr-title cn-titulo"><?php echo map_ar_texto_campo( 'cn_titulo', 'Cantinas legendarias' ); ?></h1>
		<p class="cn-bajada"><?php echo map_ar_texto_campo( 'cn_bajada', 'Cada cantina vive aquí, en su punto de la carta. Tocá una señal para abrir su ficha: dónde queda, qué pedir y cómo llegar.' ); ?></p>
		<dl class="cn-cuenta">
			<div><dt>Cantinas al aire</dt><dd class="cn-rojo"><?php echo (int) $map_n['aire']; ?></dd></div>
			<div><dt>Puntos aliados</dt><dd class="cn-verde"><?php echo (int) $map_n['aliados']; ?></dd></div>
			<div><dt>Fuera del aire</dt><dd class="cn-gris"><?php echo (int) $map_n['cerro']; ?></dd></div>
			<div><dt>Con cruz</dt><dd><?php echo (int) $map_n['cruz']; ?></dd></div>
		</dl>
	</header></div>

	<div class="hr-wrap"><div class="cn-mesa">

		<section class="cn-carta" aria-label="La carta de cantinas">
			<div class="cn-marco">
				<div id="cn-mapa" class="cn-mapa" role="application" aria-label="Mapa de cantinas. Usá el registro de la derecha si preferís una lista."></div>
				<p class="cn-hoja" id="cn-hoja">Hoja Valle Central · 10°N 84°W</p>
				<div class="cn-zoom">
					<button type="button" id="cn-mas" aria-label="Acercar">+</button>
					<button type="button" id="cn-menos" aria-label="Alejar">−</button>
				</div>
				<div class="cn-gua" id="cn-gua" hidden>
					<p class="cn-gua__tit">Fuera de la hoja · Guanacaste</p>
					<div class="cn-gua__carta">
						<img src="<?php echo esc_url( content_url( '/uploads/2026/archivo/cantinas/carta-guanacaste.jpg' ) ); ?>" width="1038" height="884" alt="Carta aeronáutica de la costa de Guanacaste alrededor de Pinilla" loading="lazy">
						<div id="cn-gua-puntos"></div>
					</div>
				</div>
				<button type="button" class="cn-gua-boton" id="cn-gua-boton" hidden></button>
				<button type="button" class="cn-volver" id="cn-volver" hidden>Volver al Valle Central</button>
				<div class="cn-notam" id="cn-notam" role="note" hidden>
					<b>NOTAM · MAP-CANTINAS</b>
					<span><?php echo map_ar_texto_campo( 'cn_notam', 'Nuestros reservistas se dan a la dura tarea de mapear más cantinas. Pronto, en esta carta.' ); ?></span>
					<a href="<?php echo esc_url( home_url( '/contacto/' ) ); ?>">¿Conocés una? Reportala →</a>
				</div>
			</div>
			<ul class="cn-leyenda">
				<li><i class="cn-l cn-l--cantina"></i>Cantina</li>
				<li><i class="cn-l cn-l--aliado"></i>Punto aliado</li>
				<li><i class="cn-l cn-l--cruz"></i>Con cruz</li>
				<li><i class="cn-l cn-l--cerro"></i>Fuera del aire · cerró</li>
				<li><i class="cn-l cn-l--senal"></i>Señal activa</li>
				<li><i class="cn-l cn-l--zona"></i>Zona: tocá para ver sus cantinas</li>
			</ul>
			<p class="cn-credito">Cartas: Joint Operations Graphic (Air), hojas de Costa Rica · Plano de calles: <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">© colaboradores de OpenStreetMap</a></p>
		</section>

		<aside class="cn-lado" aria-label="Ficha y registro">
			<article class="cn-ficha" id="cn-ficha" aria-live="polite">
				<p class="cn-ficha__vacia">Tocá una señal de la carta o una cantina del registro.</p>
			</article>

			<section class="cn-reg" aria-labelledby="cn-reg-t">
				<div class="cn-reg__cab">
					<h2 id="cn-reg-t">Registro · <span id="cn-reg-nombre">las <?php echo count( $map_cn ); ?></span></h2>
					<button type="button" id="cn-todas" hidden>Ver las <?php echo count( $map_cn ); ?></button>
				</div>
				<ol class="cn-reg__lista" id="cn-registro">
					<?php foreach ( $map_cn as $c ) :
						$marca = $c['cerro'] ? 'Cerró' : ( $c['aliado'] ? 'Aliado' : ( $c['cruz'] ? '✕ Cruz' : ( $c['podcast'] ? 'Podcast' : '' ) ) );
						$tipo  = $c['cerro'] ? 'cerro' : ( $c['aliado'] ? 'aliado' : ( $c['cruz'] ? 'cruz' : 'cantina' ) );
						?>
					<li data-slug="<?php echo esc_attr( $c['slug'] ); ?>">
						<button type="button" class="cn-fila cn-fila--<?php echo esc_attr( $tipo ); ?>" data-slug="<?php echo esc_attr( $c['slug'] ); ?>">
							<span class="cn-fila__n"><?php echo esc_html( $c['num'] ); ?></span>
							<span class="cn-fila__tx"><b><?php echo esc_html( $c['nombre'] ); ?></b><small><?php echo esc_html( $c['lugar'] ); ?></small></span>
							<span class="cn-fila__m"><?php echo esc_html( $marca ); ?></span>
						</button>
					</li>
					<?php endforeach; ?>
				</ol>
			</section>
		</aside>
	</div></div>

	<dialog class="cn-foto" id="cn-foto" aria-label="Foto de la cantina">
		<form method="dialog"><button type="submit" aria-label="Cerrar la foto">×</button></form>
		<img id="cn-foto-img" src="" alt="">
	</dialog>

	<script type="application/json" id="cn-datos"><?php echo wp_json_encode( array( 'base' => content_url( '/uploads/2026/archivo/cantinas/' ), 'cantinas' => $map_cn ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ); ?></script>
</main>
<?php map_ar_cerrar();

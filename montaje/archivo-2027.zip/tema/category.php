<?php
/**
 * MAP 2027 · Plantilla de categoría (una sola para todas, también las subcategorías)
 * Cabecera con el nombre en grande, descripción y datos; subcategorías con su cuenta;
 * registro por año en páginas de 12 (cuadros numerados, como en las series); otras categorías.
 * La papelería compartida está en map-archivo.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once get_stylesheet_directory() . '/map-archivo.php';
map_ar_preparar();

$map_cat   = get_queried_object();
$map_cid   = (int) $map_cat->term_id;
$map_hijas = get_terms( array(
	'taxonomy'   => 'category',
	'parent'     => $map_cid,
	'hide_empty' => true,
) );
$map_hijas = is_wp_error( $map_hijas ) ? array() : $map_hijas;
$map_ids_hijas = wp_list_pluck( $map_hijas, 'term_id' );
$map_linaje    = array_merge( array( $map_cid ), get_ancestors( $map_cid, 'category' ), get_term_children( $map_cid, 'category' ) );

// Todas las entradas de la categoría y sus hijas, de la más nueva a la más vieja.
$map_posts = get_posts( array(
	'cat'              => $map_cid,
	'posts_per_page'   => 300,
	'orderby'          => 'date',
	'order'            => 'DESC',
	'suppress_filters' => false,
) );
$map_total   = count( $map_posts );
$map_por_pag = 12;
$map_paginas = array_chunk( $map_posts, $map_por_pag );
$map_por_anio = array();
foreach ( $map_posts as $p ) {
	$y = get_the_date( 'Y', $p );
	$map_por_anio[ $y ] = isset( $map_por_anio[ $y ] ) ? $map_por_anio[ $y ] + 1 : 1;
}

$map_txt = function ( $n ) {
	return $n . ' ' . ( 1 === (int) $n ? 'texto' : 'textos' );
};
$map_desc = trim( wp_strip_all_tags( term_description( $map_cid ) ) );

map_ar_abrir( 'Textos', 'Saltar al registro' );
?>
<main class="ap" id="contenido">
	<div class="ap-wrap"><header class="ac-cab ap-ancho">
		<?php echo map_ar_migas(); // phpcs:ignore ?>
		<div class="ac-cab__fila">
			<h1><?php echo esc_html( single_cat_title( '', false ) ); ?></h1>
			<div>
				<?php if ( $map_desc ) : ?><p class="ac-desc"><?php echo esc_html( $map_desc ); ?></p><?php endif; ?>
				<div class="ac-datos">
					<span><b><?php echo (int) $map_total; ?></b> <?php echo 1 === $map_total ? 'texto' : 'textos'; ?></span>
					<?php
					foreach ( $map_hijas as $h ) {
						echo '<span>' . (int) $h->count . ' en ' . esc_html( $h->name ) . '</span>';
					}
					if ( $map_posts ) {
						$ult = $map_posts[0];
						echo '<span>Desde ' . esc_html( get_the_date( 'Y', end( $map_posts ) ) ) . '</span>';
						echo '<span>Último: ' . esc_html( get_the_date( 'j', $ult ) . ' ' . map_ar_mes( $ult ) . ' ' . get_the_date( 'Y', $ult ) ) . '</span>';
						reset( $map_posts );
					}
					?>
				</div>
			</div>
		</div>
		<?php if ( $map_hijas ) : ?>
		<div class="ac-hijas"><span>Subcategorías de <?php echo esc_html( $map_cat->name ); ?>:</span><?php
			foreach ( $map_hijas as $h ) {
				echo '<a href="' . esc_url( get_term_link( $h ) ) . '">' . esc_html( $h->name ) . '<small>· ' . esc_html( $map_txt( $h->count ) ) . '</small></a>';
			}
		?></div>
		<?php endif; ?>
	</header></div>

	<div class="ap-wrap"><section class="ac-reg ap-ancho" aria-label="Textos de <?php echo esc_attr( $map_cat->name ); ?>">
		<?php if ( ! $map_posts ) : ?>
			<p class="ac-vacio">Todavía no hay textos en esta categoría.</p>
		<?php endif; ?>
		<?php foreach ( $map_paginas as $n => $pag ) : ?>
		<div class="ac-pag" data-pag="<?php echo (int) $n + 1; ?>"<?php echo $n ? ' hidden' : ''; ?>><?php
			$anio = '';
			foreach ( $pag as $p ) {
				$y = get_the_date( 'Y', $p );
				if ( $y !== $anio ) {
					if ( '' !== $anio ) {
						echo '</ol>';
					}
					$anio = $y;
					echo '<div class="ac-anio"><h2>' . esc_html( $y ) . '</h2><span>' . esc_html( $map_txt( $map_por_anio[ $y ] ) ) . '</span></div><ol class="ar-lista">';
				}
				// Si la entrada está en una subcategoría, se nombra (en rojo); si no, otras categorías donde también está.
				$cats  = get_the_category( $p->ID );
				$hijas = array();
				$otras = array();
				foreach ( $cats as $c ) {
					if ( in_array( (int) $c->term_id, $map_ids_hijas, true ) ) {
						$hijas[] = $c->name;
					} elseif ( ! in_array( (int) $c->term_id, $map_linaje, true ) && 'uncategorized' !== $c->slug ) {
						$otras[] = $c->name;
					}
				}
				if ( $hijas ) {
					$meta = '<span class="ar-meta ar-meta--hija">' . esc_html( implode( ' · ', $hijas ) ) . '</span>';
				} elseif ( $otras ) {
					$meta = '<span class="ar-meta">También en ' . esc_html( implode( ' · ', $otras ) ) . '</span>';
				} else {
					$meta = '<span class="ar-meta"></span>';
				}
				echo '<li><span class="ar-marca ar-marca--fecha"><b>' . esc_html( get_the_date( 'd', $p ) ) . '</b>' . esc_html( map_ar_mes( $p ) ) . '</span><div><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a>' . $meta . '</div></li>'; // phpcs:ignore
			}
			if ( '' !== $anio ) {
				echo '</ol>';
			}
		?></div>
		<?php endforeach; ?>

		<?php if ( count( $map_paginas ) > 1 ) : ?>
		<nav class="ac-pags" aria-label="Páginas"><span class="rot">Página</span><?php
			foreach ( $map_paginas as $n => $pag ) {
				echo '<button type="button" data-ir="' . (int) ( $n + 1 ) . '"' . ( $n ? '' : ' aria-current="page"' ) . '>' . esc_html( str_pad( (string) ( $n + 1 ), 2, '0', STR_PAD_LEFT ) ) . '</button>';
			}
		?><button type="button" data-ir="sig">Siguiente →</button></nav>
		<?php endif; ?>
	</section></div>

	<?php
	$map_todas = get_terms( array(
		'taxonomy'   => 'category',
		'hide_empty' => true,
		'parent'     => 0,
		'orderby'    => 'count',
		'order'      => 'DESC',
	) );
	if ( ! is_wp_error( $map_todas ) && $map_todas ) :
		$raiz = $map_cid;
		$anc  = get_ancestors( $map_cid, 'category' );
		if ( $anc ) {
			$raiz = (int) end( $anc );
		}
		?>
	<div class="ap-wrap"><section class="ac-otras ap-ancho" aria-labelledby="ac-otras-t">
		<div class="ar-tit"><h2 id="ac-otras-t">Otras categorías</h2><span>Solo las que tienen textos</span></div>
		<ul><?php
		$hay_propia = false;
		foreach ( $map_todas as $t ) {
			if ( 'uncategorized' === $t->slug ) {
				continue;
			}
			// La cuenta incluye las subcategorías, sin contar dos veces la misma entrada.
			$q      = new WP_Query( array( 'cat' => $t->term_id, 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => false ) );
			$cuenta = (int) $q->found_posts;
			if ( (int) $t->term_id === $raiz ) {
				echo '<li><span class="aqui" aria-current="page">' . esc_html( $t->name ) . '<small>' . $cuenta . '</small></span></li>'; // phpcs:ignore
				continue;
			}
			$propia = map_ar_pagina_propia( (int) $t->term_id );
			$hay_propia = $hay_propia || (bool) $propia;
			echo '<li><a href="' . esc_url( $propia ? $propia : get_term_link( $t ) ) . '"' . ( $propia ? ' class="propia"' : '' ) . '>' . esc_html( $t->name ) . '<small>' . $cuenta . '</small></a></li>'; // phpcs:ignore
		}
		?></ul>
		<?php if ( $hay_propia ) : ?><p class="ac-otras__nota">Las de borde punteado llevan a sus páginas propias.</p><?php endif; ?>
	</section></div>
	<?php endif; ?>
</main>
<?php map_ar_cerrar();

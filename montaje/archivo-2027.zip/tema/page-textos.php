<?php
/**
 * MAP 2027 · Portada de Textos (página «textos»)
 * Última transmisión → Crónicas del Refugio → Al aire → Antología → Últimos artículos → Lo más leído.
 * La papelería compartida está en map-archivo.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once get_stylesheet_directory() . '/map-archivo.php';
map_ar_preparar();

// Todas las entradas, de la más nueva a la más vieja (la primera es la última transmisión).
$map_todas = get_posts( array(
	'posts_per_page'   => 400,
	'orderby'          => 'date',
	'order'            => 'DESC',
	'suppress_filters' => false,
) );
$map_ult = $map_todas ? $map_todas[0] : null;

// ¿Trae narración? (reproductor propio del sitio o el del expediente de Arkady)
$map_narra = function ( $post ) {
	$c = (string) $post->post_content;
	return false !== strpos( $c, 'map-audio-player' ) || false !== strpos( $c, 'ec-play' ) || false !== strpos( $c, 'ar-pista' );
};

// Al aire: la narración más reciente que no sea la última transmisión.
$map_aire = null;
foreach ( $map_todas as $k => $p ) {
	if ( $k > 0 && $map_narra( $p ) ) {
		$map_aire = $p;
		break;
	}
}

// Cuentas por categoría (con subcategorías) para los filtros del registro.
$map_cuenta = array();
foreach ( array_slice( $map_todas, 1 ) as $p ) {
	$ids = array();
	foreach ( get_the_category( $p->ID ) as $c ) {
		$ids[] = $c->term_id;
		$ids   = array_merge( $ids, get_ancestors( $c->term_id, 'category' ) );
	}
	foreach ( array_unique( $ids ) as $id ) {
		$map_cuenta[ $id ] = isset( $map_cuenta[ $id ] ) ? $map_cuenta[ $id ] + 1 : 1;
	}
}
$map_principales = array( 4, 15, 34, 908, 32, 545, 35 );
$map_cr_n        = ( new WP_Query( array( 'cat' => 1080, 'posts_per_page' => 1, 'fields' => 'ids' ) ) )->found_posts;

map_ar_abrir( 'Textos', 'Saltar a los textos' );
?>
<main class="ap" id="contenido">

	<div class="ap-wrap"><header class="ap-cab ap-ancho">
		<p class="ap-kicker">Archivo MAP</p>
		<h1>Textos</h1>
		<p class="ap-intro">Miradas crudas y reflexivas sobre política, cultura y sociedad. Textos que buscan abrir preguntas más que cerrar respuestas. Desde las voces de <b>Sangre, Sombras &amp; Asfalto</b> — sin concesiones.</p>
	</header></div>

	<?php if ( $map_ult ) :
		$url  = get_permalink( $map_ult );
		$cat  = map_ar_categoria( $map_ult->ID );
		$ext  = has_excerpt( $map_ult ) ? trim( wp_strip_all_tags( get_the_excerpt( $map_ult ) ) ) : '';
		$min  = map_ar_minutos( map_ar_texto( $map_ult->ID ) );
		?>
	<div class="ap-wrap"><section class="ap-ultima ap-ancho" aria-labelledby="ap-ultima-t">
		<div class="ar-tit"><h2>Última transmisión</h2><span><?php echo esc_html( get_the_date( 'j', $map_ult ) . ' ' . map_ar_mes( $map_ult ) . ' ' . get_the_date( 'Y', $map_ult ) ); ?></span></div>
		<?php if ( has_post_thumbnail( $map_ult ) ) : ?>
		<a class="ap-ultima__foto" href="<?php echo esc_url( $url ); ?>" tabindex="-1" aria-hidden="true"><?php echo get_the_post_thumbnail( $map_ult, 'large', array( 'loading' => 'eager', 'fetchpriority' => 'high', 'sizes' => '(max-width: 860px) 100vw, 620px' ) ); ?></a>
		<?php endif; ?>
		<div class="ap-ultima__txt">
			<?php if ( $cat ) : ?><p class="ap-kicker"><?php echo esc_html( $cat ); ?></p><?php endif; ?>
			<h3 id="ap-ultima-t"><a href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( get_the_title( $map_ult ) ); ?></a></h3>
			<?php if ( $ext && mb_strlen( $ext ) <= 220 ) : ?><p class="ap-bajada"><?php echo esc_html( $ext ); ?></p><?php endif; ?>
			<p class="ap-meta"><?php echo esc_html( get_the_author_meta( 'display_name', $map_ult->post_author ) . ' · ' . $min . ' min de lectura' . ( $map_narra( $map_ult ) ? ' · con narración' : '' ) ); ?></p>
			<div class="ap-acciones">
				<a class="ap-boton" href="<?php echo esc_url( $url ); ?>">Leer la entrada</a>
				<?php if ( $map_narra( $map_ult ) ) : ?><a class="ap-boton ap-boton--linea" href="<?php echo esc_url( $url ); ?>">▶ Escuchar la narración</a><?php endif; ?>
			</div>
		</div>
	</section></div>
	<?php endif; ?>

	<div class="ap-wrap"><section class="ap-proyecto ap-ancho" aria-labelledby="ap-cr">
		<a class="ap-libro" href="<?php echo esc_url( home_url( '/cronicas-del-refugio/' ) ); ?>" aria-label="Crónicas del Refugio, portada del libro">
			<img src="<?php echo esc_url( content_url( '/uploads/2026/04/idcdr2.webp' ) ); ?>" width="1200" height="1800" loading="lazy" alt="Portada del libro Crónicas del Refugio" onerror="this.parentNode.classList.add('sin-foto')">
			<span class="ap-libro__alt" aria-hidden="true"><b>Crónicas del Refugio</b><i>y otras geografías de la memoria</i><small>Valdo Jiménez V.</small></span>
		</a>
		<div class="ap-proyecto__cuerpo">
			<div class="ap-proyecto__ficha"><span>Proyecto literario</span><span>En curso</span><span><?php echo (int) $map_cr_n; ?> crónicas</span><span>Desde 2022</span></div>
			<h2 id="ap-cr">Crónicas del Refugio</h2>
			<p class="ap-proyecto__sub">y otras geografías de la memoria</p>
			<p>Comenzó a tomar forma en el 2022, luego de que una crecida desapareciera mi casa. Son crónicas de una Costa Rica que no aparece en las guías turísticas, y que sin embargo está muy viva.</p>
			<a class="ap-boton" href="<?php echo esc_url( home_url( '/cronicas-del-refugio/' ) ); ?>">Entrar a las crónicas →</a>
		</div>
	</section></div>

	<?php if ( $map_aire ) :
		$serie = function_exists( 'get_field' ) ? (string) get_field( 'bitacora_numero', $map_aire->ID ) : '';
		$rot   = map_ar_categoria( $map_aire->ID ) . ( $serie ? ' · Bitácora ' . $serie : '' );
		?>
	<div class="ap-wrap"><section class="ap-aire ap-ancho" aria-labelledby="ap-aire-t">
		<div class="ar-tit"><h2 id="ap-aire-t">Al aire</h2><span>la última narración</span></div>
		<div class="ap-aire__fila">
			<a class="ar-play ap-aire__play" href="<?php echo esc_url( get_permalink( $map_aire ) ); ?>" aria-label="Escuchar <?php echo esc_attr( get_the_title( $map_aire ) ); ?>"><i aria-hidden="true"></i></a>
			<div class="ap-aire__txt">
				<span class="ar-meta"><?php echo esc_html( $rot ); ?></span>
				<a class="ap-aire__nombre" href="<?php echo esc_url( get_permalink( $map_aire ) ); ?>"><?php echo esc_html( get_the_title( $map_aire ) ); ?></a>
			</div>
			<a class="ap-aire__todos" href="<?php echo esc_url( home_url( '/podcast/' ) ); ?>">Todos los episodios →</a>
		</div>
	</section></div>
	<?php endif; ?>

	<div class="ap-wrap"><section class="ap-anto ap-ancho" aria-labelledby="ap-anto-t">
		<figure class="ap-anto__tapa">
			<img src="<?php echo esc_url( content_url( '/uploads/2026/10/antologia-portada-nc-400.webp' ) ); ?>" width="400" height="536" loading="lazy" alt="Portada del libro Antología: Señales todavía activas, de Púa Ediciones: un hombre bebe de un vaso de cerveza en una cantina" onerror="this.parentNode.classList.add('sin-foto')">
			<span class="ap-anto__alt" aria-hidden="true">Antología</span>
		</figure>
		<div class="ap-anto__cuerpo">
			<div class="ap-proyecto__ficha"><span>Libro físico</span><span>Púa Ediciones</span><span>Varios autores</span><span>En preparación</span></div>
			<h2 id="ap-anto-t">Antología — Señales todavía activas</h2>
			<p>Faunos persistentes. Cantinas ocultas. Café para el descenso. Material recuperado de una época que todavía no termina de morirse. Con el sello de MAP Radio CR.</p>
		</div>
	</section></div>

	<div class="ap-wrap"><section class="ap-lista-ancha ap-ancho" aria-labelledby="ap-ult-t">
		<div class="ar-tit"><h2 id="ap-ult-t">Últimos artículos</h2><span>registro del archivo</span></div>
		<div class="ap-filtros" id="ap-filtros" role="group" aria-label="Filtrar por categoría">
			<button type="button" data-cat="todos" aria-pressed="true">Todos</button>
			<?php
			$boton = function ( $id ) use ( $map_cuenta ) {
				$t = get_term( $id, 'category' );
				if ( ! $t || is_wp_error( $t ) || empty( $map_cuenta[ $id ] ) ) {
					return '';
				}
				return '<button type="button" data-cat="' . (int) $id . '" aria-pressed="false">' . esc_html( $t->name ) . ' <small>' . (int) $map_cuenta[ $id ] . '</small></button>';
			};
			foreach ( $map_principales as $id ) {
				echo $boton( $id ); // phpcs:ignore
			}
			$otros = array_diff( array_keys( $map_cuenta ), $map_principales, array( 1 ) );
			if ( $otros ) :
				?>
			<button type="button" class="ap-filtros__mas" aria-expanded="false">Más ▾</button>
			<div class="ap-filtros__otros" hidden><?php
				foreach ( $otros as $id ) {
					echo $boton( $id ); // phpcs:ignore
				}
			?></div>
			<?php endif; ?>
		</div>
		<ol class="ar-lista" id="ap-registro"><?php
		foreach ( array_slice( $map_todas, 1 ) as $p ) {
			$ids   = array();
			$names = array();
			foreach ( get_the_category( $p->ID ) as $c ) {
				if ( 'uncategorized' === $c->slug ) {
					continue;
				}
				$names[] = $c->name;
				$ids[]   = $c->term_id;
				$ids     = array_merge( $ids, get_ancestors( $c->term_id, 'category' ) );
			}
			$anio = get_the_date( 'Y', $p );
			echo '<li data-cats="' . esc_attr( implode( ',', array_unique( $ids ) ) ) . '"><span class="ar-marca ar-marca--fecha"><b>' . esc_html( get_the_date( 'd', $p ) ) . '</b>' . esc_html( map_ar_mes( $p ) ) . '</span><div><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a><span class="ar-meta">' . esc_html( implode( ' · ', $names ) . ( gmdate( 'Y' ) !== $anio ? ' · ' . $anio : '' ) ) . '</span></div></li>';
		}
		?></ol>
		<p class="ap-vacio" id="ap-vacio" hidden>Todavía no hay textos en esta categoría.</p>
		<button type="button" class="ap-mas" id="ap-mas" hidden>Cargar más →</button>
	</section></div>

	<?php $map_pop = array_slice( map_ar_populares(), 0, 5 ); if ( $map_pop ) : ?>
	<div class="ap-wrap"><section class="ap-lista-ancha ap-ancho" aria-labelledby="ap-top-t">
		<div class="ar-tit"><h2 id="ap-top-t">Lo más leído</h2><span>contador del sitio</span></div>
		<ol class="ar-lista"><?php
		foreach ( $map_pop as $k => $pid ) {
			echo '<li><span class="ar-marca">' . ( $k + 1 ) . '</span><div><a href="' . esc_url( get_permalink( $pid ) ) . '">' . esc_html( get_the_title( $pid ) ) . '</a><span class="ar-meta">' . esc_html( map_ar_categoria( $pid ) ) . '</span></div></li>';
		}
		?></ol>
	</section></div>
	<?php endif; ?>

</main>
<?php map_ar_cerrar();

<?php
/**
 * MAP 2027 · Podcast (página «podcast»)
 * Generada desde la maqueta aprobada (gen_podcast.py). La papelería compartida está en map-archivo.php;
 * el reproductor de la página está en /wp-content/uploads/2026/archivo/podcast.js.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once get_stylesheet_directory() . '/map-archivo.php';
map_ar_preparar();
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_script( 'map-podcast', content_url( '/uploads/2026/archivo/podcast.js' ), array(), MAP_AR_VER, array( 'in_footer' => true, 'strategy' => 'defer' ) );
}, 21 );
map_ar_abrir( 'Podcast', 'Saltar a los episodios' );
?>
<main class="ap pc" id="contenido">

  <!-- 1 · cabecera -->
  <div class="ap-wrap"><header class="pc-cab ap-ancho">
    <div class="pc-cab__txt">
      <p class="ap-kicker"><?php echo map_ar_texto_campo( 'pc_kicker', 'MAP Radio Radio Pachuko · desde 2016' ); ?></p>
      <h1>Podcast</h1>
      <p class="pc-intro"><?php echo map_ar_texto_campo( 'pc_intro', 'Más de 200 episodios. Un podcast de Costa Rica con conversaciones, relatos y poesía de gente que vale la pena escuchar. Desde 2016, haciendo podcast con alma y siempre con una idea clara de lo que queremos decir.' ); ?></p>
      <dl class="pc-datos">
        <div><dt>Episodios</dt><dd><?php echo map_ar_texto_campo( 'pc_dato_episodios', '200+' ); ?></dd></div>
        <div><dt>Series</dt><dd>3</dd></div>
        <div><dt>Al aire desde</dt><dd>2016</dd></div>
      </dl>
      <a class="ap-boton" href="https://open.spotify.com/show/6XGk2uLzxlDTm7Op6mqEBB">Escuchar en Spotify ↗</a>
    </div>
    <figure class="pc-cab__foto">
      <img src="<?php echo esc_url( home_url( '/' ) ); ?>wp-content/uploads/2026/06/podcast-mapradio-de-costa-rica.webp" alt="Sesión de grabación de MAP Radio, podcast de Costa Rica, con micrófono de campo y guitarra" onerror="this.parentNode.classList.add('sin-foto')">
      <figcaption><?php echo map_ar_texto_campo( 'pc_pie_foto', 'Sesión de grabación · MAP Radio Radio Pachuko' ); ?></figcaption>
    </figure>
  </header></div>

  <!-- 2 · sintonizador -->
  <div class="ap-wrap"><nav class="pc-dial ap-ancho" aria-label="Series">
    <span class="pc-dial__lab">Sintonizar una serie</span>
    <div class="pc-dial__escala" aria-hidden="true"></div>
    <ol>
      <li><a href="#bastardos"><span>01</span><b>Los Bastardos de Poveda</b><i><?php echo map_ar_texto_campo( 'pc_bastardos_subtitulo', 'Escritores y poetas de Alajuela' ); ?></i></a></li>
      <li><a href="#relatos"><span>02</span><b>Relatos Cortos</b><i><?php echo map_ar_texto_campo( 'pc_relatos_subtitulo', 'Textos propios y de amigos de MAP' ); ?></i></a></li>
      <li><a href="#rpgp"><span>03</span><b>RPGP Radio Pachuko</b><i><?php echo map_ar_texto_campo( 'pc_rpgp_subtitulo', 'Grandes personajes sin vitrina' ); ?></i></a></li>
    </ol>
  </nav></div>

  <!-- 2b · donde empezó todo -->
  <div class="ap-wrap"><section class="pc-origen ap-ancho" id="origen" aria-labelledby="pc-origen-t">
    <div class="pc-origen__sello" aria-hidden="true"><b>Rescatado</b><span>Borrado de Spotify e iVoox</span></div>
    <p class="pc-origen__lab"><?php echo map_ar_texto_campo( 'pc_origen_rotulo', 'Donde empezó todo · Los Bastardos de Poveda · Episodio 1' ); ?></p>
    <h2 id="pc-origen-t"><?php echo map_ar_texto_campo( 'pc_origen_nombre', 'Bernabé Berrocal' ); ?></h2>
    <p class="pc-origen__meta"><?php echo map_ar_texto_campo( 'pc_origen_datos', 'Veterinario · 28 de agosto de 2020 · 1 h 21 min' ); ?></p>
    <div class="pc-origen__txt">
      <div><?php echo map_ar_html_campo( 'pc_origen_col_1', '<p>El primer episodio de la serie. Lo grabamos en agosto de 2020, en plena pandemia. Teníamos mucha ilusión, porque casi nunca uno escucha este tipo de conversaciones con escritores: tan distendidas, con muchos deseos de aprender de un autor, de su proceso creativo, de su oficio, y eso sin elevarlo a un ser de luz que no puede codificar su mensaje para que un mortal cualquiera lo pueda entender.</p>' ); ?></div>
      <div><?php echo map_ar_html_campo( 'pc_origen_col_2', '<p>Una serie que, si bien tiene más de diez episodios, siento yo que evolucionó a RPGP: Radio Pachuko Grandes Personajes, donde también nos hemos sentado a hablar con escritores y con personas que sentimos tienen una gran historia que compartir, incluso cuando las dos existían en paralelo. En ocasiones me pregunto si deberían fusionarse, ser una sola, o dejar que sigan existiendo.</p>' ); ?></div>
      <div><?php echo map_ar_html_campo( 'pc_origen_col_3', '<p>Estaba en Spotify, y la plataforma lo eliminó por derechos de autor; también lo habían eliminado en iVoox. La copia que guardábamos en YouTube quedó en el antiguo canal de Nasional, que unos ladrones de cripto rusos se robaron justo después de publicar este episodio.</p><p>Increíble que hayan pasado seis años.</p>' ); ?></div>
    </div>
    <div class="pc-cinta" data-src="<?php echo esc_url( home_url( '/' ) ); ?>wp-content/uploads/2026/10/bastardos-de-poveda-ep01-2020.mp3" data-dur="4902">
      <button type="button" class="pc-cinta__play" aria-label="Escuchar el episodio 1 completo"><i aria-hidden="true"></i></button>
      <div class="pc-cinta__cuerpo">
        <div class="pc-cinta__barra" role="slider" tabindex="0" aria-label="Posición del episodio" aria-valuemin="0" aria-valuemax="4902" aria-valuenow="0"><span></span></div>
        <div class="pc-cinta__pie"><span class="pc-cinta__t">0:00:00 / 1:21:42</span><span class="pc-cinta__saltos"><button type="button" data-salto="-15">−15 s</button><button type="button" data-salto="30">+30 s</button></span></div>
      </div>
    </div>
  </section></div>

  <!-- 3 · el universo -->
  <div class="ap-wrap"><section class="pc-universo ap-ancho" aria-labelledby="pc-u-t">
    <h2 id="pc-u-t" class="pc-universo__tit"><?php echo map_ar_texto_campo( 'pc_universo_titulo', 'El universo MAP Radio' ); ?></h2>
    <p><?php echo map_ar_texto_campo( 'pc_universo_texto', 'Este universo va por capas: conversaciones largas, relatos breves, poesía frente a cámara y personajes que no aparecerán nunca en los grandes medios de comunicación masiva de Costa Rica, al menos no, siendo quienes en realidad son. Acá vas a encontrar una selección curada de cada serie, con contexto y anécdotas que explican cómo nació cada episodio y por qué vale la pena escucharlo.' ); ?></p>
  </section></div>

  
  <div class="ap-wrap"><section class="pc-serie ap-ancho" id="bastardos" aria-labelledby="pc-bastardos-t">
    <header class="pc-serie__cab">
      <span class="pc-num">01</span>
      <div><h2 id="pc-bastardos-t">Los Bastardos de Poveda</h2><p><?php echo map_ar_texto_campo( 'pc_bastardos_subtitulo', 'Escritores y poetas de Alajuela' ); ?></p></div>
    </header>
    <div class="pc-serie__grid">
      <div class="lb-texto pc-serie__txt"><?php echo map_ar_html_campo( 'pc_bastardos_texto', '<p>Nombre acuñado entre el escritor alajuelense Sergio Murillo y Bernardo Soto —quien todavía se resiste a llamarse "escritor". Serie de conversaciones con escritores, poetas, gestores culturales y artistas, casi todos de la ardiente Alajuela. Son charlas sin apuro: a veces intensas, otras llenas de carcajadas, siempre con la sensación de que la vida y la literatura se cruzan en la mesa.</p><p>Entre mis episodios favoritos están el de Luis Poveda y <a href="https://open.spotify.com/episode/30cZBWLrhIQnQaNmqrOoBZ">16 Reds, que debe una segunda parte</a>. Con Bernardo grabamos dos veces, en plena pandemia y en estados de consciencia bastante psicodélicos. Nadie esperaba mucho de ese episodio ni de MAPRADIO en aquel momento, sin embargo, hoy —con más de 200 programas— nos queda clarísimo: Los Bastardos de Poveda no es un hobby. Es parte del ADN de MAP RADIO.</p>' ); ?></div>
      <aside class="pc-dest" aria-label="Episodio destacado · #10">
        <span class="pc-dest__lab"><?php echo map_ar_texto_campo( 'pc_bastardos_destacado_rotulo', 'Episodio destacado · #10' ); ?></span>
        <b class="pc-dest__nom"><?php echo map_ar_texto_campo( 'pc_bastardos_destacado_nombre', 'Luis Poveda' ); ?></b>
        <p><?php echo map_ar_texto_campo( 'pc_bastardos_destacado_texto', 'El bicho empezaba a perder fuerza, no se grabó en noviembre sino en enero o febrero. En algún lugar de la garita de Alajuela. Entre cervezas y estados muy alterados de consciencia, tuvimos la oportunidad de conversar con Don Luis Poveda. Nos explotó la cabeza cuando todos, incluso quien leía los poemas que sacaba de un bolso tejido muy viejo, se maravillaba asombrado al descubrir aquellas piezas exquisitas. Así 3 quijotes, escondidos en una mandarina, sentían como les reventaba el cerebro al escuchar el poema: YO SOY MULTIPICHA.' ); ?></p>
        <button type="button" class="pc-play" data-sp="0bQOtOpPP0W8T4Aj1Gtwma" data-tipo="episode"><i aria-hidden="true"></i>Escuchar el episodio</button>
      </aside>
    </div>
    <blockquote class="lb-cita pc-lectura">
        <span class="pc-lectura__lab">Lectura recomendada · Editorial MAP</span>
        <p>"Acerca de las causas perdidas o, mejor dicho, empresas absurdas. Solo así, desde mi punto de vista, pueden perseguirse eso que se conoce como «causas perdidas» que yo prefiero llamar «empresas absurdas». La felicidad de (intentar) conseguir aquello que el lente de las convenciones sociales determina como absurdo torna, a mi juicio, menos perdido y, por ende, más tangible su logro."</p>
        <div class="lb-audio" data-src="<?php echo esc_url( home_url( '/' ) ); ?>wp-content/uploads/2026/10/ignacio-castillo-etica-tortuguista.mp3">
          <button type="button" class="lb-audio__play" aria-label="Escuchar el comentario de Ignacio Castillo"><i aria-hidden="true"></i></button>
          <div class="lb-audio__barra" aria-hidden="true"><span></span></div>
          <span class="lb-audio__t">0:36</span>
        </div>
        <footer><b>Nacho Alemán</b><span>Acerca de las causas perdidas</span><a href="<?php echo esc_url( home_url( '/' ) ); ?>acerca-de-las-causas-perdidas/">Leer el artículo completo →</a></footer>
      </blockquote><div class="pc-retratos"><div class="pc-retratos__cab"><h3>Los retratos</h3><span>Nueve protagonistas · plumilla de carbón</span></div><ol><li class="pc-ret" id="retrato-01"><figure><img src="<?php echo esc_url( content_url( '/uploads/2026/archivo/podcast/retratos/' ) ); ?>bastardos-poveda-01.jpg" alt="Retrato en plumilla de Valdo, con gorro de lana, anteojos de pasta y barba, firmado Los Bastardos de Poveda" loading="lazy" width="600" height="600"></figure><div class="pc-ret__txt"><span class="pc-ret__nn">Retrato 01</span><b>Valdo</b><span class="pc-ret__fecha">28 jun 2020</span><p>…poco a poco nos íbamos dando cuenta hacia dónde apuntaba la serie.</p><button type="button" class="pc-ret__oir" data-sp="6Zq8DQzqHFvSRJe8aCOmFx" data-tipo="episode"><i aria-hidden="true"></i>Escuchar aquí</button></div></li><li class="pc-ret" id="retrato-02"><figure><img src="<?php echo esc_url( content_url( '/uploads/2026/archivo/podcast/retratos/' ) ); ?>bastardos-poveda-02.jpg" alt="Retrato en plumilla de Bernabé Berrocal, con pelo largo, bigote y barba, firmado Los Bastardos de Poveda" loading="lazy" width="600" height="600"></figure><div class="pc-ret__txt"><span class="pc-ret__nn">Retrato 02</span><b>Bernabé Berrocal</b><span class="pc-ret__fecha">28 ago 2020</span><p>…difícil entender este camino desde la biología hasta las letras.</p><a class="pc-ret__oir" href="#origen"><i aria-hidden="true"></i>Escuchar · Donde empezó todo</a></div></li><li class="pc-ret" id="retrato-03"><figure><img src="<?php echo esc_url( content_url( '/uploads/2026/archivo/podcast/retratos/' ) ); ?>bastardos-poveda-03.jpg" alt="Retrato en plumilla de David Monge, con sombrero, anteojos y barba de candado, firmado Los Bastardos de Poveda" loading="lazy" width="600" height="600"></figure><div class="pc-ret__txt"><span class="pc-ret__nn">Retrato 03</span><b>David Monge</b><span class="pc-ret__fecha">24 jun 2020</span><p>El ejercicio mental de quien crece con la lectura.</p><button type="button" class="pc-ret__oir" data-sp="1wbp43vNmlT75UrDvqjgOb" data-tipo="episode"><i aria-hidden="true"></i>Escuchar aquí</button></div></li><li class="pc-ret" id="retrato-04"><figure><img src="<?php echo esc_url( content_url( '/uploads/2026/archivo/podcast/retratos/' ) ); ?>bastardos-poveda-04.jpg" alt="Retrato en plumilla de Daniela Herrera, sonriente, con pelo largo ondulado y anteojos sobre la cabeza, firmado Los Bastardos de Poveda" loading="lazy" width="600" height="600"></figure><div class="pc-ret__txt"><span class="pc-ret__nn">Retrato 04</span><b>Daniela Herrera</b><span class="pc-ret__fecha">16 feb 2024</span><p>La vida teje historias que desafían el alma.</p><button type="button" class="pc-ret__oir" data-sp="0sr3OW4rOc68Bh2O0dOO2q" data-tipo="episode"><i aria-hidden="true"></i>Escuchar aquí</button></div></li><li class="pc-ret" id="retrato-05"><figure><img src="<?php echo esc_url( content_url( '/uploads/2026/archivo/podcast/retratos/' ) ); ?>bastardos-poveda-05.jpg" alt="Retrato en plumilla de Bernardo Corrales, con pelo corto y una sonrisa amplia, firmado Los Bastardos de Poveda" loading="lazy" width="600" height="600"></figure><div class="pc-ret__txt"><span class="pc-ret__nn">Retrato 05</span><b>Bernardo Corrales</b><span class="pc-ret__fecha">9 jun 2020</span><p>El hijo del aserrín, madera y poesía.</p><button type="button" class="pc-ret__oir" data-sp="4hR9BZzsEUIPAUGPSpSW46" data-tipo="episode"><i aria-hidden="true"></i>Escuchar aquí</button></div></li><li class="pc-ret" id="retrato-06"><figure><img src="<?php echo esc_url( content_url( '/uploads/2026/archivo/podcast/retratos/' ) ); ?>bastardos-poveda-06.jpg" alt="Retrato en plumilla de Sergio Murillo, con anteojos oscuros, abrigo y bufanda, firmado Los Bastardos de Poveda" loading="lazy" width="600" height="600"></figure><div class="pc-ret__txt"><span class="pc-ret__nn">Retrato 06</span><b>Sergio Murillo</b><span class="pc-ret__fecha">27 abr 2022</span><p>…impíos de letra y leyendas con miel de mango.</p><button type="button" class="pc-ret__oir" data-sp="3sfP2f6qG8UgFzoo6K4hpH" data-tipo="episode"><i aria-hidden="true"></i>Escuchar aquí</button></div></li><li class="pc-ret" id="retrato-07"><figure><img src="<?php echo esc_url( content_url( '/uploads/2026/archivo/podcast/retratos/' ) ); ?>bastardos-poveda-07.jpg" alt="Retrato en plumilla de Piro Soto, con pelo canoso, mirando hacia un lado, firmado Los Bastardos de Poveda" loading="lazy" width="600" height="600"></figure><div class="pc-ret__txt"><span class="pc-ret__nn">Retrato 07</span><b>Piro Soto</b><span class="pc-ret__fecha">28 mar 2021</span><p>16 Reds o Aserrín, Fuego &amp; Viento… ¿Qué le preocupa? ¿A qué le tiene miedo? ¿Le vale el qué dirán?</p><button type="button" class="pc-ret__oir" data-sp="30cZBWLrhIQnQaNmqrOoBZ" data-tipo="episode"><i aria-hidden="true"></i>Escuchar aquí</button></div></li><li class="pc-ret" id="retrato-08"><figure><img src="<?php echo esc_url( content_url( '/uploads/2026/archivo/podcast/retratos/' ) ); ?>bastardos-poveda-08.jpg" alt="Retrato en plumilla de Fabián González, con sombrero de ala, anteojos, barba y camisa floreada, firmado Los Bastardos de Poveda" loading="lazy" width="600" height="600"></figure><div class="pc-ret__txt"><span class="pc-ret__nn">Retrato 08</span><b>Fabián González</b><span class="pc-ret__fecha">15 oct 2020</span><p>A la gente le prohibían patinar y aun así, la gente patinaba.</p><button type="button" class="pc-ret__oir" data-sp="6ovbEL7YPhrgSSUNQTpyNw" data-tipo="episode"><i aria-hidden="true"></i>Escuchar aquí</button></div></li><li class="pc-ret" id="retrato-09"><figure><img src="<?php echo esc_url( content_url( '/uploads/2026/archivo/podcast/retratos/' ) ); ?>bastardos-poveda-09.jpg" alt="Retrato en plumilla de Luis Poveda, con gorro de lana, bigote blanco y una sonrisa amplia, firmado Los Bastardos de Poveda" loading="lazy" width="600" height="600"></figure><div class="pc-ret__txt"><span class="pc-ret__nn">Retrato 09</span><b>Luis Poveda</b><span class="pc-ret__fecha">26 nov 2022</span><p>Entre cervezas y estados muy alterados de consciencia.</p><button type="button" class="pc-ret__oir" data-sp="0bQOtOpPP0W8T4Aj1Gtwma" data-tipo="episode"><i aria-hidden="true"></i>Escuchar aquí</button></div></li></ol></div>
    <div class="pc-completa">
      <span>Serie completa · Los Bastardos de Poveda</span>
      <button type="button" class="ap-boton ap-boton--linea" data-sp="3fdA06l2zgrJqjiqr1FXlO" data-tipo="playlist">▶ Abrir la lista de episodios</button>
    </div>
  </section></div>
  <div class="ap-wrap"><section class="pc-serie ap-ancho" id="relatos" aria-labelledby="pc-relatos-t">
    <header class="pc-serie__cab">
      <span class="pc-num">02</span>
      <div><h2 id="pc-relatos-t">Relatos Cortos</h2><p><?php echo map_ar_texto_campo( 'pc_relatos_subtitulo', 'Textos propios y de amigos de MAP' ); ?></p></div>
    </header>
    <div class="pc-serie__grid">
      <div class="lb-texto pc-serie__txt"><?php echo map_ar_html_campo( 'pc_relatos_texto', '<p>En Relatos Cortos el director de MAPRADIOCR comparte textos propios y de amigos cercanos a MAP. Algunas piezas nacieron para este espacio, otras son rescates que merecían una segunda vida.</p><p>Algunos textos vienen acompañados de música. En otros momentos el texto es seco; lo importante es que la palabra respire y tenga su propio pulso. No se trata de añadir música como elemento decorativo: también incorporamos efectos especiales de sonido para construir un ambiente que envuelva a quien escucha los relatos. Esta serie es para historias que se cuentan en pocos minutos pero se quedan rondando mucho tiempo después.</p>' ); ?></div>
      <aside class="pc-dest" aria-label="Episodio destacado · Los estudios de campo del Dr. Arkady Volkov Lazenko">
        <span class="pc-dest__lab"><?php echo map_ar_texto_campo( 'pc_relatos_destacado_rotulo', 'Episodio destacado · Los estudios de campo del Dr. Arkady Volkov Lazenko' ); ?></span>
        <b class="pc-dest__nom"><?php echo map_ar_texto_campo( 'pc_relatos_destacado_nombre', 'Bitácora 6: Receptor transdimensional de banda vacante residual VX-996' ); ?></b>
        <p><?php echo map_ar_texto_campo( 'pc_relatos_destacado_texto', 'El Dr. Arkady Volkov Lazenko existe. Camina por este mundo y ahora se encuentra en su propio universo.' ); ?></p>
        <a class="pc-play" href="#vx"><i aria-hidden="true"></i>Sintonizar en el receptor</a>
      </aside>
    </div>
        <div class="vx" id="vx" data-src="<?php echo esc_url( home_url( '/' ) ); ?>wp-content/uploads/2026/10/estudios-de-campo-bitacora-6-receptor-vx-996.mp3" data-dur="3800.92">
      <div class="vx__placa">
        <span class="vx__marca">Receptor VX-996</span>
        <span class="vx__banda">Banda vacante residual · Los estudios de campo del Dr. Arkady Volkov Lazenko</span>
        <span class="vx__estado"><i class="vx__lampara" aria-hidden="true"></i><b id="vx-estado">En espera</b></span>
      </div>
      <div class="vx__dial" id="vx-dial" aria-hidden="true">
        <div class="vx__escala" id="vx-escala"><div class="vx__aguja" id="vx-aguja"></div></div>
      </div>
      <canvas class="vx__onda" id="vx-onda" height="72" role="slider" tabindex="0" aria-label="Posición en el episodio" aria-valuemin="0" aria-valuemax="3800.92" aria-valuenow="0"></canvas>
      <div class="vx__mandos">
        <button type="button" class="vx__salto" id="vx-atras" aria-label="Retroceder 15 segundos">−15</button>
        <button type="button" class="vx__play" id="vx-play" aria-label="Sintonizar y escuchar"><i aria-hidden="true"></i></button>
        <button type="button" class="vx__salto" id="vx-adelante" aria-label="Adelantar 15 segundos">+15</button>
        <span class="vx__tiempo" id="vx-tiempo">00:00 / 1:03:20</span>
        <a class="vx__spotify" href="https://open.spotify.com/episode/5y6aZCiib54ScVg3EnUu2W">También en Spotify ↗</a>
      </div>
      <p class="vx__nota"></p>
    </div>
    

    <div class="pc-completa">
      <span>Serie completa · Relatos Cortos</span>
      <button type="button" class="ap-boton ap-boton--linea" data-sp="6Swta2Qt0hI72V9Luh07mj" data-tipo="playlist">▶ Abrir la lista de episodios</button>
    </div>
  </section></div>
  <div class="ap-wrap"><section class="pc-serie ap-ancho" id="rpgp" aria-labelledby="pc-rpgp-t">
    <header class="pc-serie__cab">
      <span class="pc-num">03</span>
      <div><h2 id="pc-rpgp-t">RPGP Radio Pachuko</h2><p><?php echo map_ar_texto_campo( 'pc_rpgp_subtitulo', 'Grandes personajes sin vitrina' ); ?></p></div>
    </header>
    <div class="pc-serie__grid">
      <div class="lb-texto pc-serie__txt"><?php echo map_ar_html_campo( 'pc_rpgp_texto', '<p>En RPGP no buscamos "famosillos" ni figuras de vitrina. Aquí se sientan personas que apreciamos y que han marcado nuestra vida de una u otra manera. Sus historias pueden ser sorprendentes, divertidas, conmovedoras o todo al mismo tiempo.</p><p>Lo importante es que hay verdad y experiencia detrás de cada palabra. Son conversaciones que no escucharías en otros espacios porque no se trata de marketing, sino de compartir momentos reales con gente que tiene algo genuino que compartir.</p>' ); ?></div>
      <aside class="pc-dest" aria-label="Episodio destacado · #22 · 2021">
        <span class="pc-dest__lab"><?php echo map_ar_texto_campo( 'pc_rpgp_destacado_rotulo', 'Episodio destacado · #22 · 2021' ); ?></span>
        <b class="pc-dest__nom"><?php echo map_ar_texto_campo( 'pc_rpgp_destacado_nombre', 'Carlos Pincel' ); ?></b>
        <p><?php echo map_ar_texto_campo( 'pc_rpgp_destacado_texto', 'Un sábado de mayo, aún con el bicho persiguiendo a todo mundo. Nos sentamos con el mítico Pincel a conversar, al aire libre, entre cervezas y más cervezas. Carlos Pincel, la génesis del artista, su mano y la extensión de un pincel que emerge de una mente creativa, la que desarrolló personajes y cómics en una Tiquicia de antaño.' ); ?></p>
        <button type="button" class="pc-play" data-sp="4Qsr3Tu2sDm58gGSM1eYU2" data-tipo="episode"><i aria-hidden="true"></i>Escuchar el episodio</button>
      </aside>
    </div>
    
    <div class="pc-completa">
      <span>Serie completa · RPGP Radio Pachuko</span>
      <button type="button" class="ap-boton ap-boton--linea" data-sp="5OX4RYwRW7Y5rFjCcS5h64" data-tipo="playlist">▶ Abrir la lista de episodios</button>
    </div>
  </section></div>

  <!-- 8 · cierre -->
  <div class="ap-wrap"><section class="lb-cierre ap-ancho pc-cierre">
    <p><?php echo map_ar_texto_campo( 'pc_cierre_frase', 'Lo que viste fue nada más una extinta' ); ?> <span><?php echo map_ar_texto_campo( 'pc_cierre_remate', 'boca de cortesía.' ); ?></span></p>
    <div class="pc-cierre__txt">
      <a class="ap-boton" href="https://open.spotify.com/show/6XGk2uLzxlDTm7Op6mqEBB">Escuchar en Spotify ↗</a>
      <span><?php echo map_ar_texto_campo( 'pc_cierre_texto', 'Esto es apenas una parte de lo que hemos creado en MAP Radio Radio Pachuko. Cada serie, cada episodio y cada historia forma parte de un archivo vivo que seguimos construyendo desde 2016. Si algo de lo que escuchaste te movió, quedate cerca. Hay mucho más por descubrir, y las mejores conversaciones todavía no han pasado.' ); ?></span>
    </div>
  </section></div>
</main>
<?php map_ar_cerrar();

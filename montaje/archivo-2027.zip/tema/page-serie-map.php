<?php
/**
 * MAP 2027 · página «serie-map»
 * Generada desde la maqueta aprobada (gen_pagina.py seriemap). La papelería compartida está en map-archivo.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once get_stylesheet_directory() . '/map-archivo.php';
map_ar_preparar();
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_script( 'map-serie-map', content_url( '/uploads/2026/archivo/serie-map.js' ), array(), MAP_AR_VER, array( 'in_footer' => true, 'strategy' => 'defer' ) );
}, 21 );
map_ar_abrir( 'Serie MAP', 'Saltar a la serie' );
?>
<main class="ap pc sm" id="contenido">

  <!-- 1 · cabecera -->
  <div class="ap-wrap"><header class="pc-cab ap-ancho">
    <div class="pc-cab__txt">
      <p class="ap-kicker">MAP · Música, Arte &amp; Patineta · desde 2016</p>
      <h1>Serie MAP</h1>
      <p class="pc-intro">Serie documental sobre la música independiente, el arte y la patineta en Costa Rica. La primera temporada se transmitió por cable; la segunda está en preparación.</p>
      <dl class="pc-datos">
        <div><dt>Temporada 1</dt><dd>7 ep.</dd></div>
        <div><dt>Temporada 2</dt><dd>8 ep.</dd></div>
        <div><dt>Desde</dt><dd>2016</dd></div>
      </dl>
      <a class="ap-boton" href="#t1">Ver la temporada 1 ▸</a>
    </div>
    <figure class="pc-cab__foto">
      <img src="<?php echo esc_url( home_url( '/' ) ); ?>wp-content/uploads/2025/08/MAP-copy-1-scaled.webp" alt="Skater haciendo un truco aéreo sobre un bowl cubierto de grafiti mientras un camarógrafo, en cuclillas, lo graba de cerca" onerror="this.parentNode.classList.add('sin-foto')">
      <figcaption>MAP documentándose a sí mismo · 2016 · <span class="sm-nowrap">Fotografía: Randy Parker</span></figcaption>
    </figure>
  </header></div>

  <!-- 2 · qué es MAP -->
  <div class="ap-wrap"><section class="lb-sec lb-col" aria-labelledby="sm-que-t">
    <div class="ar-tit"><h2 id="sm-que-t">¿Qué es MAP?</h2><span>serie documental</span></div>
    <div class="lb-texto">
      <p>Enciendo la televisión y nada me habla a mí. La grilla entera parece hecha para premiar al que no tiene vergüenza, al que grita más fuerte, al que convirtió el ridículo en carrera. Y esa misma fórmula vacía que llena las pantallas del mundo se replica igualita en lo local, sin que nadie se sonroje.</p>
      <p>En algún momento dejamos de quejarnos y entendimos algo simple: si no vemos lo que queremos ver, lo tenemos que hacer nosotros.</p>
      <p>Así nace MAP. Conocemos gente con un talento enorme —pintan, patinan, hacen música, escriben prosa y poesía— y la mayoría nunca va a salir en ningún lado, porque no juega el juego del espectáculo. MAP es la ventana que los expone. Una serie que va a buscar las historias que de verdad valen la pena y las cuenta bien, con cuidado, sin convertirlas en circo.</p>
      <p>Porque esas historias existen. Lo que no existe es el ojo para reconocerlas. Los que deciden qué se produce en este país se mueven por una sola cosa, y no es la cultura: es la taquilla. No hay curaduría, no hay olfato, no hay interés en mirar donde no hay plata fácil. Por eso las mejores historias de Costa Rica siguen sin contarse.</p>
      <p><b>MAP es para contarlas.</b></p>
    </div>
  </section></div>

  <!-- 3 · temporada 1 · sala de proyección -->
  <div class="ap-wrap"><section class="lb-sec ap-ancho sm-sala" id="t1" aria-labelledby="sm-t1-t">
    <div class="ar-tit"><h2 id="sm-t1-t">Temporada 1</h2><span>sala de proyección · 7 episodios</span></div>
    <p class="sm-sala__intro">Planeamos ocho episodios y llegamos a siete. Elija un rollo y se proyecta aquí mismo.</p>
    <div class="sm-pantalla" id="sm-pantalla" aria-live="polite">
      <div class="sm-reposo"><span>Sala de proyección · Temporada 1</span><b>Elija un rollo</b></div>
    </div>
    <ol class="sm-rollos">
      <li><button type="button" class="sm-rollo" data-yt="PB6SnFlnb8o" data-titulo="Serie MAP · Episodio 01" aria-pressed="false" aria-label="Proyectar el episodio 01"><span class="sm-rollo__img"><img src="https://i.ytimg.com/vi/PB6SnFlnb8o/hqdefault.jpg" alt="" loading="lazy" onerror="this.remove()"><span class="sm-rollo__num">01</span><span class="sm-rollo__play" aria-hidden="true"></span></span><span class="sm-rollo__pie"><b>Episodio 01</b><i>Temporada 1</i></span></button></li>
      <li><button type="button" class="sm-rollo" data-yt="F9wLX6oaOmM" data-titulo="Serie MAP · Episodio 02" aria-pressed="false" aria-label="Proyectar el episodio 02"><span class="sm-rollo__img"><img src="https://i.ytimg.com/vi/F9wLX6oaOmM/hqdefault.jpg" alt="" loading="lazy" onerror="this.remove()"><span class="sm-rollo__num">02</span><span class="sm-rollo__play" aria-hidden="true"></span></span><span class="sm-rollo__pie"><b>Episodio 02</b><i>Temporada 1</i></span></button></li>
      <li><button type="button" class="sm-rollo" data-yt="qwx5L_enoNw" data-titulo="Serie MAP · Episodio 03" aria-pressed="false" aria-label="Proyectar el episodio 03"><span class="sm-rollo__img"><img src="https://i.ytimg.com/vi/qwx5L_enoNw/hqdefault.jpg" alt="" loading="lazy" onerror="this.remove()"><span class="sm-rollo__num">03</span><span class="sm-rollo__play" aria-hidden="true"></span></span><span class="sm-rollo__pie"><b>Episodio 03</b><i>Temporada 1</i></span></button></li>
      <li><button type="button" class="sm-rollo" data-yt="QR0Z23TyHpI" data-titulo="Serie MAP · Episodio 04" aria-pressed="false" aria-label="Proyectar el episodio 04"><span class="sm-rollo__img"><img src="https://i.ytimg.com/vi/QR0Z23TyHpI/hqdefault.jpg" alt="" loading="lazy" onerror="this.remove()"><span class="sm-rollo__num">04</span><span class="sm-rollo__play" aria-hidden="true"></span></span><span class="sm-rollo__pie"><b>Episodio 04</b><i>Temporada 1</i></span></button></li>
      <li><button type="button" class="sm-rollo" data-yt="GbF4s9WTb74" data-titulo="Serie MAP · Episodio 05" aria-pressed="false" aria-label="Proyectar el episodio 05"><span class="sm-rollo__img"><img src="https://i.ytimg.com/vi/GbF4s9WTb74/hqdefault.jpg" alt="" loading="lazy" onerror="this.remove()"><span class="sm-rollo__num">05</span><span class="sm-rollo__play" aria-hidden="true"></span></span><span class="sm-rollo__pie"><b>Episodio 05</b><i>Temporada 1</i></span></button></li>
      <li><button type="button" class="sm-rollo" data-yt="Wa-5an6RgW4" data-titulo="Serie MAP · Episodio 06" aria-pressed="false" aria-label="Proyectar el episodio 06"><span class="sm-rollo__img"><img src="https://i.ytimg.com/vi/Wa-5an6RgW4/hqdefault.jpg" alt="" loading="lazy" onerror="this.remove()"><span class="sm-rollo__num">06</span><span class="sm-rollo__play" aria-hidden="true"></span></span><span class="sm-rollo__pie"><b>Episodio 06</b><i>Temporada 1</i></span></button></li>
      <li><button type="button" class="sm-rollo" data-yt="QQUH3Go5VnA" data-titulo="Serie MAP · Episodio 07" aria-pressed="false" aria-label="Proyectar el episodio 07"><span class="sm-rollo__img"><img src="https://i.ytimg.com/vi/QQUH3Go5VnA/hqdefault.jpg" alt="" loading="lazy" onerror="this.remove()"><span class="sm-rollo__num">07</span><span class="sm-rollo__play" aria-hidden="true"></span></span><span class="sm-rollo__pie"><b>Episodio 07</b><i>Temporada 1</i></span></button></li>
      <li><div class="sm-rollo sm-rollo--vacio" role="img" aria-label="Episodio 08: pendiente. Se acabó el combustible."><span class="sm-rollo__img"><svg class="sm-tanque" viewBox="0 0 320 180" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><rect width="320" height="180" fill="var(--ar-tinta)"/><path d="M81.7 106.0 A104 104 0 0 1 270.3 106.0" fill="none" stroke="var(--ar-papel)" stroke-opacity=".35" stroke-width="1"/><line x1="81.7" y1="106.0" x2="96.2" y2="112.8" stroke="var(--ar-acento)" stroke-width="3"/><line x1="88.9" y1="93.2" x2="95.6" y2="97.5" stroke="var(--ar-acento)" stroke-width="1.5"/><line x1="97.8" y1="81.4" x2="103.8" y2="86.7" stroke="var(--ar-acento)" stroke-width="1.5"/><line x1="108.3" y1="71.1" x2="113.5" y2="77.1" stroke="var(--ar-papel)" stroke-width="1.5"/><line x1="120.1" y1="62.3" x2="128.7" y2="75.8" stroke="var(--ar-papel)" stroke-width="3"/><line x1="133.1" y1="55.3" x2="136.4" y2="62.6" stroke="var(--ar-papel)" stroke-width="1.5"/><line x1="146.9" y1="50.2" x2="149.1" y2="57.8" stroke="var(--ar-papel)" stroke-width="1.5"/><line x1="161.3" y1="47.0" x2="162.4" y2="55.0" stroke="var(--ar-papel)" stroke-width="1.5"/><line x1="176.0" y1="46.0" x2="176.0" y2="62.0" stroke="var(--ar-papel)" stroke-width="3"/><line x1="190.7" y1="47.0" x2="189.6" y2="55.0" stroke="var(--ar-papel)" stroke-width="1.5"/><line x1="205.1" y1="50.2" x2="202.9" y2="57.8" stroke="var(--ar-papel)" stroke-width="1.5"/><line x1="218.9" y1="55.3" x2="215.6" y2="62.6" stroke="var(--ar-papel)" stroke-width="1.5"/><line x1="231.9" y1="62.3" x2="223.3" y2="75.8" stroke="var(--ar-papel)" stroke-width="3"/><line x1="243.7" y1="71.1" x2="238.5" y2="77.1" stroke="var(--ar-papel)" stroke-width="1.5"/><line x1="254.2" y1="81.4" x2="248.2" y2="86.7" stroke="var(--ar-papel)" stroke-width="1.5"/><line x1="263.1" y1="93.2" x2="256.4" y2="97.5" stroke="var(--ar-papel)" stroke-width="1.5"/><line x1="270.3" y1="106.0" x2="255.8" y2="112.8" stroke="var(--ar-papel)" stroke-width="3"/><text x="112.6" y="126.4" text-anchor="middle" class="sm-tanque__e">E</text><text x="239.4" y="126.4" text-anchor="middle" class="sm-tanque__f">F</text><text x="176.0" y="88.0" text-anchor="middle" class="sm-tanque__m">½</text><line x1="176" y1="150" x2="88.0" y2="131.3" stroke="var(--ar-acento)" stroke-width="3.5" stroke-linecap="round"/><circle cx="176" cy="150" r="9" fill="var(--ar-papel)"/><circle cx="176" cy="150" r="3.5" fill="var(--ar-tinta)"/><g class="sm-tanque__lampara" transform="translate(276 26)"><circle r="17" fill="var(--ar-acento)"/><rect x="-7" y="-9" width="9" height="17" rx="1.5" fill="var(--ar-tinta)"/><rect x="-5" y="-6.5" width="5" height="4" fill="var(--ar-acento)"/><path d="M2 -6 h3 l3 3 v9 a2 2 0 0 1 -4 0 v-5 h-2" fill="none" stroke="var(--ar-tinta)" stroke-width="1.8"/></g></svg><span class="sm-rollo__num">08</span></span><span class="sm-rollo__pie"><b>Episodio 08</b><i>Sin combustible</i></span></div></li>
    </ol>
  </section></div>

  <!-- 4 · temporada 2 · escaleta -->
  <div class="ap-wrap"><section class="lb-sec lb-col" aria-labelledby="sm-t2-t">
    <div class="ar-tit"><h2 id="sm-t2-t">¿Por qué esta segunda temporada importa?</h2><span>temporada 2</span></div>
    <div class="lb-texto">
      <p>La primera temporada se transmitió en un canal de cable. Habíamos planeado ocho episodios y llegamos a siete. No porque se nos acabaran las historias, sino porque éramos dos personas sosteniendo todo. Construimos un producto de calidad entre dos, y el único apoyo que teníamos —un espacio en un canal de televisión— en algún punto del proyecto quedó claro que no sería suficiente para sostener algo serial como MAP. El combustible se nos fue agotando en el camino.</p>
      <p>Y aun así, funcionó. La gente que vio MAP lo amó. Eso nos dejó una certeza y una espina: la certeza de que el contenido importaba, y la espina de no haber podido cerrarlo como merecía.</p>
      <p>La segunda temporada es volver a hacerlo bien. Ocho episodios que esta vez sí forman una sola historia, un arco que va desde la herida de no ser visto hasta la decisión de seguir creando aunque nadie esté mirando.</p>
      <p>No volvemos porque sea fácil. Volvemos porque las historias siguen ahí, sin contarse, y porque ya demostramos que cuando se cuentan, conectan. Tenemos claro qué nos faltó en la primera temporada, y sabemos cómo potenciar MAP ahora. Por eso arrancamos esta segunda temporada: no para repetir lo que hicimos, sino para llevarlo donde siempre debió estar.</p>
    </div>
  </section></div>

  <div class="ap-wrap"><section class="lb-sec ap-ancho" aria-labelledby="sm-esc-t">
    <div class="ar-tit"><h2 id="sm-esc-t">Temporada 2 · La escaleta</h2><span>8 episodios · 4 actos</span></div>
    <p class="sm-arco">Ocho episodios que trazan un solo arco: de la necesidad de ser visto, a la decisión de seguir aun sin testigos. Cada uno tensiona el tema central desde un ángulo distinto. El artista maldito, olvidado, ninguneado… pero irreductible.</p>
    <div class="sm-escaleta">
      <div class="sm-acto"><div class="sm-acto__cab"><h3>La herida</h3><span>Acto I</span></div><ol><li><span>01</span><b>El visionario ignorado</b><i>¿Qué mueve a alguien a crear sin audiencia?</i></li><li><span>02</span><b>El testimonio del abandono</b><i>¿Por qué este país niega a sus mejores hijos?</i></li></ol></div><div class="sm-acto"><div class="sm-acto__cab"><h3>El tiempo</h3><span>Acto II</span></div><ol><li><span>03</span><b>El cuerpo que persiste</b><i>¿Qué pasa cuando el arte también es físico?</i></li><li><span>04</span><b>El eco de lo que fue</b><i>¿Qué significa envejecer siendo invisible?</i></li></ol></div><div class="sm-acto"><div class="sm-acto__cab"><h3>La rabia</h3><span>Acto III</span></div><ol><li><span>05</span><b>El grito sin micrófono</b><i>¿Qué es un artista sin escenario?</i></li><li><span>06</span><b>La furia como testamento</b><i>¿Puede la rabia sostener una carrera?</i></li></ol></div><div class="sm-acto"><div class="sm-acto__cab"><h3>El fuego</h3><span>Acto IV</span></div><ol><li><span>07</span><b>El culto sin religión</b><i>¿Quién sostiene a los genios cuando caen?</i></li><li><span>08</span><b>El fuego que no se apaga</b><i>¿Y si no hace falta que te reconozcan nunca?</i></li></ol></div>
    </div>
  </section></div>

  <!-- 5 · manifiesto -->
  <div class="ap-wrap"><section class="lb-sec lb-col" aria-labelledby="sm-pr-t">
    <div class="ar-tit"><h2 id="sm-pr-t">8 principios para su funcionamiento</h2><span>mapradiocr</span></div>
    <ol class="sm-principios">
      <li><span>01</span><h3>Un terreno de resistencia cultural</h3><p>El skateboarding, la música independiente y el arte no pertenecen a los circuitos convencionales; son movimientos que surgen de la resistencia a lo establecido. MAP es un reflejo de esa misma resistencia. No buscamos adaptarnos al sistema, sino cuestionarlo. Retratamos estas culturas no para integrarlas en la corriente dominante, sino para que sigan siendo espacios de subversión y libertad.</p></li><li><span>02</span><h3>La autenticidad por encima de todo</h3><p>La esencia de este proyecto reside en su autenticidad. Cobrar a los artistas, músicos o patinadores por aparecer en un espacio no solo traiciona el principio de la cultura que se quiere mostrar, sino que convierte al espacio en un instrumento de exclusión. La producción de este contenido debe ser financiada por quienes comprenden y respetan su valor intrínseco. Nuestro compromiso es con la verdad de estas culturas, y esa verdad no puede ser comprada ni vendida.</p></li><li><span>03</span><h3>No apropiar, solo retratar</h3><p>Nuestro rol no es apropiarnos de estas expresiones, sino documentarlas en su forma más pura. No somos dueños de esta cultura; somos testigos. Retratamos la música, el skate y el arte urbano para que hablen por sí mismos, no para imponerles una narrativa externa. Al evitar la tentación de transformarlos en un producto, mantenemos intacta la esencia de lo que estos movimientos representan.</p></li><li><span>04</span><h3>Contra la espectacularización</h3><p>MAP no debe ser una plataforma de entretenimiento vacío, sino un medio para que la gente comprenda el verdadero significado detrás del skateboarding, la música y el arte como parte de una CULTURA. Estos movimientos no son simples imágenes para un retrato: vienen cargados de ideas, historias y formas de ver el mundo. No buscamos "lo bonito" para la foto, sino lo que tiene peso; y eso exige investigar, observar y descubrir lo que realmente vale la pena contar.</p></li><li><span>05</span><h3>Un proyecto colectivo</h3><p>MAP no es un esfuerzo aislado, sino una construcción colectiva que se alimenta de muchas manos y miradas. Apoyar este espacio no siempre significa aportar dinero; también es difundirlo, compartirlo, hablar de él, traer a otros a conocerlo. Cada vez que alguien recomienda un podcast, muestra un video o comparte una publicación, está ayudando a que esta cultura siga viva y visible. Pasar el proyecto de mano en mano es un acto de resistencia contra el olvido y la indiferencia.</p></li><li><span>06</span><h3>La independencia no se negocia</h3><p>MAP no puede depender de las conveniencias, intereses o condiciones de quienes estén dispuestos a apoyar económicamente. La línea editorial y el contenido no se negocian para complacer a patrocinadores, instituciones o tendencias de moda. La verdadera independencia es la que permite retratar la cultura tal como es, sin ajustar el mensaje para no incomodar.</p></li><li><span>07</span><h3>Un espacio para desafiar estructuras</h3><p>La relevancia de una obra, un artista o un movimiento no debe depender de cúpulas culturales o redes de favores. MAP busca mostrar lo que tiene valor real, aunque no provenga de entornos privilegiados ni goce de visibilidad heredada. Aquí la presencia se gana por mérito y autenticidad, no por conexiones.</p></li><li><span>08</span><h3>Cultura que no se vende</h3><p>El verdadero éxito de MAP está en mantenerse fiel a sus principios y en respetar los espacios culturales que retrata. Si el objetivo se convierte en buscar likes, seguidores o validación fácil, se cae en lo que llamamos pornografía de la cultura: mostrar por mostrar, vaciando de contenido lo que alguna vez tuvo valor. Ese es el camino más rápido al fracaso.</p></li>
    </ol>
  </section></div>

  <!-- 6 · cierre -->
  <div class="ap-wrap"><section class="lb-cierre ap-ancho">
    <p class="sm-frase">MAP no entrevista famosos. MAP encuentra personas que tienen historias increíbles que contar, <span>aunque nadie los haya escuchado todavía.</span></p>
    <span class="lb-cierre__src">Misión MAP · 2016 · mapradiocr.com</span>
    <div class="sm-cierre__acciones">
      <span class="sm-cierre__lab">La temporada 2 arranca con apoyo</span>
      <a class="ap-boton" href="<?php echo esc_url( home_url( '/' ) ); ?>contacto/#astillero">Patrocinar la temporada 2 ▸</a>
      <a class="ap-boton ap-boton--linea" href="https://ko-fi.com/mapradiocr">Un café en Ko-fi ↗</a>
    </div>
  </section></div>
</main>
<?php map_ar_cerrar();

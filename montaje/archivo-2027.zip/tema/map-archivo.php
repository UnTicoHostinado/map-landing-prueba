<?php
/**
 * MAP 2027 · Papelería del archivo, compartida por las plantillas del tema hijo
 * (single.php, category.php y las que vengan). No es una plantilla: la cargan con require_once.
 * Estilos y scripts en /wp-content/uploads/2026/archivo/.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Fecha en que se instala el sitio nuevo: lo publicado antes lleva el sello SEÑAL PREVIA.
if ( ! defined( 'MAP_INSTRUMENTO' ) ) {
	define( 'MAP_INSTRUMENTO', '2026-11-01' );
}
if ( ! defined( 'MAP_AR_VER' ) ) {
	define( 'MAP_AR_VER', '20261105d' );
}

/* Las plantillas del archivo traen su propia papelería: fuera los estilos del tema y el CSS adicional del 2026. */
if ( ! function_exists( 'map_ar_preparar' ) ) {
	function map_ar_preparar() {
		$base = content_url( '/uploads/2026/archivo/' );
		add_action( 'wp_enqueue_scripts', function () use ( $base ) {
			wp_enqueue_style( 'map-fuentes', 'https://fonts.googleapis.com/css2?family=B612+Mono:wght@400;700&family=Bebas+Neue&family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans:ital,wght@0,300;0,400;0,500;0,600;1,300&display=swap', array(), null );
			wp_enqueue_style( 'map-archivo', $base . 'archivo.css', array(), MAP_AR_VER );
			wp_enqueue_script( 'map-archivo', $base . 'archivo.js', array(), MAP_AR_VER, array( 'in_footer' => true, 'strategy' => 'defer' ) );
			// wpDiscuz carga su hoja «minimal» desde la cabecera del tema; como aquí no se usa esa cabecera, se pide a mano.
			if ( is_singular() && file_exists( WP_PLUGIN_DIR . '/wpdiscuz/themes/default/style-minimal.css' ) ) {
				wp_enqueue_style( 'wpdiscuz-frontend-minimal-css', plugins_url( 'wpdiscuz/themes/default/style-minimal.css' ), array(), defined( 'WPDISCUZ_VERSION' ) ? WPDISCUZ_VERSION : null );
			}
		}, 20 );
		add_action( 'wp_print_styles', function () {
			$ws = wp_styles();
			foreach ( (array) $ws->queue as $h ) {
				$src = isset( $ws->registered[ $h ] ) ? (string) $ws->registered[ $h ]->src : '';
				if ( 0 === strpos( $h, 'wpdiscuz' ) ) {
					continue;
				}
				if ( 0 === strpos( $h, 'neve' ) || 'chld_thm_cfg_child' === $h || false !== strpos( $src, '/wp-content/themes/' ) ) {
					wp_dequeue_style( $h );
				}
			}
			wp_deregister_style( 'neve-style' );
		}, 1 );
		remove_action( 'wp_head', 'wp_custom_css_cb', 101 );
	}
}

/* Apertura: documento, barra del archivo y buscador. $seccion marca el menú. */
if ( ! function_exists( 'map_ar_abrir' ) ) {
	function map_ar_abrir( $seccion = 'Textos', $saltar = 'Saltar al contenido', $barra = true ) {
		$menu = array(
			'Serie MAP'         => home_url( '/serie-map/' ),
			'Textos'            => home_url( '/textos/' ),
			'Podcast'           => home_url( '/podcast/' ),
			'Sobre el director' => home_url( '/sobre-el-director/' ),
			'Contacto'          => home_url( '/contacto/' ),
			'Frecuencia'        => home_url( '/suscribirse/' ),
		);
		?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class( 'map-archivo' ); ?>>
<?php wp_body_open(); ?>
<?php if ( ! $barra ) { return; } ?>
<a class="ar-saltar" href="#contenido"><?php echo esc_html( $saltar ); ?></a>

<header class="ar-barra">
	<div class="ar-barra__in">
		<a class="ar-sello" href="<?php echo esc_url( home_url( '/?desde=textos' ) ); ?>" title="Volver a la carta">MAP</a>
		<nav class="ar-menu" id="ar-menu" aria-label="Secciones"><?php
		foreach ( $menu as $txt => $url ) {
			echo '<a href="' . esc_url( $url ) . '"' . ( 'Frecuencia' === $txt ? ' class="ar-menu__fq"' : '' ) . ( $seccion === $txt ? ' aria-current="true"' : '' ) . '>' . esc_html( 'Frecuencia' === $txt ? 'Frecuencia MAP' : $txt ) . '</a>';
		}
		?></nav>
		<button type="button" class="ar-btn ar-btn--menu" id="ar-menu-btn" aria-expanded="false" aria-controls="ar-menu">Menú</button>
		<button type="button" class="ar-btn" id="ar-buscar-btn">Buscar ⌕</button>
	</div>
</header>

<div class="ar-buscador" id="ar-buscador" hidden>
	<form class="ar-buscador__in" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<label for="ar-q">Buscar en el archivo</label>
		<input id="ar-q" name="s" type="search" placeholder="Bolaño, patinetas, cantina…" autocomplete="off">
		<p>Busca en títulos, textos y etiquetas de todas las entradas.</p>
		<button type="button" class="ar-btn ar-btn--claro" id="ar-buscar-cerrar">Cerrar ✕</button>
	</form>
</div>
<?php
	}
}

/* Cierre: pie del sitio y wp_footer. */
if ( ! function_exists( 'map_ar_cerrar' ) ) {
	function map_ar_cerrar( $pie = true ) {
		if ( $pie ) :
		?>
<footer class="ar-pie">
	<div class="ar-pie__in">
		<a class="ar-pie__marca" href="<?php echo esc_url( home_url( '/' ) ); ?>">MAP — 2016 ⚡</a>
		<span class="ar-pie__cred">Ingeniería web — Dr. Arkady Volkov Lazenko · Instituto Cuántico Costarricense para la Investigación Interdimensional</span>
		<a class="ar-pie__fq" href="<?php echo esc_url( home_url( '/suscribirse/' ) ); ?>">Frecuencia MAP · el boletín de los lunes →</a>
		<nav aria-label="Legal"><a href="<?php echo esc_url( home_url( '/politica-de-privacidad/' ) ); ?>">Privacidad</a><span aria-hidden="true">·</span><a href="<?php echo esc_url( home_url( '/terminos-y-condiciones/' ) ); ?>">Términos</a></nav>
	</div>
</footer>
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>
<?php
	}
}

/* Migas de pan de Rank Math con la clase del archivo. */
if ( ! function_exists( 'map_ar_migas' ) ) {
	function map_ar_migas() {
		if ( ! function_exists( 'rank_math_the_breadcrumbs' ) ) {
			return '';
		}
		ob_start();
		rank_math_the_breadcrumbs();
		return str_replace( 'class="rank-math-breadcrumb"', 'class="rank-math-breadcrumb ar-migas" aria-label="Migas de pan"', ob_get_clean() );
	}
}

if ( ! function_exists( 'map_ar_minutos' ) ) {
	function map_ar_minutos( $html ) {
		$txt = wp_strip_all_tags( preg_replace( '#<(script|style)[^>]*>.*?</\1>#is', ' ', $html ) );
		$n   = count( preg_split( '/\s+/u', trim( $txt ), -1, PREG_SPLIT_NO_EMPTY ) );
		return max( 1, (int) round( $n / 220 ) );
	}
}

/* Categoría principal de una entrada (la primaria de Rank Math, si la hay). */
if ( ! function_exists( 'map_ar_categoria' ) ) {
	function map_ar_categoria( $post_id ) {
		$c = get_the_category( $post_id );
		if ( ! $c ) {
			return '';
		}
		$pri = (int) get_post_meta( $post_id, 'rank_math_primary_category', true );
		foreach ( $c as $x ) {
			if ( $x->term_id === $pri ) {
				return $x->name;
			}
		}
		return $c[0]->name;
	}
}

/* Categorías que tienen página propia: en las listas llevan a esa página (borde punteado). */
if ( ! function_exists( 'map_ar_pagina_propia' ) ) {
	function map_ar_pagina_propia( $term_id ) {
		$propias = array(
			1080 => '/cronicas-del-refugio/',
			35   => '/podcast/',
		);
		return isset( $propias[ $term_id ] ) ? home_url( $propias[ $term_id ] ) : '';
	}
}

/* Mes corto en español con mayúscula: «Oct». */
if ( ! function_exists( 'map_ar_mes' ) ) {
	function map_ar_mes( $post ) {
		$m = array( 'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic' );
		return $m[ (int) get_the_date( 'n', $post ) - 1 ];
	}
}

/* Series con anterior / siguiente: categoría => nombre, unidad y total previsto (0 = las publicadas). */
if ( ! function_exists( 'map_ar_serie' ) ) {
	function map_ar_serie( $post_id ) {
		$series = array(
			1097 => array( 'Los Estudios de Campo', 'Bitácora', 10 ),
			1080 => array( 'Crónicas del Refugio', 'Crónica', 0 ),
			1096 => array( 'La Cantina Ideal', 'Estudio', 0 ),
		);
		foreach ( $series as $cat => $s ) {
			if ( ! has_category( $cat, $post_id ) ) {
				continue;
			}
			$ids = get_posts( array(
				'cat'              => $cat,
				'orderby'          => 'date',
				'order'            => 'ASC',
				'posts_per_page'   => 60,
				'fields'           => 'ids',
				'suppress_filters' => false,
			) );
			$i = array_search( $post_id, $ids, true );
			if ( false === $i ) {
				return '';
			}
			$total = max( (int) $s[2], count( $ids ) );
			$num   = function ( $n ) {
				return str_pad( (string) $n, 2, '0', STR_PAD_LEFT );
			};
			// Nombre de cada pieza: el de la bitácora (ACF) si lo tiene; si no, el título de la entrada.
			$nom = function ( $id ) {
				$n = function_exists( 'get_field' ) ? (string) get_field( 'bitacora_nombre', $id ) : '';
				return '' !== trim( $n ) ? $n : get_the_title( $id );
			};
			ob_start(); ?>
<div class="hr-wrap"><nav class="ar-serie hr-col" aria-label="Serie <?php echo esc_attr( $s[0] ); ?>">
	<div class="ar-tit"><h2><?php echo esc_html( $s[0] ); ?></h2><span><?php echo esc_html( $s[1] . ' ' . $num( $i + 1 ) . ' de ' . $num( $total ) ); ?></span></div>
	<ol class="ar-serie__tira"><?php
			for ( $k = 0; $k < $total; $k++ ) {
				if ( $k === $i ) {
					echo '<li><span class="ar-serie__n ar-serie__n--aqui" aria-current="page" title="' . esc_attr( $s[1] . ' ' . $num( $k + 1 ) . ': ' . $nom( $ids[ $k ] ) ) . '">' . $num( $k + 1 ) . '</span></li>';
				} elseif ( isset( $ids[ $k ] ) ) {
					echo '<li><a class="ar-serie__n" href="' . esc_url( get_permalink( $ids[ $k ] ) ) . '" title="' . esc_attr( $s[1] . ' ' . $num( $k + 1 ) . ': ' . $nom( $ids[ $k ] ) ) . '">' . $num( $k + 1 ) . '</a></li>';
				} else {
					echo '<li><span class="ar-serie__n ar-serie__n--prep" title="En preparación">' . $num( $k + 1 ) . '</span></li>';
				}
			}
			?></ol>
	<div class="ar-serie__nav"><?php
			if ( $i > 0 ) {
				$a = $ids[ $i - 1 ];
				echo '<a class="ar-serie__paso ar-serie__paso--ant" href="' . esc_url( get_permalink( $a ) ) . '" rel="prev"><span>← Anterior · ' . esc_html( $s[1] . ' ' . $num( $i ) ) . '</span><b>' . esc_html( $nom( $a ) ) . '</b></a>';
			} else {
				echo '<span class="ar-serie__paso ar-serie__paso--vacio"><span>← Anterior</span><b>Es la primera</b></span>';
			}
			if ( isset( $ids[ $i + 1 ] ) ) {
				$b = $ids[ $i + 1 ];
				echo '<a class="ar-serie__paso ar-serie__paso--sig" href="' . esc_url( get_permalink( $b ) ) . '" rel="next"><span>Siguiente · ' . esc_html( $s[1] . ' ' . $num( $i + 2 ) ) . ' →</span><b>' . esc_html( $nom( $b ) ) . '</b></a>';
			} else {
				echo '<span class="ar-serie__paso ar-serie__paso--sig ar-serie__paso--vacio"><span>Siguiente →</span><b>' . ( $total > count( $ids ) ? 'En preparación' : 'Es la última' ) . '</b></span>';
			}
			?></div>
</nav></div>
<?php
			return ob_get_clean();
		}
		return '';
	}
}

/* Lo más leído: el contador del sitio (/map/v1/populares), guardado una hora. */
if ( ! function_exists( 'map_ar_populares' ) ) {
	function map_ar_populares() {
		$lista = get_transient( 'map_ar_populares' );
		if ( false === $lista ) {
			$lista = array();
			$r     = rest_do_request( new WP_REST_Request( 'GET', '/map/v1/populares' ) );
			if ( ! $r->is_error() ) {
				foreach ( (array) $r->get_data() as $p ) {
					if ( ! empty( $p['id'] ) ) {
						$lista[] = (int) $p['id'];
					}
				}
			}
			set_transient( 'map_ar_populares', $lista, HOUR_IN_SECONDS );
		}
		return $lista;
	}
}

/* Búsqueda: patrón que no distingue tildes ni mayúsculas, para resaltar y recortar. */
if ( ! function_exists( 'map_ar_patron' ) ) {
	function map_ar_patron( $termino ) {
		$grupos = array( 'a' => 'aáàäâ', 'e' => 'eéèëê', 'i' => 'iíìïî', 'o' => 'oóòöô', 'u' => 'uúùüû', 'n' => 'nñ' );
		$base   = mb_strtolower( remove_accents( $termino ) );
		$out    = '';
		foreach ( preg_split( '//u', $base, -1, PREG_SPLIT_NO_EMPTY ) as $c ) {
			$out .= isset( $grupos[ $c ] ) ? '[' . $grupos[ $c ] . mb_strtoupper( $grupos[ $c ] ) . ']' : preg_quote( $c, '/' );
		}
		return '/(' . $out . ')/iu';
	}
}
if ( ! function_exists( 'map_ar_marcar' ) ) {
	function map_ar_marcar( $txt, $patron ) {
		$t = esc_html( $txt );
		return $patron ? preg_replace( $patron, '<mark>$1</mark>', $t ) : $t;
	}
}
if ( ! function_exists( 'map_ar_texto' ) ) {
	function map_ar_texto( $post_id ) {
		$t = get_post_field( 'post_content', $post_id );
		$t = preg_replace( '#<(script|style)[^>]*>.*?</\\1>#is', ' ', $t );
		$t = preg_replace( '/<[^>]+>/', ' ', strip_shortcodes( $t ) );
		$t = wp_strip_all_tags( $t );
		return trim( preg_replace( '/\\s+/u', ' ', html_entity_decode( $t, ENT_QUOTES, 'UTF-8' ) ) );
	}
}
/* Recorte de unas 220 letras alrededor de la palabra buscada. */
if ( ! function_exists( 'map_ar_recorte' ) ) {
	function map_ar_recorte( $txt, $patron ) {
		$i = -1;
		if ( $patron && preg_match( $patron, $txt, $m, PREG_OFFSET_CAPTURE ) ) {
			$i = mb_strlen( substr( $txt, 0, $m[0][1] ) );
		}
		if ( $i < 110 ) {
			return mb_strlen( $txt ) > 220 ? preg_replace( '/\\s+\\S*$/u', '', mb_substr( $txt, 0, 220 ) ) . '…' : $txt;
		}
		$ini = max( 0, $i - 80 );
		$sub = mb_substr( $txt, $ini, 240 );
		$sub = preg_replace( '/^\\S*\\s/u', '', $sub );
		$sub = preg_replace( '/\\s+\\S*$/u', '', $sub );
		return '…' . $sub . '…';
	}
}

/* Textos editables de las páginas especiales (campos ACF «MAP 2027 · …», registrados en el snippet WPCode de campos).
   Si el campo está vacío, o ACF no está, sale el texto de siempre. */
if ( ! function_exists( 'map_ar_campo' ) ) {
	function map_ar_campo( $nombre, $defecto = '', $post_id = false ) {
		if ( ! function_exists( 'get_field' ) ) {
			return $defecto;
		}
		$v = get_field( $nombre, $post_id );
		if ( is_string( $v ) ) {
			$v = trim( $v );
		}
		return ( null === $v || false === $v || '' === $v || array() === $v ) ? $defecto : $v;
	}
}
/* Texto corto o párrafo sin formato: se escapa. */
if ( ! function_exists( 'map_ar_texto_campo' ) ) {
	function map_ar_texto_campo( $nombre, $defecto = '' ) {
		return esc_html( map_ar_campo( $nombre, $defecto ) );
	}
}
/* Texto con formato (editor visual): enlaces, cursivas y párrafos. */
if ( ! function_exists( 'map_ar_html_campo' ) ) {
	function map_ar_html_campo( $nombre, $defecto = '' ) {
		return wp_kses_post( map_ar_campo( $nombre, $defecto ) );
	}
}

/* Frecuencia MAP: el recuadro para suscribirse (formulario 1 de MailPoet, lista «Frecuencia MAP»).
   $variante: 'pagina' (página Suscribirse), 'entrada' (al final de cada entrada), 'gracias'. */
if ( ! function_exists( 'map_ar_frecuencia' ) ) {
	function map_ar_frecuencia( $variante = 'entrada', $titulo = 'Sintonizá la Frecuencia MAP', $texto = 'Cada lunes te llega un correo corto: un texto mío, un clip, una película que vale la pena y algo del archivo MAP.' ) {
		if ( ! shortcode_exists( 'mailpoet_form' ) ) {
			return;
		}
		$id = 'fq-' . $variante;
		?>
<section class="fq fq--<?php echo esc_attr( $variante ); ?>" aria-labelledby="<?php echo esc_attr( $id ); ?>">
	<p class="fq__sello">Frecuencia MAP · todos los lunes</p>
	<h2 class="fq__tit" id="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $titulo ); ?></h2>
	<?php if ( $texto ) : ?><p class="fq__tx"><?php echo esc_html( $texto ); ?></p><?php endif; ?>
	<div class="fq__form"><?php
		echo str_replace(
			array( 'This field is required.', 'This value should be a valid email.' ),
			array( 'Escribí tu correo para sintonizar.', 'Escribí un correo válido, por ejemplo nombre@correo.com.' ),
			do_shortcode( '[mailpoet_form id="1"]' )
		); ?></div>
	<p class="fq__nota">Gratis · un correo por semana · te das de baja con un toque</p>
</section>
		<?php
	}
}

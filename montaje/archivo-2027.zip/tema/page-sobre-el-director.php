<?php
/**
 * MAP 2027 · página «sobre-el-director»
 * Generada desde la maqueta aprobada (gen_pagina.py director). La papelería compartida está en map-archivo.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once get_stylesheet_directory() . '/map-archivo.php';
map_ar_preparar();
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_script( 'map-sobre-el-director', content_url( '/uploads/2026/archivo/sobre-el-director.js' ), array(), MAP_AR_VER, array( 'in_footer' => true, 'strategy' => 'defer' ) );
}, 21 );
map_ar_abrir( 'Sobre el director', 'Saltar a la biografía' );
?>
<main class="ap sd" id="contenido">

  <!-- 1 · cabecera -->
  <div class="ap-wrap"><header class="sd-cab ap-ancho">
    <figure class="sd-foto">
      <img src="<?php echo esc_url( home_url( '/' ) ); ?>wp-content/uploads/2026/07/Valdo_limpiando_la_camara.webp" width="666" height="998" alt="Valdo Jiménez V. limpia el lente de una cámara de video" onerror="this.parentNode.classList.add('sin-foto')">
      <figcaption>Foto: Olman Torres · @stdbyproject</figcaption>
    </figure>
    <div class="sd-cab__txt">
      <p class="ap-kicker">Sobre el director · MAP Radio Radio Pachuko</p>
      <h1>Valdo Jiménez V.</h1>
      <p class="sd-epigrafe">"Si los grandes medios de comunicación masiva de este país se dedicaran realmente a generar contenido, tanto mis exquisitos textos como mis piezas visuales estarían con regularidad adornando sus pantallas. Sin embargo, el negocio de los medios en Costa Rica es otro, no el de crear, ante lo cual no queda más que la trinchera desde donde construyo."</p>
    </div>
  </header></div>

  <!-- 2 · biografía -->
  <div class="ap-wrap"><section class="lb-sec lb-col" aria-labelledby="sd-bio-t">
    <div class="ar-tit"><h2 id="sd-bio-t">Biografía</h2><span>desde 2016</span></div>
    <div class="lb-texto">
      <p>Soy Valdo Jiménez V., director de MAP RADIO RADIO PACHUKO. Desde el 2016 he sostenido este proyecto con el mismo espíritu con que se sostiene una barricada: convicción, terquedad y cariño por la música, el arte y la palabra libre. Acompañado siempre de la generosidad de entrañables amigos.</p>
      <p>Crecí entre cuentos fantásticos y cámaras prestadas, hasta hacer de la narrativa —oral, escrita y visual— mi oficio y mi refugio. He trabajado con bandas independientes, filmado documentales, creado videoclips y acompañado a artistas y colectivos que rara vez tienen espacio en la prensa tradicional.</p>
      <p>El documental <a href="https://youtu.be/_g5LaE4DjVA">RUIDO</a>, del que soy director, se proyectó en el Festival Internacional de Cine de Costa Rica y también en el centro penitenciario La Reforma, frente a 400 internos, donde encantó contra todo pronóstico. Su origen, sin embargo, es más antiguo de lo que parece: cuando Nasional Skateboards nació en 2007, una de las ideas fundacionales era crear un documental sobre la escena skate costarricense. Casi diez años después, sin haberlo planeado así, RUIDO vería la luz. Anteriormente tuve la oportunidad de grabar un corto documental en México junto al actor <a href="https://open.spotify.com/episode/5yg67wrtr0rB70qXH3MiPk">Eliseo Martínez</a>, uno de los protagonistas de la película <i>Te Prometo Anarquía</i>.</p>
      <p>MAP RADIO nació de esa necesidad: dar voz a quienes crean desde el margen, con la autenticidad que no se negocia en salas de redacción ni se mide por pautas publicitarias. Aquí no se simula neutralidad: aquí se escribe, se graba y se comparte con la convicción de que la cultura real no cabe en las vitrinas del poder.</p>
    </div>
  </section></div>

  <!-- 3 · proyectos -->
  <div class="ap-wrap"><section class="lb-sec ap-ancho" aria-labelledby="sd-pr-t">
    <div class="ar-tit"><h2 id="sd-pr-t">Proyectos</h2><span>cuatro frentes</span></div>
    <ul class="sd-proyectos">
      <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>podcast/"><span>Podcast</span><b>MAP Radio Radio Pachuko</b><i>Desde 2016 · 200+ episodios</i></a></li>
      <li><a href="https://youtu.be/_g5LaE4DjVA"><span>Documental</span><b>RUIDO</b><i>Tesis 2016 · Festival Internacional de Cine de Costa Rica 2018</i></a></li>
      <li><a href="https://www.nasionalsb.com/"><span>Patinetas</span><b>Nasional Skateboards</b><i>Fundada en 2007 · nasionalsb.com</i></a></li>
      <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>cronicas/"><span>Literatura</span><b>Crónicas del Refugio</b><i>y otras geografías de la memoria</i></a></li>
    </ul>
  </section></div>

  <!-- 4 · sin mordaza -->
  <div class="ap-wrap"><section class="sd-mordaza ap-ancho" aria-labelledby="sd-mo-t">
    <div><span class="sd-mordaza__lab">Declaración editorial</span><h2 id="sd-mo-t">Sin mordaza.</h2></div>
    <p>MAP RADIO RADIO PACHUKO no pretende ser neutral, porque la neutralidad suele ser la excusa de los tibios. Aquí hablamos sin mordaza: de lo que arde en las calles, de la música que no suena en la radio comercial, de las voces que no caben en el horario estelar. Nuestra editorial nace del inconformismo y de la convicción de que el arte, la palabra y el ruido son armas de resistencia. No nos interesa agradar; nos interesa incomodar, cuestionar y abrir espacio donde otros prefieren cerrar la puerta.</p>
  </section></div>

  <!-- 5 · archivo audiovisual · moviola -->
  <div class="ap-wrap"><section class="lb-sec ap-ancho" id="archivo" aria-labelledby="sd-av-t">
    <div class="ar-tit"><h2 id="sd-av-t">Archivo audiovisual</h2><span>11 piezas · la moviola</span></div>
    <p class="sd-archivo__intro">Este espacio reúne fragmentos y obras completas que han marcado mi recorrido en la dirección y creación de contenido: clips de skate, cortos documentales, videoclips musicales y proyectos que han viajado por publicaciones locales e internacionales. Más que un archivo, es una forma de compartir el proceso, la energía y las circunstancias detrás de cada pieza.</p>
    <div class="sd-moviola" id="sd-moviola">
      <div class="sd-moviola__izq">
        <div class="sd-pantalla" id="sd-pantalla" aria-live="polite">
          <div class="sd-reposo"><span>Archivo audiovisual · pieza 01</span><b>Capitán Rooster</b><button type="button" class="sd-proyectar" data-proyectar>Proyectar</button></div>
        </div>
        <div class="sd-extra" data-de="av-capitan-rooster"><a href="https://www.vice.com/es/article/escuchen-a-capitan-rooster-la-banda-mas-marginal-de-costa-rica/">↗ Noisey: La banda más marginal de Costa Rica</a><p class="sd-anecdota"><b>Anécdota —</b> En 2018 se robaron el canal de YouTube de Nasional Skateboards (abierto en 2006). Este video terminó en un canal ruso de "criptomonedas". Igual acá queda, en casa.</p></div>
      </div>
      <div class="sd-fichas">
        <article class="sd-ficha" id="av-capitan-rooster" data-n="01" data-corto="Capitán Rooster" data-tipo="sp" data-id="2PJC801GYe35z66oUobqPT"><span class="sd-ficha__num">01</span><h3>Capitán Rooster — Barrio México</h3><span class="sd-ficha__rot">Corto documental · publicado en Noisey / VICE</span><blockquote>"Hace 11 años, con una cámara, un micrófono y mucha fiebre por hacer, grabé este capítulo sobre Capitán Rooster. Lo publicó Noisey (VICE) así, tal cual."</blockquote><p>Un paseo por Barrio México, un Distrito en San José famoso por sus esquinas, sus iglesias, sus cantinas y sus talleres. Es precisamente en un taller donde se puede ver un ensayo de Capitán Rooster y luego una charla sobre el barrio y la vida de una banda underground entre sus calles.</p></article>
        <article class="sd-ficha" id="av-malas-palabras" data-n="02" data-corto="Malas Palabras" data-tipo="yt" data-id="f85UiXEweyk" hidden><span class="sd-ficha__num">02</span><h3>Malas Palabras — Do It Yourself</h3><span class="sd-ficha__rot">Corto documental · Blank TV</span><blockquote>"Hace 11 años filmé este corto documental con la alineación original de Malas Palabras. En ese momento había algo que valía la pena capturar: su energía en estudio y el espíritu DIY que los definía."</blockquote><p>Este trabajo refuerza lo que más disfruto del audiovisual: la narrativa documental. No necesito fingir nada, solo estar ahí y dejar que las historias se cuenten por sí solas. Con Malas Palabras, en una finca en Belén de Heredia, esas 6 horas de rodaje entre cables y anécdotas quedó registrado un momento irrepetible.</p></article>
        <article class="sd-ficha" id="av-agent-orange" data-n="03" data-corto="Agent Orange" data-tipo="sp" data-id="2M3QyvydFx2ViMPzkJgGpS" hidden><span class="sd-ficha__num">03</span><h3>Agent Orange en Costa Rica</h3><span class="sd-ficha__rot">Extracto de MAP: Música, Arte &amp; Patineta — episodio 4</span><blockquote>"Este clip es un extracto del cuarto episodio de MAP, grabado hace 6 años con la asistencia de Randy Parker. Para mí marca un punto clave en la evolución de mi trabajo audiovisual."</blockquote><p>Dos personas enfocadas, con roles claros y respeto por el oficio, pueden lograr piezas que superan en calidad a muchas producciones que se ven en la televisión costarricense. Este clip es una prueba de cómo un equipo reducido y comprometido puede capturar la intensidad de un evento sin artificios.</p></article>
        <article class="sd-ficha" id="av-tenochtitlan" data-n="04" data-corto="Tenochtitlan" data-tipo="sp" data-id="5yg67wrtr0rB70qXH3MiPk" hidden><span class="sd-ficha__num">04</span><h3>Tenochtitlan según Pelukaz</h3><span class="sd-ficha__rot">Música, Arte &amp; Patinetas · México</span><blockquote>"Este clip recoge parte de un viaje a México hace 10 años. Entre León y Guadalajara, presencié escenas que no estaba acostumbrado a ver."</blockquote><p>México me impactó profundamente. Conocí a Eliseo Martínez, uno de los protagonistas de Te Prometo Anarquía. Este trabajo combina tres elementos que siempre he buscado en MAP: el relato de "Pelucas", la cultura del skate y una narrativa que va más allá de los trucos.</p></article>
        <article class="sd-ficha" id="av-ruido" data-n="05" data-corto="RUIDO" data-tipo="yt" data-id="u8Yw1QZw_5s" hidden><span class="sd-ficha__num">05</span><h3>RUIDO — Tesis documental</h3><span class="sd-ficha__rot">Tesis de graduación · Universidad Veritas · 2016</span><blockquote>"Con William Conejo comparto esa incomodidad —casi rabia— de vivir en un país que premia lo que no debería premiar."</blockquote><p>RUIDO fue mi tesis de graduación en la Universidad Veritas en 2016. Ese mismo año fue seleccionado para el Festival Internacional de Cine de Costa Rica; la escuela no lo permitió. El documental tuvo que esperar dos años para llegar a su audiencia.</p></article>
        <article class="sd-ficha" id="av-chuck-jones" data-n="06" data-corto="Chuck Jones" data-tipo="yt" data-id="aaO3vJ_xMJU" hidden><span class="sd-ficha__num">06</span><h3>Chuck Jones — Corto documental</h3><span class="sd-ficha__rot">Álbum debut Aperitivo · punk rock · 2019</span><blockquote>"La idea siempre fue clara: no caer en el morbo ni en los clichés que suelen rodear al punk rock. Queríamos mostrar a las personas detrás de la música."</blockquote><p>Durante casi dos meses seguimos a la banda en ensayos, conciertos y conversaciones. Cuatro amigos unidos por la urgencia de tocar y decir lo que piensan. El cierre es el videoclip de "No caminarás solo", un mensaje de resistencia que resume el espíritu de la banda.</p></article>
        <article class="sd-ficha" id="av-circo" data-n="07" data-corto="5irko-0-Seis" data-tipo="yt" data-id="W5z7VqDv_HQ" hidden><span class="sd-ficha__num">07</span><h3>5irko-0-Seis — Hasta que las calles sangren</h3><span class="sd-ficha__rot">Videoclip · hip hop · primera vez trabajando con rap</span><blockquote>"Este proyecto fue especial para mí porque marcó la primera vez que trabajaba con rap."</blockquote><p>El clip se aleja de lo que normalmente se acostumbra en el género. Aquí el concepto fue un poco más allá: entender el tempo, la cadencia y la intensidad del hip hop desde la óptica de la cámara. Con Tavo, uno de los integrantes, la conexión siguió más allá de este proyecto.</p></article>
        <article class="sd-ficha" id="av-sentido-comun" data-n="08" data-corto="Sentido Común" data-tipo="yt" data-id="8dDkYGbBD5o" hidden><span class="sd-ficha__num">08</span><h3>Sentido Común — Corto documental</h3><span class="sd-ficha__rot">Cartago · Skate or Die · premio del público 2024</span><span class="sd-ficha__premio">★ Premio del público — Festival de Cine Cartago</span><blockquote>"En 2024 tuve la oportunidad de trabajar con Sentido Común, una banda muy querida en Cartago y profundamente ligada a las patinetas."</blockquote><p>Este trabajo combina un corto documental en blanco y negro con el videoclip de Skate or Die en color. El resultado fue un registro que no solo documenta a la banda, sino también la comunidad que la rodea.</p></article>
        <article class="sd-ficha" id="av-continental" data-n="09" data-corto="Continental" data-tipo="yt" data-id="22LSFONUBcc" hidden><span class="sd-ficha__num">09</span><h3>Concierto Continental &amp; la versión extendida</h3><span class="sd-ficha__rot">Registro en vivo · One Army Man · 2019</span><blockquote>"Continental es una de esas bandas que considero de culto en Costa Rica: talentosa, sólida y con un sonido que merecería trascender mucho más allá de nuestras fronteras."</blockquote><p>Estuvimos ahí como era la costumbre: One Army Man. Momentos intensos y genuinos, buena música y opiniones honestas sobre la realidad de la escena. La noche fue en 2019, antes de la pandemia.</p></article>
        <article class="sd-ficha" id="av-canchitas" data-n="10" data-corto="Las Canchitas" data-tipo="yt" data-id="kwgF9zsxwZc" hidden><span class="sd-ficha__num">10</span><h3>Las Canchitas — Música, Arte &amp; Patinetas</h3><span class="sd-ficha__rot">Cápsula MAP · rotación en TDMás</span><blockquote>"Fueron piezas muy bien ejecutadas con lo mínimo: una sola cámara, un micrófono."</blockquote><p>Las Canchitas cuenta cómo las canchas de básquet se transformaban en skateparks improvisados en una época donde los parques de skate eran prácticamente inexistentes en Costa Rica. Un fragmento de historia que merecía un registro.</p></article>
        <article class="sd-ficha" id="av-caidas-libres" data-n="11" data-corto="Caídas Libres" data-tipo="yt" data-id="hY9x9JfMutY" hidden><span class="sd-ficha__num">11</span><h3>Caídas Libres — Sesión en San Isidro</h3><span class="sd-ficha__rot">Post punk · San Isidro de Heredia</span><blockquote>"Colaborar con Caídas Libres fue una experiencia muy interesante."</blockquote><p>El clip combina material grabado en San Isidro de Heredia con un trabajo anterior en sala de ensayo. Este proyecto me recordó la importancia de cuidar cada detalle de producción antes de rodar. No conseguí luces, se debió haber utilizado otro micrófono para las entrevistas. Por otro lado es importante que haya quedado un registro.</p></article>
      </div>
    </div>
    <ol class="sd-indice">
      <li><button type="button" data-ficha="av-capitan-rooster" aria-pressed="true"><span class="sd-indice__n">01</span><span class="sd-indice__t"><b>Capitán Rooster</b><i>Corto documental · publicado en Noisey / VICE</i></span><span class="sd-indice__m">Corto documental</span></button></li>
      <li><button type="button" data-ficha="av-malas-palabras" aria-pressed="false"><span class="sd-indice__n">02</span><span class="sd-indice__t"><b>Malas Palabras</b><i>Corto documental · Blank TV</i></span><span class="sd-indice__m">Corto documental</span></button></li>
      <li><button type="button" data-ficha="av-agent-orange" aria-pressed="false"><span class="sd-indice__n">03</span><span class="sd-indice__t"><b>Agent Orange</b><i>Extracto de MAP: Música, Arte &amp; Patineta — episodio 4</i></span><span class="sd-indice__m">Serie MAP</span></button></li>
      <li><button type="button" data-ficha="av-tenochtitlan" aria-pressed="false"><span class="sd-indice__n">04</span><span class="sd-indice__t"><b>Tenochtitlan</b><i>Música, Arte &amp; Patinetas · México</i></span><span class="sd-indice__m">Serie MAP</span></button></li>
      <li><button type="button" data-ficha="av-ruido" aria-pressed="false"><span class="sd-indice__n">05</span><span class="sd-indice__t"><b>RUIDO</b><i>Tesis de graduación · Universidad Veritas · 2016</i></span><span class="sd-indice__m">Documental</span></button></li>
      <li><button type="button" data-ficha="av-chuck-jones" aria-pressed="false"><span class="sd-indice__n">06</span><span class="sd-indice__t"><b>Chuck Jones</b><i>Álbum debut Aperitivo · punk rock · 2019</i></span><span class="sd-indice__m">Corto documental</span></button></li>
      <li><button type="button" data-ficha="av-circo" aria-pressed="false"><span class="sd-indice__n">07</span><span class="sd-indice__t"><b>5irko-0-Seis</b><i>Videoclip · hip hop · primera vez trabajando con rap</i></span><span class="sd-indice__m">Videoclip</span></button></li>
      <li><button type="button" data-ficha="av-sentido-comun" aria-pressed="false"><span class="sd-indice__n">08</span><span class="sd-indice__t"><b>Sentido Común</b><i>Cartago · Skate or Die · premio del público 2024</i></span><span class="sd-indice__m">Corto documental</span></button></li>
      <li><button type="button" data-ficha="av-continental" aria-pressed="false"><span class="sd-indice__n">09</span><span class="sd-indice__t"><b>Continental</b><i>Registro en vivo · One Army Man · 2019</i></span><span class="sd-indice__m">Registro en vivo</span></button></li>
      <li><button type="button" data-ficha="av-canchitas" aria-pressed="false"><span class="sd-indice__n">10</span><span class="sd-indice__t"><b>Las Canchitas</b><i>Cápsula MAP · rotación en TDMás</i></span><span class="sd-indice__m">Cápsula MAP</span></button></li>
      <li><button type="button" data-ficha="av-caidas-libres" aria-pressed="false"><span class="sd-indice__n">11</span><span class="sd-indice__t"><b>Caídas Libres</b><i>Post punk · San Isidro de Heredia</i></span><span class="sd-indice__m">Sesión</span></button></li>
    </ol>
  </section></div>

  <!-- 6 · credo -->
  <div class="ap-wrap"><section class="lb-sec ap-ancho" aria-labelledby="sd-cr-t">
    <div class="ar-tit"><h2 id="sd-cr-t">Credo</h2><span>MAP Radio Radio Pachuko</span></div>
    <div class="sd-credo">
      <div><h3>Creemos <span>en la palabra.</span></h3><p>En la palabra que nace desde el alma. En la música como refugio, en el cine como memoria viva y en la literatura como un mapa para extraviarse y encontrarse de nuevo.</p></div>
      <div><h3>Creemos <span>en la calle.</span></h3><p>En las amistades que se tejen entre humo y madrugadas interminables, en las cantinas como templos sinceros, en la calle como universidad de los libres.</p></div>
    </div>
  </section></div>

  <!-- 7 · cierre: MAP existe -->
  <div class="ap-wrap"><section class="lb-cierre ap-ancho">
    <p class="sd-frase">MAP RADIO existe para recordarnos que la cultura real no se mide en índices de audiencia, sino en el pulso de quienes aún creen que se puede desafiar al sistema <span>sin financiamiento, y aun así con ideas que encienden.</span></p>
    <span class="lb-cierre__src">MAP existe · Credo · mapradiocr.com</span>
  </section></div>
</main>
<?php map_ar_cerrar();

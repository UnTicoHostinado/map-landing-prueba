/* MAP 2027 · Cantinas legendarias · el mapa vivo del Dr. Arkady (Leaflet, sin complementos) */
(function () {
  'use strict';
  var nodo = document.getElementById('cn-datos');
  var el = document.getElementById('cn-mapa');
  if (!nodo || !el || !window.L) return;
  var DATOS = JSON.parse(nodo.textContent);
  var C = DATOS.cantinas;
  var BASE = DATOS.base;
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s || '').replace(/[&<>"']/g, function (m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]; }); };
  var celular = window.matchMedia('(max-width: 640px)');

  /* cartas: Costa Rica completa (nueve hojas JOG sobre la carta regional) y el Valle Central a resolución completa */
  var PAIS = [[6.8, -87.0], [13.0, -80.6]];
  var chica = window.matchMedia('(max-width: 820px)').matches;
  var VALLE_CARTA = [[9.80, -84.46], [10.26, -83.94]];
  var VALLE = [[9.84, -84.40], [10.20, -83.99]];
  var GUA = { w: -86.0, e: -85.62, n: 10.42, s: 10.10 };
  var ZONAS = [
    ['San José centro', 9.933, -84.076], ['Aserrí', 9.859, -84.094], ['Alajuela centro', 10.016, -84.215],
    ['Heredia', 9.998, -84.117], ['Sabanilla', 9.944, -84.030], ['Escazú', 9.919, -84.140], ['Cartago', 9.864, -83.919],
    ['Liberia', 10.635, -85.437], ['Puntarenas', 9.976, -84.833], ['Limón', 9.990, -83.030]
  ];

  var mapa = L.map(el, {
    zoomControl: false, attributionControl: false, zoomSnap: 0.25, zoomDelta: 1,
    minZoom: 6, maxZoom: 17, maxBounds: PAIS, maxBoundsViscosity: 1,
    scrollWheelZoom: false, tap: true
  });
  /* la rueda del ratón solo mueve el mapa después de tocarlo (si no, atrapa el scroll de la página) */
  mapa.once('click focus mousedown touchstart', function () { mapa.scrollWheelZoom.enable(); });

  var calles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { minZoom: 12.5, maxZoom: 19, className: 'cn-calles' });
  var cartaValle = L.imageOverlay(BASE + (chica ? 'carta-valle-hd-m.jpg' : 'carta-valle-hd.jpg'), VALLE_CARTA, { className: 'cn-carta-img' }).addTo(mapa);
  var cartaPais = L.imageOverlay(BASE + (chica ? 'carta-pais-9h-m.jpg' : 'carta-pais-9h.jpg'), PAIS, { className: 'cn-carta-img' });
  setTimeout(function () { cartaPais.addTo(mapa).bringToBack(); }, 400);

  /* el zoom hacia afuera se detiene cuando la carta llena todo el marco: nunca se ve el borde */
  function tope() { mapa.setMinZoom(Math.ceil(mapa.getBoundsZoom(PAIS, true) * 4) / 4); }
  tope();
  mapa.on('resize', tope);
  mapa.fitBounds(VALLE, { padding: [6, 6], animate: false });
  var Z0 = mapa.getZoom();

  /* ---------- estado ---------- */
  var sel = null, filtro = null, filtroNombre = '';
  var capa = L.layerGroup().addTo(mapa);
  var porSlug = {};
  C.forEach(function (c) { porSlug[c.slug] = c; });

  function tipo(c) { return c.cerro ? 'cerro' : (c.aliado ? 'aliado' : (c.cruz ? 'cruz' : 'cantina')); }
  function zonaDe(lat, lng, ancho) {
    if (ancho > 0.15) return 'Valle Central';
    var mejor = '', d = 0.07;
    ZONAS.forEach(function (z) { var dd = Math.hypot(z[1] - lat, z[2] - lng); if (dd < d) { d = dd; mejor = z[0]; } });
    return mejor;
  }

  /* ---------- marcadores y grupos (se arman de nuevo con cada zoom) ---------- */
  function pinta() {
    capa.clearLayers();
    var z = mapa.getZoom();
    var radio = z >= 15.5 ? 20 : 34;
    var pts = C.map(function (c) { return { c: c, p: mapa.project([c.lat, c.lng], z) }; });
    var grupos = [];
    var senales = pts.filter(function (o) { return o.c.senal; });
    pts.forEach(function (o) {
      /* los puntos con señal activa nunca se agrupan: su sonar siempre se ve */
      if (o.c.senal) { grupos.push({ p: o.p, items: [o.c] }); return; }
      var g = null;
      for (var i = 0; i < grupos.length; i++) {
        if (grupos[i].p.distanceTo(o.p) < radio) { g = grupos[i]; break; }
      }
      if (g) { g.items.push(o.c); } else { grupos.push({ p: o.p, items: [o.c] }); }
    });
    grupos.forEach(function (g) {
      if (g.items.length === 1) {
        var c = g.items[0], t = tipo(c), on = sel === c.slug;
        var html = (c.senal ? '<span class="cn-sonar cn-sonar--' + t + '"></span><span class="cn-sonar cn-sonar--' + t + ' cn-sonar--2"></span>' : '') +
          '<span class="cn-pin cn-pin--' + t + (on ? ' is-on' : '') + '"><b>' + esc(c.num) + '</b></span>';
        var m = L.marker([c.lat, c.lng], {
          icon: L.divIcon({ className: 'cn-ico', html: html, iconSize: [30, 30], iconAnchor: [15, 15] }),
          title: c.nombre, keyboard: true, riseOnHover: true, zIndexOffset: on ? 1000 : 0
        });
        m.on('click', function () { elige(c.slug, false); });
        capa.addLayer(m);
      } else {
        var lat = 0, lng = 0, n = g.items.length, b = L.latLngBounds([]);
        g.items.forEach(function (c) { lat += c.lat; lng += c.lng; b.extend([c.lat, c.lng]); });
        lat /= n; lng /= n;
        var nombre = zonaDe(lat, lng, Math.max(b.getEast() - b.getWest(), b.getNorth() - b.getSouth()));
        /* si el grupo cae encima de un punto con señal, se corre un poco para que los dos se vean */
        var pg = mapa.project([lat, lng], z);
        senales.forEach(function (s) {
          var d = pg.distanceTo(s.p);
          if (d < 48) {
            var dx = pg.x - s.p.x, dy = pg.y - s.p.y;
            if (d < 1) { dx = 1; dy = -1; d = Math.SQRT2; }
            pg = L.point(s.p.x + dx / d * 50, s.p.y + dy / d * 50);
          }
        });
        var arriba = pg.y < mapa.project([lat, lng], z).y - 1;
        var ll = mapa.unproject(pg, z);
        lat = ll.lat; lng = ll.lng;
        var activo = filtro && g.items.every(function (c) { return filtro.indexOf(c.slug) > -1; });
        var hayOn = g.items.some(function (c) { return c.slug === sel; });
        var gm = L.marker([lat, lng], {
          icon: L.divIcon({
            className: 'cn-ico',
            html: '<span class="cn-zona' + (activo ? ' is-on' : '') + (hayOn ? ' tiene-sel' : '') + '"><b>' + n + '</b></span>' + (nombre ? '<span class="cn-zona__et' + (arriba ? ' cn-zona__et--arriba' : '') + '">' + esc(nombre) + '</span>' : ''),
            iconSize: [52, 52], iconAnchor: [26, 26]
          }),
          title: (nombre || 'Zona') + ': ' + n + ' puntos', keyboard: true, zIndexOffset: 500
        });
        gm.on('click', function () {
          filtra(g.items.map(function (c) { return c.slug; }), nombre || 'esta zona');
          mapa.flyToBounds(b, { padding: [70, 70], maxZoom: 17, duration: 0.8 });
        });
        capa.addLayer(gm);
      }
    });
    capas();
  }

  /* ---------- qué se ve según el acercamiento ---------- */
  function capas() {
    var z = mapa.getZoom();
    var lejos = z <= Z0 - 1.25;
    var calle = z >= 12.5;
    if (calle) { if (!mapa.hasLayer(calles)) calles.addTo(mapa); } else if (mapa.hasLayer(calles)) { mapa.removeLayer(calles); }
    el.classList.toggle('es-calle', calle);
    $('cn-notam').hidden = !lejos;
    $('cn-volver').hidden = !lejos && !calle;
    $('cn-volver').textContent = calle ? 'Volver a la carta' : 'Volver al Valle Central';
    $('cn-hoja').hidden = celular.matches && !$('cn-volver').hidden;
    $('cn-hoja').textContent = lejos ? 'Carta de Costa Rica · nueve hojas' : (calle ? 'Plano de calles · OpenStreetMap' : 'Hoja Valle Central · 10°N 84°W');
    var verGua = !lejos && !calle && fuera.length > 0;
    $('cn-gua').hidden = !verGua || celular.matches;
    $('cn-gua-boton').hidden = !verGua || !celular.matches;
  }

  /* ---------- Guanacaste: lo que queda fuera de la hoja del Valle Central ---------- */
  var fuera = C.filter(function (c) { return c.lng >= GUA.w && c.lng <= GUA.e && c.lat <= GUA.n && c.lat >= GUA.s; });
  function pintaGua() {
    var cont = $('cn-gua-puntos');
    cont.innerHTML = '';
    fuera.forEach(function (c) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'cn-pin cn-pin--' + tipo(c) + (sel === c.slug ? ' is-on' : '');
      b.style.left = ((c.lng - GUA.w) / (GUA.e - GUA.w) * 100) + '%';
      b.style.top = ((GUA.n - c.lat) / (GUA.n - GUA.s) * 100) + '%';
      b.setAttribute('aria-label', c.nombre);
      b.innerHTML = '<b>' + esc(c.num) + '</b>';
      b.addEventListener('click', function () { elige(c.slug, false); });
      cont.appendChild(b);
    });
    var gb = $('cn-gua-boton');
    gb.textContent = 'Guanacaste · ' + fuera.length + ' →';
    gb.onclick = function () { if (fuera[0]) elige(fuera[0].slug, true); };
  }

  /* ---------- la ficha ---------- */
  function ficha(c) {
    var t = tipo(c), h = '';
    h += '<div class="cn-ficha__cab"><span>Ficha Nº ' + esc(c.num) + '</span><span>' + esc(c.prov) + '</span></div>';
    var sellos = '';
    if (c.aliado) sellos += '<span class="cn-sello cn-sello--aliado">Punto aliado · aquí también se toma birra</span>';
    if (c.cerro) sellos += '<span class="cn-sello cn-sello--cerro">Fuera del aire · cerró operaciones</span>';
    if (c.senal) sellos += '<span class="cn-sello cn-sello--senal">◉ Señal activa</span>';
    if (c.iconico) sellos += '<span class="cn-sello cn-sello--icono">Icónico</span>';
    if (c.cruz) sellos += '<span class="cn-sello cn-sello--cruz">✕ Con cruz</span>';
    if (sellos) h += '<div class="cn-sellos">' + sellos + '</div>';
    h += '<h2 class="cn-ficha__nombre">' + esc(c.nombre) + '</h2>';
    h += '<p class="cn-ficha__lugar">' + esc(c.lugar) + '</p>';
    if (c.resena) h += '<p class="cn-ficha__resena">' + esc(c.resena).replace(/\r?\n+/g, '<br>') + '</p>';
    if (c.cruz) h += '<div class="cn-cruz"><p>Motivo de la cruz</p><p>' + esc(c.cruz) + '</p></div>';
    if (c.fotos && c.fotos.length) {
      h += '<div class="cn-fotos">';
      c.fotos.forEach(function (f, i) {
        h += '<button type="button" class="cn-fotos__b" data-g="' + esc(f.g) + '" aria-label="Ver la foto ' + (i + 1) + ' de ' + esc(c.nombre) + '"><img src="' + esc(f.c) + '" alt="" loading="lazy"></button>';
      });
      h += '</div>';
    }
    if (c.cerro) {
      h += '<p class="cn-memoria">Ya no opera. Queda en la carta como memoria: aquí hubo cantina.</p>';
    } else {
      var ll = c.lat + ',' + c.lng;
      h += '<div class="cn-botones">' +
        '<a class="cn-b" href="https://www.google.com/maps/search/?api=1&amp;query=' + ll + '" target="_blank" rel="noopener">Google Maps</a>' +
        '<a class="cn-b" href="https://waze.com/ul?ll=' + ll + '&amp;navigate=yes" target="_blank" rel="noopener">Waze</a>' +
        '<button type="button" class="cn-b cn-b--rojo" id="cn-compartir">Compartir</button></div>';
    }
    if (c.podcast) h += '<a class="cn-extra" href="' + esc(c.podcast) + '" target="_blank" rel="noopener">Escuchar el episodio grabado aquí ↗</a>';
    if (c.cronica) h += '<a class="cn-extra" href="' + esc(c.cronica) + '">Leer la crónica de esta cantina →</a>';
    var f = $('cn-ficha');
    f.className = 'cn-ficha cn-ficha--' + t;
    f.innerHTML = h;
    [].forEach.call(f.querySelectorAll('.cn-fotos__b'), function (b) {
      b.addEventListener('click', function () {
        var d = $('cn-foto');
        $('cn-foto-img').src = b.getAttribute('data-g');
        $('cn-foto-img').alt = 'Foto de ' + c.nombre;
        if (d.showModal) d.showModal(); else window.open(b.getAttribute('data-g'), '_blank');
      });
    });
    var cp = $('cn-compartir');
    if (cp) cp.addEventListener('click', function () {
      var url = location.origin + location.pathname + '#' + c.slug;
      var txt = c.nombre + ' · Cantinas legendarias de MAP';
      if (navigator.share) { navigator.share({ title: txt, url: url }).catch(function () {}); }
      else if (navigator.clipboard) { navigator.clipboard.writeText(url).then(function () { cp.textContent = 'Enlace copiado'; }); }
    });
  }

  /* ---------- registro ---------- */
  var filas = [].slice.call(document.querySelectorAll('#cn-registro li'));
  filas.forEach(function (li) {
    li.querySelector('button').addEventListener('click', function () { elige(li.getAttribute('data-slug'), 'lista'); });
  });
  function filtra(slugs, nombre) {
    filtro = slugs; filtroNombre = nombre;
    filas.forEach(function (li) { li.hidden = !!slugs && slugs.indexOf(li.getAttribute('data-slug')) < 0; });
    $('cn-reg-nombre').textContent = slugs ? nombre + ' (' + slugs.length + ')' : 'las ' + C.length;
    $('cn-todas').hidden = !slugs;
  }
  $('cn-todas').addEventListener('click', function () { filtra(null, ''); pinta(); });

  function elige(slug, volar) {
    var c = porSlug[slug];
    if (!c) return;
    sel = slug;
    ficha(c);
    filas.forEach(function (li) { li.classList.toggle('is-on', li.getAttribute('data-slug') === slug); });
    if (volar !== 'inicio' && history.replaceState) history.replaceState(null, '', '#' + slug);
    if (volar) mapa.flyTo([c.lat, c.lng], Math.max(mapa.getZoom(), 15), { duration: 0.9 });
    else pinta();
    pintaGua();
    if (celular.matches && volar === 'lista') $('cn-ficha').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  /* ---------- botones ---------- */
  $('cn-mas').addEventListener('click', function () { mapa.zoomIn(); });
  $('cn-menos').addEventListener('click', function () { mapa.zoomOut(); });
  $('cn-volver').addEventListener('click', function () { mapa.flyToBounds(VALLE, { padding: [6, 6], duration: 0.8 }); });
  mapa.on('zoomend', pinta);
  celular.addEventListener && celular.addEventListener('change', capas);

  /* ---------- arranque: #nombre en la dirección, o la primera señal activa ---------- */
  pintaGua();
  var h = decodeURIComponent((location.hash || '').slice(1));
  if (h && porSlug[h]) {
    elige(h, true);
  } else {
    var primera = C.filter(function (c) { return c.senal; })[0] || C[0];
    if (primera) { sel = primera.slug; ficha(primera); filas.forEach(function (li) { li.classList.toggle('is-on', li.getAttribute('data-slug') === sel); }); pinta(); } else pinta();
  }
})();

/* MAP 2027 · Podcast: onda del receptor, receptor VX-996, cita con audio, cinta del episodio 1 y Spotify al tocar */
window.__VX_PICOS=[0.59, 0.533, 0.487, 0.614, 0.543, 0.615, 0.689, 0.606, 0.693, 0.61, 0.485, 0.449, 0.397, 0.544, 0.465, 0.436, 0.391, 0.695, 0.633, 0.535, 0.494, 0.678, 0.623, 0.68, 0.454, 0.573, 0.597, 0.724, 0.695, 0.38, 0.703, 0.481, 0.578, 0.713, 0.765, 0.699, 0.512, 0.411, 0.252, 0.518, 0.349, 0.488, 0.554, 0.513, 0.523, 0.567, 0.468, 0.625, 0.733, 0.73, 0.629, 0.461, 0.624, 0.835, 0.787, 0.753, 0.769, 0.725, 0.517, 0.571, 0.536, 0.597, 0.579, 0.351, 0.697, 0.72, 0.724, 0.813, 0.747, 0.72, 0.658, 0.679, 0.667, 0.517, 0.551, 0.497, 0.495, 0.48, 0.432, 0.579, 0.667, 0.642, 0.666, 0.624, 0.563, 0.558, 0.534, 0.531, 0.565, 0.641, 0.646, 0.699, 0.41, 0.511, 0.568, 0.384, 0.585, 0.715, 0.682, 0.568, 0.584, 0.662, 0.764, 0.754, 0.858, 0.851, 0.735, 0.682, 0.504, 0.747, 0.628, 0.648, 0.706, 0.772, 0.691, 0.623, 0.538, 0.355, 0.614, 0.587, 0.419, 0.572, 0.84, 0.911, 0.885, 0.485, 0.532, 0.562, 0.519, 0.554, 0.636, 0.565, 0.605, 0.541, 0.551, 0.745, 0.708, 0.679, 0.567, 0.52, 0.382, 0.496, 0.636, 0.633, 1, 0.55, 0.497, 0.552, 0.52, 0.48, 0.487, 0.394, 0.302, 0.648, 0.74, 0.737, 0.65, 0.72, 0.695, 0.673, 0.604, 0.274, 0.42, 0.409, 0.502, 0.442, 0.512, 0.672, 0.812, 0.73, 0.489, 0.51, 0.574, 0.598, 0.691, 0.579, 0.593, 0.628, 0.583, 0.588, 0.596, 0.63, 0.62, 0.491, 0.674, 0.724, 0.712, 0.691, 0.598, 0.549, 0.424, 0.742, 0.577, 0.526, 0.552, 0.623, 0.564, 0.67, 0.664, 0.612, 0.571, 0.577, 0.569, 0.631, 0.59, 0.59, 0.513, 0.429, 0.596, 0.603, 0.586, 0.365, 0.413, 0.434, 0.625, 0.635, 0.528, 0.509, 0.657, 0.465, 0.495, 0.499, 0.743, 0.67, 0.636, 0.657, 0.624, 0.568, 0.598, 0.632, 0.519, 0.608, 0.553, 0.426, 0.496, 0.52, 0.598, 0.637, 0.661, 0.54, 0.683, 0.29, 0.581, 0.424, 0.369, 0.505, 0.274, 0.586, 0.446, 0.554, 0.488, 0.748, 0.661, 0.732, 0.715, 0.724, 0.587, 0.628, 0.825, 0.87, 0.909, 0.728, 0.638, 0.459, 0.449, 0.572, 0.559, 0.618, 0.529, 0.641, 0.645, 0.533, 0.468, 0.544, 0.511, 0.527, 0.491, 0.468, 0.579, 0.47, 0.46, 0.612, 0.702, 0.622, 0.584, 0.487, 0.442, 0.387, 0.327, 0.308, 0.444, 0.323, 0.398, 0.564, 0.61, 0.405, 0.624, 0.739, 0.613, 0.355, 0.248, 0.681, 0.768, 0.683, 0.64, 0.611, 0.781, 0.747, 0.738, 0.557, 0.613, 0.588, 0.57, 0.707, 0.75, 0.717, 0.547, 0.654, 0.577, 0.081];

(function(){
  var w=document.getElementById('vx'); if(!w) return;
  var picos=window.__VX_PICOS||[], dur=+w.dataset.dur||1, au=null;
  var cv=document.getElementById('vx-onda'), ctx=cv.getContext('2d'), esc=document.getElementById('vx-escala'), ag=document.getElementById('vx-aguja');
  var bPlay=document.getElementById('vx-play'), tEl=document.getElementById('vx-tiempo'), estado=document.getElementById('vx-estado'), lamp=w.querySelector('.vx__lampara');
  var reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
  var raiz=getComputedStyle(document.documentElement), ROJO=raiz.getPropertyValue('--ar-acento').trim()||'#E8412C', TIZA='rgba(244,243,239,.28)';
  function mm(x){x=Math.max(0,Math.floor(x));var h=Math.floor(x/3600),m=Math.floor(x%3600/60),s=x%60;return (h?h+':':'')+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0')}
  /* escala del dial: marcas finas y seis lecturas de tiempo */
  for(var i=0;i<=60;i++){var m=document.createElement('i');m.style.left=(i/60*100)+'%';if(i%10===0){m.className='mayor';var l=document.createElement('b');l.textContent=mm(dur*i/60);l.style.left=(i/60*100)+'%';esc.appendChild(l)}else if(i%5===0)m.className='media';esc.appendChild(m)}
  function dibujar(){
    var dpr=window.devicePixelRatio||1, W=cv.clientWidth, H=72; if(!W)return;
    cv.width=Math.round(W*dpr); cv.height=Math.round(H*dpr); ctx.setTransform(dpr,0,0,dpr,0,0); ctx.clearRect(0,0,W,H);
    var n=picos.length, bw=W/n, p=(au?au.currentTime:0)/dur;
    for(var k=0;k<n;k++){var h=Math.max(2,picos[k]*(H-10));ctx.fillStyle=(k/n)<p?ROJO:TIZA;ctx.fillRect(k*bw+bw*.18,(H-h)/2,Math.max(1,bw*.64),h)}
  }
  function pos(){
    var t=au?au.currentTime:0, p=Math.min(1,t/dur);
    ag.style.left=(p*100)+'%'; tEl.textContent=mm(t)+' / '+mm(dur); cv.setAttribute('aria-valuenow',Math.round(t)); dibujar();
    if(au&&!au.paused){var a=picos[Math.min(picos.length-1,Math.floor(p*picos.length))]||0;lamp.style.opacity=reduce?1:(.3+.7*a)}
  }
  function tick(){pos(); if(au&&!au.paused) requestAnimationFrame(tick)}
  function cargar(){
    if(au) return au;
    au=new Audio(w.dataset.src); au.preload='auto';
    au.addEventListener('ended',function(){w.classList.remove('sonando');estado.textContent='Fin de la transmisión';lamp.style.opacity='';bPlay.setAttribute('aria-label','Volver a escuchar')});
    au.addEventListener('error',function(){estado.textContent='Sin señal';w.classList.remove('sonando');var n=w.querySelector('.vx__nota');if(n){n.innerHTML='Esta vista previa no deja cargar audio de mapradiocr.com. Ábrala en GitHub o escúchela en Spotify.';n.style.display='block'}});
    au.addEventListener('waiting',function(){estado.textContent='Buscando señal…'});
    au.addEventListener('playing',function(){estado.textContent='Sintonizado'});
    return au;
  }
  function alternar(){
    cargar();
    if(au.paused){var pr=au.play(); if(pr&&pr.catch)pr.catch(function(){estado.textContent='Sin señal'});w.classList.add('sonando');estado.textContent='Buscando señal…';bPlay.setAttribute('aria-label','Pausar');tick()}
    else{au.pause();w.classList.remove('sonando');estado.textContent='En pausa';lamp.style.opacity='';bPlay.setAttribute('aria-label','Seguir escuchando')}
  }
  function ir(t){cargar(); au.currentTime=Math.max(0,Math.min(dur-0.2,t)); pos()}
  bPlay.addEventListener('click',alternar);
  document.getElementById('vx-atras').addEventListener('click',function(){ir((au?au.currentTime:0)-15)});
  document.getElementById('vx-adelante').addEventListener('click',function(){ir((au?au.currentTime:0)+15)});
  cv.addEventListener('click',function(e){var r=cv.getBoundingClientRect();ir((e.clientX-r.left)/r.width*dur)});
  cv.addEventListener('keydown',function(e){
    if(e.key==='ArrowRight'){ir((au?au.currentTime:0)+5);e.preventDefault()}
    else if(e.key==='ArrowLeft'){ir((au?au.currentTime:0)-5);e.preventDefault()}
    else if(e.key===' '||e.key==='Enter'){alternar();e.preventDefault()}
  });
  window.addEventListener('resize',dibujar);
  dibujar(); pos();
})();

(function(){
  var $=function(s){return document.querySelector(s)}, $$=function(s){return [].slice.call(document.querySelectorAll(s))};

  /* audio de la cita: carga al tocar */
  $$('.lb-audio').forEach(function(w){
    var b=w.querySelector('button'), bar=w.querySelector('.lb-audio__barra span'), t=w.querySelector('.lb-audio__t'), au=null;
    function mm(x){x=Math.max(0,Math.round(x));return Math.floor(x/60)+':'+String(x%60).padStart(2,'0')}
    b.addEventListener('click',function(){
      if(!au){au=new Audio(w.dataset.src);
        au.addEventListener('timeupdate',function(){bar.style.width=(au.currentTime/(au.duration||36)*100)+'%';t.textContent=mm((au.duration||36)-au.currentTime)});
        au.addEventListener('ended',function(){w.classList.remove('sonando');bar.style.width='0%';t.textContent=mm(au.duration)});}
      if(au.paused){au.play();w.classList.add('sonando')}else{au.pause();w.classList.remove('sonando')}
    });
  });

  /* episodio 1: cinta con avance y saltos */
  $$('.pc-cinta').forEach(function(w){
    var b=w.querySelector('.pc-cinta__play'), barra=w.querySelector('.pc-cinta__barra'), lleno=barra.querySelector('span'), t=w.querySelector('.pc-cinta__t'), D=+w.dataset.dur, au=null;
    function hms(x){x=Math.max(0,Math.floor(x));return Math.floor(x/3600)+':'+String(Math.floor(x%3600/60)).padStart(2,'0')+':'+String(x%60).padStart(2,'0')}
    function pinta(){var d=au&&au.duration||D, c=au?au.currentTime:0;lleno.style.width=(c/d*100)+'%';t.textContent=hms(c)+' / '+hms(d);barra.setAttribute('aria-valuenow',Math.floor(c))}
    function cargar(){if(au)return;au=new Audio(w.dataset.src);au.preload='metadata';au.addEventListener('timeupdate',pinta);au.addEventListener('ended',function(){w.classList.remove('sonando')})}
    b.addEventListener('click',function(){cargar();if(au.paused){au.play();w.classList.add('sonando')}else{au.pause();w.classList.remove('sonando')}});
    function ir(seg){cargar();var x=Math.max(0,Math.min((au.duration||D)-1,seg));if(au.readyState<1){au.addEventListener('loadedmetadata',function(){au.currentTime=x;pinta()},{once:true});au.load()}else au.currentTime=x;pinta()}
    barra.addEventListener('click',function(e){var r=barra.getBoundingClientRect();ir((e.clientX-r.left)/r.width*(au&&au.duration||D))});
    barra.addEventListener('keydown',function(e){if(e.key==='ArrowRight'){ir((au?au.currentTime:0)+30);e.preventDefault()}if(e.key==='ArrowLeft'){ir((au?au.currentTime:0)-15);e.preventDefault()}});
    $$('[data-salto]').forEach(function(s){if(w.contains(s))s.addEventListener('click',function(){ir((au?au.currentTime:0)+(+s.dataset.salto))})});
  });

  /* reproductores de Spotify: cargan solo al tocar */
  var puede=true;
  $$('[data-sp]').forEach(function(b){
    b.addEventListener('click',function(){
      var tipo=b.dataset.tipo, id=b.dataset.sp, caja=document.createElement('div');
      caja.className='pc-sp pc-sp--'+tipo;
      if(puede){
        caja.innerHTML='<iframe src="https://open.spotify.com/embed/'+tipo+'/'+id+'?utm_source=generator&theme=0" title="Reproductor de Spotify" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>';
      }else{
        caja.innerHTML='<div class="pc-sp__aviso">Aquí se abre el reproductor de Spotify. Esta vista previa no lo carga: <a href="https://open.spotify.com/'+tipo+'/'+id+'">escuchar en Spotify ↗</a></div>';
      }
      var ret=b.closest('.pc-ret'); if(ret){b.remove();ret.appendChild(caja)}else b.replaceWith(caja);
    });
  });
})();

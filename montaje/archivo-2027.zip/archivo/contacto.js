/* MAP 2027 · página contacto */
(function(){
  var $=function(s){return document.querySelector(s)}, $$=function(s){return [].slice.call(document.querySelectorAll(s))};

  /* ventanillas: el asunto viaja al formulario */
  var vs=$$('.ct-v'), asunto=$('#ct-asunto');
  function elegir(a,mover){
    vs.forEach(function(v){v.setAttribute('aria-pressed',v.dataset.asunto===a)});
    asunto.textContent=a;
    var c4=document.getElementById('wpforms-18966-field_5'); if(c4)c4.value=a;
    if(mover){$('#ct-form').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});setTimeout(function(){var n=document.getElementById('wpforms-18966-field_1');if(n)n.focus({preventScroll:true})},400)}
  }
  vs.forEach(function(v){v.addEventListener('click',function(){elegir(v.dataset.asunto,true)})});
  $$('[data-ir-asunto]').forEach(function(b){b.addEventListener('click',function(){elegir(b.dataset.irAsunto,true)})});
  if(location.hash==='#panol-pregunta')elegir('El Pañol · merch',false);
  /* sala de proyección: un solo reproductor, carga al tocar */
  var puede=true;
  var pant=$('#ct-pantalla');
  function proyectar(id,titulo,desde){
    $$('.ct-prod li').forEach(function(li){li.classList.toggle('activa',!!li.querySelector('[data-yt="'+id+'"]'))});
    if(puede){
      pant.innerHTML='<iframe src="https://www.youtube-nocookie.com/embed/'+id+'?autoplay=1&rel=0&playsinline=1" title="'+titulo.replace(/"/g,'')+'" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>';
    }else{
      pant.innerHTML='<div class="ct-pantalla__reposo"><span>'+titulo+'</span><b>Aquí se proyecta</b><a href="https://youtu.be/'+id+'">Esta vista previa no carga YouTube · abrir en YouTube ↗</a></div>';
    }
    if(desde)$('#ct-sala').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});
  }
  $$('[data-yt]').forEach(function(b){b.addEventListener('click',function(){proyectar(b.dataset.yt,b.dataset.titulo,b.classList.contains('ct-link'))})});

  $('#ct-lista').addEventListener('submit',function(e){
    e.preventDefault(); var i=$('#ct-lista-correo'), est=$('#ct-lista-estado');
    if(!i.value.trim()||i.validity.typeMismatch){est.textContent='Revisá el correo.';return}
    est.textContent='Apuntando…';fetch('/wp-json/map/v1/lista',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({correo:i.value.trim(),web:(e.target.web||{}).value||''})}).then(function(r){return r.json().then(function(d){return {ok:r.ok,d:d}})}).then(function(x){if(x.ok){est.textContent=x.d.nuevo===false?'Ya estabas en la lista. Te avisamos primero.':'Apuntado. Te avisamos primero cuando salgan.';i.value=''}else{est.textContent=(x.d&&x.d.message)||'No se pudo apuntar. Probá de nuevo.'}}).catch(function(){est.textContent='No se pudo apuntar. Probá de nuevo.'});
  });
})();

/* el asunto inicial también viaja en el formulario */
(function(){var c4=document.getElementById('wpforms-18966-field_5'),a=document.getElementById('ct-asunto');if(c4&&a&&!c4.value)c4.value=a.textContent;})();

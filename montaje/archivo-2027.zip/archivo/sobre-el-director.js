/* MAP 2027 · página sobre-el-director */
(function(){
  var $=function(s){return document.querySelector(s)}, $$=function(s){return [].slice.call(document.querySelectorAll(s))};

  /* moviola: el índice cambia la ficha; la pantalla carga solo al tocar Proyectar */
  var puede=true;
  var pant=$('#sd-pantalla'), quieto=matchMedia('(prefers-reduced-motion: reduce)').matches, actual=null;
  function fuente(f){return f.dataset.tipo==='sp'
    ?'https://open.spotify.com/embed/episode/'+f.dataset.id+'/video?utm_source=generator&theme=0'
    :'https://www.youtube-nocookie.com/embed/'+f.dataset.id+'?autoplay=1&rel=0&playsinline=1'}
  function enlace(f){return f.dataset.tipo==='sp'?'https://open.spotify.com/episode/'+f.dataset.id:'https://youtu.be/'+f.dataset.id}
  function reposo(f){
    pant.innerHTML='<div class="sd-reposo"><span>Archivo audiovisual · pieza '+f.dataset.n+'</span><b>'+f.dataset.corto+'</b><button type="button" class="sd-proyectar" data-proyectar>Proyectar</button></div>';
  }
  function proyectar(f){
    pant.innerHTML=puede
      ?'<iframe src="'+fuente(f)+'" title="'+f.dataset.corto+'" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>'
      :'<div class="sd-reposo"><span>Pieza '+f.dataset.n+' · '+f.dataset.corto+'</span><b>Aquí se proyecta</b><a href="'+enlace(f)+'">Esta vista previa no carga el video · abrir ↗</a></div>';
  }
  function elegir(id,mover){
    var f=document.getElementById(id); if(!f)return; actual=f;
    $$('.sd-ficha').forEach(function(x){x.hidden=(x!==f)});
    $$('.sd-extra').forEach(function(x){x.hidden=(x.dataset.de!==id)});
    $$('.sd-indice button').forEach(function(b){b.setAttribute('aria-pressed',b.dataset.ficha===id)});
    reposo(f);
    if(mover)$('#sd-moviola').scrollIntoView({behavior:quieto?'auto':'smooth',block:'start'});
  }
  pant.addEventListener('click',function(e){if(e.target.closest('[data-proyectar]')&&actual)proyectar(actual)});
  $$('.sd-indice button').forEach(function(b){b.addEventListener('click',function(){elegir(b.dataset.ficha,true)})});
  var h=location.hash.slice(1); elegir(document.getElementById(h)&&h.indexOf('av-')===0?h:$('.sd-ficha').id,false);

  /* cierre: cada línea de borde a borde (cuatro en pantalla ancha, siete en celular) */
  var frase=$('.sd-frase');
  var CORTES={ancho:['MAP Radio existe para recordarnos que la cultura real','no se mide en índices de audiencia, sino en el pulso','de quienes aún creen que se puede desafiar al sistema','[sin financiamiento, y aun así con ideas que encienden.]'],
              angosto:['MAP Radio existe para recordarnos','que la cultura real no se mide','en índices de audiencia, sino en','el pulso de quienes aún creen que','se puede desafiar al sistema','[sin financiamiento, y aun así]','[con ideas que encienden.]']}, corte='';
  function armar(){
    var c=frase.clientWidth<600?'angosto':'ancho'; if(c===corte)return; corte=c;
    frase.innerHTML=CORTES[c].map(function(l){return '<span class="sd-linea">'+l.replace('[','<span>').replace(']','</span>')+'</span>'}).join(' ');
  }
  function ajustar(){
    armar(); frase.classList.add('lista');
    var ancho=frase.clientWidth;
    $$('.sd-linea').forEach(function(l){
      var f=100; l.style.fontSize=f+'px';
      for(var i=0;i<3;i++){f=f*ancho/l.getBoundingClientRect().width;l.style.fontSize=(f*.997)+'px'}
    });
  }
  if(frase){ajustar();if(document.fonts&&document.fonts.load)document.fonts.load('100px "Bebas Neue"').then(ajustar,ajustar);
    var rt;addEventListener('resize',function(){clearTimeout(rt);rt=setTimeout(ajustar,120)});}
})();

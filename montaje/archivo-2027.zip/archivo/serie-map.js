/* MAP 2027 · página serie-map */
(function(){
  var $=function(s){return document.querySelector(s)}, $$=function(s){return [].slice.call(document.querySelectorAll(s))};

  /* frase de cierre: cada línea llega de borde a borde */
  var frase=$('.sm-frase');
  /* cortes: tres líneas en pantalla ancha, cinco en celular; lo que va entre [ ] sale en rojo */
  var CORTES={ancho:['MAP no entrevista famosos. MAP encuentra personas','que tienen historias increíbles que contar,','[aunque nadie los haya escuchado todavía.]'],
              angosto:['MAP no entrevista famosos.','MAP encuentra personas que','tienen historias increíbles','que contar, [aunque nadie]','[los haya escuchado todavía.]']}, corte='';
  function armar(){
    var c=frase.clientWidth<600?'angosto':'ancho'; if(c===corte)return; corte=c;
    frase.innerHTML=CORTES[c].map(function(l){return '<span class="sm-linea">'+l.replace('[','<span>').replace(']','</span>')+'</span>'}).join(' ');
  }
  function ajustar(){
    armar();
    frase.classList.add('lista');
    var ancho=frase.clientWidth;
    $$('.sm-linea').forEach(function(l){
      var f=100; l.style.fontSize=f+'px';
      for(var i=0;i<3;i++){f=f*ancho/l.getBoundingClientRect().width;l.style.fontSize=(f*.997)+'px'}
    });
  }
  if(frase){ajustar();if(document.fonts&&document.fonts.load)document.fonts.load('100px "Bebas Neue"').then(ajustar,ajustar);
    var rt;addEventListener('resize',function(){clearTimeout(rt);rt=setTimeout(ajustar,120)});}

  /* sala de proyección: un solo reproductor, carga al tocar */
  var puede=true;
  var pant=$('#sm-pantalla'), quieto=matchMedia('(prefers-reduced-motion: reduce)').matches;
  $$('.sm-rollo[data-yt]').forEach(function(b){
    b.addEventListener('click',function(){
      var id=b.dataset.yt, tit=b.dataset.titulo;
      $$('.sm-rollo').forEach(function(r){r.classList.toggle('activo',r===b);r.setAttribute('aria-pressed',r===b)});
      pant.innerHTML=puede
        ?'<iframe src="https://www.youtube-nocookie.com/embed/'+id+'?autoplay=1&rel=0&playsinline=1" title="'+tit+'" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>'
        :'<div class="sm-reposo"><span>'+tit+'</span><b>Aquí se proyecta</b><a href="https://youtu.be/'+id+'">Esta vista previa no carga YouTube · abrir en YouTube ↗</a></div>';
      pant.scrollIntoView({behavior:quieto?'auto':'smooth',block:'start'});
    });
  });
})();

/* MAP 2027 · Plantilla de entrada: menú, buscador y proyecciones dentro de la entrada */
(function () {
  var $ = function (s, c) { return (c || document).querySelector(s); },
      $$ = function (s, c) { return [].slice.call((c || document).querySelectorAll(s)); };

  var mb = $('#ar-menu-btn'), menu = $('#ar-menu');
  if (mb && menu) mb.addEventListener('click', function () {
    var on = menu.classList.toggle('abierto'); mb.setAttribute('aria-expanded', on);
  });

  var bus = $('#ar-buscador'), abrir = $('#ar-buscar-btn'), cerrar = $('#ar-buscar-cerrar');
  if (bus && abrir) {
    abrir.addEventListener('click', function () { bus.hidden = false; $('#ar-q').focus(); });
    if (cerrar) cerrar.addEventListener('click', function () { bus.hidden = true; abrir.focus(); });
    bus.addEventListener('click', function (e) { if (e.target === bus) bus.hidden = true; });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !bus.hidden) { bus.hidden = true; abrir.focus(); } });
    $('form', bus).addEventListener('submit', function (e) { if (!$('#ar-q').value.trim()) e.preventDefault(); });
  }

  /* proyección dentro de la entrada (patrón «rollo» de la hoja de rodaje): el reproductor solo carga al tocar */
  $$('button.hr-proj__screen[data-yt]').forEach(function (b) {
    b.addEventListener('click', function () {
      var nombre = ($('.hr-proj__name', b) || {}).textContent || 'Video', v = document.createElement('div'), f = document.createElement('iframe');
      v.className = 'hr-proj__video';
      f.src = 'https://www.youtube-nocookie.com/embed/' + b.dataset.yt + '?autoplay=1&rel=0&modestbranding=1&playsinline=1';
      f.title = nombre; f.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen'; f.allowFullscreen = true;
      v.appendChild(f); b.replaceWith(v);
    });
  });
})();

/* categoría: páginas del registro (cuadros numerados) */
(function () {
  var $$ = function (s) { return [].slice.call(document.querySelectorAll(s)); };
  var pags = $$('.ac-pag'), total = pags.length, actual = 1;
  if (total < 2) return;
  function ir(n) {
    actual = n;
    pags.forEach(function (p) { p.hidden = +p.dataset.pag !== n; });
    $$('.ac-pags [data-ir]').forEach(function (b) {
      if (b.dataset.ir === 'sig') { b.disabled = n >= total; b.textContent = n >= total ? 'Fin del registro' : 'Siguiente →'; }
      else if (+b.dataset.ir === n) b.setAttribute('aria-current', 'page');
      else b.removeAttribute('aria-current');
    });
    var r = document.querySelector('.ac-reg');
    if (r && r.getBoundingClientRect().top < 0) r.scrollIntoView({ behavior: 'smooth' });
  }
  $$('.ac-pags [data-ir]').forEach(function (b) {
    b.addEventListener('click', function () { ir(b.dataset.ir === 'sig' ? actual + 1 : +b.dataset.ir); });
  });
})();

/* búsqueda: filtros por categoría, «Cargar más» y otros tres imperdibles al azar */
(function () {
  var $ = function (s) { return document.querySelector(s); },
      $$ = function (s, c) { return [].slice.call((c || document).querySelectorAll(s)); };
  var lista = $('#bu-lista'), mas = $('#bu-mas'), PASO = 8, vistos = PASO, cat = 'todos';
  if (lista) {
    var items = $$('li', lista);
    var pintar = function () {
      var sel = items.filter(function (li) { return cat === 'todos' || (',' + li.dataset.cats + ',').indexOf(',' + cat + ',') >= 0; });
      items.forEach(function (li) { li.hidden = true; });
      sel.slice(0, vistos).forEach(function (li) { li.hidden = false; });
      if (mas) mas.hidden = sel.length <= vistos;
      $$('#bu-filtros button').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.cat === cat); });
    };
    $$('#bu-filtros button').forEach(function (b) {
      b.addEventListener('click', function () { cat = b.dataset.cat; vistos = PASO; pintar(); });
    });
    if (mas) mas.addEventListener('click', function () { vistos += PASO; pintar(); });
    pintar();
  }
  var imp = $('#bu-imperdibles'), azar = $('#bu-azar');
  if (imp) {
    var lis = $$('li', imp);
    var tres = function () {
      var pool = lis.slice(), elegidos = [];
      while (elegidos.length < 3 && pool.length) elegidos.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]);
      lis.forEach(function (li) { li.hidden = elegidos.indexOf(li) < 0; });
    };
    tres();
    if (azar) { if (lis.length <= 3) azar.hidden = true; else azar.addEventListener('click', tres); }
  }
})();

/* portada de Textos: registro con filtros por categoría («Más ▾») y «Cargar más» de 8 en 8 */
(function () {
  var $ = function (s) { return document.querySelector(s); },
      $$ = function (s, c) { return [].slice.call((c || document).querySelectorAll(s)); };
  var reg = $('#ap-registro'); if (!reg) return;
  var items = $$('li', reg), mas = $('#ap-mas'), vacio = $('#ap-vacio'), PASO = 8, vistos = PASO, cat = 'todos';
  function pintar() {
    var sel = items.filter(function (li) { return cat === 'todos' || (',' + li.dataset.cats + ',').indexOf(',' + cat + ',') >= 0; });
    items.forEach(function (li) { li.hidden = true; });
    sel.slice(0, vistos).forEach(function (li) { li.hidden = false; });
    if (mas) mas.hidden = sel.length <= vistos;
    if (vacio) vacio.hidden = sel.length > 0;
    $$('#ap-filtros button[data-cat]').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.cat === cat); });
  }
  $$('#ap-filtros button[data-cat]').forEach(function (b) {
    b.addEventListener('click', function () { cat = b.dataset.cat; vistos = PASO; pintar(); });
  });
  var bm = $('#ap-filtros .ap-filtros__mas'), caja = $('#ap-filtros .ap-filtros__otros');
  if (bm && caja) bm.addEventListener('click', function () {
    caja.hidden = !caja.hidden; bm.setAttribute('aria-expanded', !caja.hidden); bm.textContent = caja.hidden ? 'Más ▾' : 'Menos ▴';
  });
  if (mas) mas.addEventListener('click', function () { vistos += PASO; pintar(); });
  pintar();
})();
